import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/scheduler.dart';

/// طقس متحرك (مطر/ثلج/أوراق/بتلات) + طيور وفراشات فوق الغابة.
class SceneOverlay extends StatefulWidget {
  final bool birds;
  final bool butterflies;
  final String weather; // none | rain | snow | leaves | petals
  final bool lite;
  const SceneOverlay({
    super.key,
    this.birds = false,
    this.butterflies = false,
    this.weather = 'none',
    this.lite = true,
  });

  @override
  State<SceneOverlay> createState() => _SceneOverlayState();
}

class _SceneOverlayState extends State<SceneOverlay> with SingleTickerProviderStateMixin {
  final ValueNotifier<double> _t = ValueNotifier<double>(0);
  Ticker? _tk;
  Duration _last = Duration.zero;

  bool get _active => widget.birds || widget.butterflies || widget.weather != 'none';

  @override
  void initState() {
    super.initState();
    _tk = createTicker((e) {
      final gap = widget.lite ? 60 : 33;
      if ((e - _last).inMilliseconds >= gap) {
        _last = e;
        _t.value = e.inMilliseconds / 1000.0;
      }
    });
    if (_active) _tk!.start();
  }

  @override
  void didUpdateWidget(SceneOverlay old) {
    super.didUpdateWidget(old);
    if (_active && !(_tk?.isActive ?? false)) {
      _tk?.start();
    } else if (!_active && (_tk?.isActive ?? false)) {
      _tk?.stop();
    }
  }

  @override
  void dispose() {
    _tk?.dispose();
    _t.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_active) return const SizedBox.shrink();
    return IgnorePointer(
      child: RepaintBoundary(
        child: CustomPaint(
          size: Size.infinite,
          painter: _OverlayPainter(
            t: _t,
            birds: widget.birds,
            butterflies: widget.butterflies,
            weather: widget.weather,
            lite: widget.lite,
          ),
        ),
      ),
    );
  }
}

class _OverlayPainter extends CustomPainter {
  final ValueListenable<double> t;
  final bool birds, butterflies, lite;
  final String weather;
  _OverlayPainter({
    required this.t,
    required this.birds,
    required this.butterflies,
    required this.weather,
    required this.lite,
  }) : super(repaint: t);

  @override
  void paint(Canvas canvas, Size size) {
    final tt = t.value;
    final w = size.width, h = size.height;
    if (w <= 0 || h <= 0) return;
    _weather(canvas, w, h, tt);
    if (birds) _birds(canvas, w, h, tt);
    if (butterflies) _butterflies(canvas, w, h, tt);
  }

  void _weather(Canvas c, double w, double h, double t) {
    if (weather == 'none') return;
    final n = lite ? 22 : 42;
    for (var i = 0; i < n; i++) {
      final seed = i * 0.6180339 % 1.0;
      final speed = weather == 'rain' ? 0.9 : (weather == 'snow' ? 0.12 : 0.18);
      final y = ((t * speed + seed * 1.7) % 1.0) * (h + 20) - 10;
      var x = ((i * 0.37 + seed) % 1.0) * w;
      switch (weather) {
        case 'rain':
          c.drawLine(
            Offset(x, y),
            Offset(x - 4, y + 14),
            Paint()
              ..color = Colors.white.withValues(alpha: 0.38)
              ..strokeWidth = 1.4
              ..strokeCap = StrokeCap.round,
          );
          break;
        case 'snow':
          x += math.sin(t * 1.2 + i) * 10;
          c.drawCircle(Offset(x, y), 1.8 + (i % 3) * 0.7, Paint()..color = Colors.white.withValues(alpha: 0.85));
          break;
        case 'leaves':
          x += math.sin(t * 1.0 + i) * 16;
          const cols = [Color(0xFFE67E22), Color(0xFFF1C40F), Color(0xFFB9770E), Color(0xFFD35400)];
          c.save();
          c.translate(x, y);
          c.rotate(t * 1.5 + i);
          c.drawOval(
            Rect.fromCenter(center: Offset.zero, width: 9, height: 5),
            Paint()..color = cols[i % cols.length].withValues(alpha: 0.9),
          );
          c.restore();
          break;
        default:
          x += math.sin(t * 0.9 + i) * 14;
          c.save();
          c.translate(x, y);
          c.rotate(t + i);
          c.drawOval(
            Rect.fromCenter(center: Offset.zero, width: 7, height: 4),
            Paint()..color = const Color(0xFFFFB7D5).withValues(alpha: 0.9),
          );
          c.restore();
      }
    }
  }

  void _birds(Canvas c, double w, double h, double t) {
    final n = lite ? 2 : 3;
    final p = Paint()
      ..color = const Color(0xFF37474F)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < n; i++) {
      final x = ((t * 0.035 * (1 + i * 0.25) + i * 0.37) % 1.2 - 0.1) * w;
      final y = h * (0.1 + 0.07 * i) + math.sin(t * 1.4 + i) * 6;
      final flap = math.sin(t * 8 + i * 2) * 4;
      final path = Path()
        ..moveTo(x - 9, y + flap)
        ..quadraticBezierTo(x - 4, y - 3, x, y)
        ..quadraticBezierTo(x + 4, y - 3, x + 9, y + flap);
      c.drawPath(path, p);
    }
  }

  void _butterflies(Canvas c, double w, double h, double t) {
    const cols = [Color(0xFFFF8FB1), Color(0xFFFFD54F), Color(0xFF9FA8DA)];
    final n = lite ? 2 : 3;
    for (var i = 0; i < n; i++) {
      final x = w * (0.22 + 0.28 * i) + math.sin(t * 0.7 + i * 2) * w * 0.12;
      final y = h * 0.66 + math.sin(t * 1.3 + i) * h * 0.05;
      final fw = 2.5 + 5.5 * math.sin(t * 14 + i).abs();
      final paint = Paint()..color = cols[i % cols.length];
      c.drawOval(Rect.fromCenter(center: Offset(x - fw * 0.8, y), width: fw * 1.6, height: 8), paint);
      c.drawOval(Rect.fromCenter(center: Offset(x + fw * 0.8, y), width: fw * 1.6, height: 8), paint);
      c.drawLine(Offset(x, y - 3), Offset(x, y + 4), Paint()..color = const Color(0xFF4E342E)..strokeWidth = 1.6);
    }
  }

  @override
  bool shouldRepaint(covariant _OverlayPainter old) =>
      old.weather != weather || old.birds != birds || old.butterflies != butterflies || old.lite != lite;
}
