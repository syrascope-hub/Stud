import 'package:flutter/material.dart';
import '../forest_grid.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

const _months = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
];
const _tabs = ['يوم', 'أسبوع', 'شهر', 'سنة'];

class ForestPage extends StatefulWidget {
  const ForestPage({super.key});
  @override
  State<ForestPage> createState() => _ForestPageState();
}

class _ForestPageState extends State<ForestPage> {
  int tab = 0; // 0 يوم، 1 أسبوع، 2 شهر، 3 سنة
  DateTime anchor = _today();

  static DateTime _today() {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day);
  }

  DateTime _start(DateTime a) {
    switch (tab) {
      case 0:
        return DateTime(a.year, a.month, a.day);
      case 1:
        return weekStartOf(a);
      case 2:
        return DateTime(a.year, a.month, 1);
      default:
        return DateTime(a.year, 1, 1);
    }
  }

  void _shift(int dir) {
    setState(() {
      switch (tab) {
        case 0:
          anchor = DateTime(anchor.year, anchor.month, anchor.day + dir);
          break;
        case 1:
          anchor = DateTime(anchor.year, anchor.month, anchor.day + 7 * dir);
          break;
        case 2:
          anchor = DateTime(anchor.year, anchor.month + dir, 1);
          break;
        default:
          anchor = DateTime(anchor.year + dir, 1, 1);
      }
    });
  }

  bool get _canNext => _start(anchor).isBefore(_start(_today()));

  String get _label {
    switch (tab) {
      case 0:
        return '${dayNames[weekdayIndex(anchor)]} ${anchor.day} ${_months[anchor.month - 1]}';
      case 1:
        final a = weekStartOf(anchor);
        final b = DateTime(a.year, a.month, a.day + 6);
        return '${a.day} ${_months[a.month - 1]} – ${b.day} ${_months[b.month - 1]}';
      case 2:
        return '${_months[anchor.month - 1]} ${anchor.year}';
      default:
        return '${anchor.year}';
    }
  }

  DateTime _recDate(PlantRecord r) {
    final p = r.weekKey.split('-');
    return DateTime(int.parse(p[0]), int.parse(p[1]), int.parse(p[2]) + r.day);
  }

  bool _match(PlantRecord r) {
    final d = _recDate(r);
    switch (tab) {
      case 0:
        return d.year == anchor.year && d.month == anchor.month && d.day == anchor.day;
      case 1:
        return r.weekKey == dateKey(weekStartOf(anchor));
      case 2:
        return d.year == anchor.year && d.month == anchor.month;
      default:
        return d.year == anchor.year;
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    final list = s.plants.where(_match).toList();
    final alive = list.where((p) => p.alive).length;
    final dead = list.length - alive;
    final mins = list.where((p) => p.alive).fold(0, (a, b) => a + b.minutes);

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [C.p.forestTop, C.p.forestBottom],
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Container(
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.white.withValues(alpha: 0.6)),
                ),
                child: Row(
                  children: [
                    for (var i = 0; i < 4; i++)
                      Expanded(
                        child: GestureDetector(
                          onTap: () => setState(() {
                            tab = i;
                            anchor = _today();
                          }),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 180),
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            decoration: BoxDecoration(
                              color: tab == i ? Colors.white : Colors.transparent,
                              borderRadius: BorderRadius.circular(11),
                            ),
                            child: Text(
                              _tabs[i],
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: tab == i ? const Color(0xFF14352A) : Colors.white,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            Row(
              children: [
                IconButton(
                  onPressed: () => _shift(-1),
                  icon: const Icon(Icons.chevron_right, color: Colors.white, size: 30),
                ),
                Expanded(
                  child: Text(
                    _label,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700),
                  ),
                ),
                IconButton(
                  onPressed: _canNext ? () => _shift(1) : null,
                  icon: Icon(Icons.chevron_left, color: _canNext ? Colors.white : Colors.white24, size: 30),
                ),
              ],
            ),
            _waterBar(s),
            if (tab == 0)
              DayChips(
                selected: weekdayIndex(anchor),
                onTap: (i) => setState(() {
                  final ws = weekStartOf(anchor);
                  final d = DateTime(ws.year, ws.month, ws.day + i);
                  if (!d.isAfter(_today())) anchor = d;
                }),
                badge: (i) => s.plantsFor(dateKey(weekStartOf(anchor)), i).where((p) => p.alive).length,
              ),
            Expanded(
              child: Stack(
                children: [
                  Positioned.fill(
                    child: GridForestView(
                      key: ValueKey('$tab-${anchor.millisecondsSinceEpoch}-${list.length}'),
                      plants: list,
                      lite: s.lowPower,
                      onTap: (r) => _showPlant(s, r),
                    ),
                  ),
                  if (list.isEmpty)
                    Positioned(
                      bottom: 24,
                      left: 28,
                      right: 28,
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.32),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: const Text(
                          'لا أشجار هنا بعد.\nابدأ جلسة تركيز لتزرع أول شجرة 🌱',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.white, height: 1.6),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 6, 24, 16),
              child: Row(
                children: [
                  Text(fmtMin(mins), style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
                  const Spacer(),
                  Text('$alive', style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
                  const SizedBox(width: 6),
                  _leaf(const Color(0xFF7BD66A)),
                  const SizedBox(width: 18),
                  Text('$dead', style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
                  const SizedBox(width: 6),
                  _leaf(const Color(0xFFE7D3A0)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _waterBar(AppStore s) {
    final thirsty = s.thirstyPlants.length;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 2, 16, 6),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text('💧 ${s.water}',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              thirsty == 0 ? 'كل أشجارك مرتوية 🌿' : '$thirsty ${thirsty == 1 ? 'شجرة عطشى' : 'أشجار عطشى'} 🍂',
              style: const TextStyle(color: Colors.white70, fontSize: 13),
            ),
          ),
          if (thirsty > 0)
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF4FC3F7),
                foregroundColor: const Color(0xFF06324A),
                visualDensity: VisualDensity.compact,
              ),
              onPressed: () {
                if (s.water < 1) {
                  _snack('لا توجد قطرات ماء. أنجز مهمة أو جلسة تركيز لتكسب الماء 💧');
                  return;
                }
                final n = s.waterAll();
                _snack('سقيت $n ${n == 1 ? 'شجرة' : 'أشجار'} 💦');
              },
              icon: const Icon(Icons.water_drop, size: 18),
              label: const Text('اسقِ الكل'),
            ),
        ],
      ),
    );
  }

  void _snack(String m) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m)));
  }

  Widget _leaf(Color c) => Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF14352A),
          border: Border.all(color: c, width: 2.5),
        ),
        child: Icon(Icons.eco, size: 17, color: c),
      );

  void _showPlant(AppStore s, PlantRecord r) {
    final p = plantById(r.type);
    final t = DateTime.fromMillisecondsSinceEpoch(r.ts);
    final sub = r.subjectId == null ? null : s.subjectById(r.subjectId!);
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 4, 24, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(r.alive ? p.emoji : '🥀', style: const TextStyle(fontSize: 52)),
            const SizedBox(height: 6),
            Text(p.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text(
              '${r.alive ? 'نمت بعد' : 'ذبلت (كانت ستنمو في)'} ${fmtMin(r.minutes)}'
              '${sub == null ? '' : ' · ${sub.emoji} ${sub.name}'}',
              style: TextStyle(color: C.sub),
            ),
            const SizedBox(height: 4),
            Text(
              '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')} · ${t.day}/${t.month}',
              style: TextStyle(color: C.sub, fontSize: 12),
            ),
            if (r.isSeedling()) ...[
              const SizedBox(height: 14),
              Text(
                r.needsWater()
                    ? 'عطشى منذ ${r.dryDays()} ${r.dryDays() == 1 ? 'يوم' : 'أيام'} 🍂'
                    : 'مرتوية 💧',
                style: TextStyle(color: r.needsWater() ? C.danger : C.accent, fontWeight: FontWeight.w700),
              ),
              if (r.needsWater()) ...[
                const SizedBox(height: 4),
                Text(
                  r.dryDays() > PlantRecord.graceDays
                      ? 'الأشجار الجافة تخصم ${r.penaltyPerDay} عملة يومياً حتى تُسقى'
                      : 'اسقِها خلال ${PlantRecord.graceDays - r.dryDays() + 1} يوم قبل أن تبدأ بخصم العملات',
                  style: TextStyle(color: C.sub, fontSize: 12),
                ),
                const SizedBox(height: 10),
                FilledButton.icon(
                  onPressed: () {
                    Navigator.pop(ctx);
                    if (s.waterPlant(r)) {
                      _snack('سُقيت ${p.name} 💦');
                    } else {
                      _snack('لا توجد قطرات ماء. أنجز مهمة أو جلسة تركيز لتكسب الماء 💧');
                    }
                  },
                  icon: const Icon(Icons.water_drop),
                  label: Text('اسقِ (💧 ${s.water})'),
                ),
              ],
            ] else if (r.alive) ...[
              const SizedBox(height: 10),
              Text('شجرة ناضجة — لا تحتاج سقياً 🌳', style: TextStyle(color: C.sub, fontSize: 12)),
            ],
          ],
        ),
      ),
    );
  }
}
