import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'notif_service.dart';
import 'store.dart';
import 'theme.dart';

Future<void> showSettingsSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (ctx) {
      final s = StoreScope.of(ctx);
      return Padding(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('الإعدادات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              Text('المظهر', style: TextStyle(color: C.sub)),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: SegmentedButton<int>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(value: 0, label: Text('تلقائي'), icon: Icon(Icons.brightness_auto)),
                    ButtonSegment(value: 1, label: Text('نهاري'), icon: Icon(Icons.light_mode)),
                    ButtonSegment(value: 2, label: Text('ليلي'), icon: Icon(Icons.dark_mode)),
                  ],
                  selected: {s.themeMode},
                  onSelectionChanged: (v) => s.setThemeMode(v.first),
                ),
              ),
              const SizedBox(height: 8),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: s.strict,
                onChanged: s.setStrict,
                title: const Text('وضع الصرامة'),
                subtitle: Text('تذبل الشجرة إن غادرت التطبيق أكثر من 8 ثوانٍ',
                    style: TextStyle(fontSize: 12, color: C.sub)),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: s.lowPower,
                onChanged: s.setLowPower,
                title: const Text('وضع الأداء المنخفض'),
                subtitle: Text('تفاصيل أقل في الأشجار للهواتف الضعيفة',
                    style: TextStyle(fontSize: 12, color: C.sub)),
              ),
              const Divider(height: 24),
              const Text('الإشعارات', style: TextStyle(fontWeight: FontWeight.w800)),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: s.notifSession,
                onChanged: (v) {
                  s.setNotif(session: v);
                  NotifService.sync(s);
                },
                title: const Text('تنبيه عند انتهاء الجلسة'),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: s.notifDaily,
                onChanged: (v) {
                  s.setNotif(daily: v);
                  NotifService.sync(s);
                },
                title: const Text('تذكير يومي بالدراسة'),
                subtitle: Text(
                  'الساعة ${s.dailyHour.toString().padLeft(2, '0')}:${s.dailyMinute.toString().padLeft(2, '0')}',
                  style: TextStyle(fontSize: 12, color: C.sub),
                ),
              ),
              if (s.notifDaily)
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: TextButton.icon(
                    onPressed: () async {
                      final t = await showTimePicker(
                        context: ctx,
                        initialTime: TimeOfDay(hour: s.dailyHour, minute: s.dailyMinute),
                      );
                      if (t != null) {
                        s.setNotif(hour: t.hour, minute: t.minute);
                        NotifService.sync(s);
                      }
                    },
                    icon: const Icon(Icons.schedule),
                    label: const Text('تغيير وقت التذكير'),
                  ),
                ),
              const Divider(height: 24),
              const Text('النسخ الاحتياطي', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text('يشمل المخطط والغابة والعملات والامتحانات (بدون مفتاح الـAPI).',
                  style: TextStyle(fontSize: 12, color: C.sub)),
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () async {
                        await Clipboard.setData(ClipboardData(text: s.exportBackup()));
                        if (ctx.mounted) {
                          ScaffoldMessenger.of(ctx).showSnackBar(
                            const SnackBar(content: Text('نُسخت النسخة الاحتياطية. الصقها في ملاحظات أو رسالة تحفظها.')),
                          );
                        }
                      },
                      icon: const Icon(Icons.copy),
                      label: const Text('نسخ'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _restore(ctx, s),
                      icon: const Icon(Icons.restore),
                      label: const Text('استعادة'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              TextButton.icon(
                onPressed: () {
                  s.onboarded = false;
                  s.pokeTheme();
                  Navigator.pop(ctx);
                },
                icon: const Icon(Icons.slideshow),
                label: const Text('إعادة عرض شاشة الترحيب'),
              ),
            ],
          ),
        ),
      );
    },
  );
}

Future<void> _restore(BuildContext context, AppStore s) async {
  final ctl = TextEditingController();
  final clip = await Clipboard.getData(Clipboard.kTextPlain);
  if (clip?.text != null && clip!.text!.contains('"app"')) ctl.text = clip.text!;
  if (!context.mounted) return;
  String? err;
  await showDialog<void>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('استعادة نسخة احتياطية'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('سيُستبدل كل ما في التطبيق حالياً بمحتوى النسخة.',
                  style: TextStyle(color: C.danger, fontSize: 12.5)),
              const SizedBox(height: 10),
              TextField(
                controller: ctl,
                maxLines: 6,
                decoration: fieldDeco('الصق النص هنا'),
              ),
              if (err != null) ...[
                const SizedBox(height: 8),
                Text(err!, style: TextStyle(color: C.danger, fontSize: 12.5)),
              ],
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              final e = s.importBackup(ctl.text);
              if (e == null) {
                NotifService.sync(s);
                Navigator.pop(ctx);
              } else {
                set(() => err = e);
              }
            },
            child: const Text('استعادة'),
          ),
        ],
      ),
    ),
  );
}
