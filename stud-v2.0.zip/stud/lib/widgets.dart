import 'package:flutter/material.dart';
import 'models.dart';
import 'theme.dart';

/// شريط أيام الأسبوع (الأحد..السبت)
class DayChips extends StatelessWidget {
  final int selected;
  final ValueChanged<int> onTap;
  final int Function(int day)? badge;
  const DayChips({super.key, required this.selected, required this.onTap, this.badge});

  @override
  Widget build(BuildContext context) {
    final today = weekdayIndex(DateTime.now());
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 13),
      child: Row(
        children: [
          for (var i = 0; i < 7; i++)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: GestureDetector(
                  onTap: () => onTap(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: i == selected ? C.accent : C.surface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: i == today && i != selected ? C.accent.withValues(alpha: 0.6) : Colors.transparent,
                      ),
                    ),
                    child: Column(
                      children: [
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            dayShort[i],
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: i == selected ? C.onAccent : C.text,
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          badge == null ? (i == today ? '•' : ' ') : '${badge!(i)}',
                          style: TextStyle(
                            fontSize: 12,
                            color: i == selected ? C.onAccent : C.sub,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
