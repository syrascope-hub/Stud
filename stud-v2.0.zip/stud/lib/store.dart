import 'dart:convert';
import 'dart:math';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

class ActiveSession {
  final String type;
  int startMs;
  final int minutes;
  final String? subjectId;
  int? pausedAtMs; // غير null أثناء الإيقاف المؤقت
  bool pauseUsed;
  ActiveSession({
    required this.type,
    required this.startMs,
    required this.minutes,
    this.subjectId,
    this.pausedAtMs,
    this.pauseUsed = false,
  });
  int get endMs => startMs + minutes * 60000;
  Map<String, dynamic> toJson() => {
        'type': type,
        'startMs': startMs,
        'minutes': minutes,
        'subjectId': subjectId,
        'pausedAtMs': pausedAtMs,
        'pauseUsed': pauseUsed,
      };
  factory ActiveSession.fromJson(Map<String, dynamic> j) => ActiveSession(
        type: j['type'] as String,
        startMs: j['startMs'] as int,
        minutes: j['minutes'] as int,
        subjectId: j['subjectId'] as String?,
        pausedAtMs: j['pausedAtMs'] as int?,
        pauseUsed: (j['pauseUsed'] ?? false) as bool,
      );
}

class ChatMsg {
  final bool user;
  final String text;
  final List<String> changes;
  ChatMsg(this.user, this.text, [this.changes = const []]);
  Map<String, dynamic> toJson() => {'user': user, 'text': text, 'changes': changes};
  factory ChatMsg.fromJson(Map<String, dynamic> j) => ChatMsg(
        j['user'] as bool,
        j['text'] as String,
        ((j['changes'] ?? []) as List).map((e) => '$e').toList(),
      );
}

class FocusPreset {
  final String? subjectId;
  final int? minutes;
  const FocusPreset({this.subjectId, this.minutes});
}

class AppStore extends ChangeNotifier {
  late SharedPreferences _p;
  List<Subject> subjects = [];
  List<PlanItem> plan = [];
  List<PlantRecord> plants = [];
  Set<String> done = {};
  ActiveSession? active;
  String apiKey = '';
  String model = 'openai/gpt-4o-mini';
  bool strict = true;
  bool lowPower = true;
  int themeMode = 0; // 0 تلقائي، 1 فاتح، 2 داكن
  bool onboarded = false;
  int coins = 0;
  Set<String> unlocked = {'oak', 'pine', 'bush'};
  String sound = 'none';
  int water = 0; // قطرات الماء المتاحة للسقي
  Set<String> waterAwarded = {};
  Set<String> claimed = {};
  int breakStartMs = 0;
  int breakMinutes = 0;
  List<Notebook> notebooks = [];
  List<NoteEntry> notes = [];
  Set<String> decor = {};
  List<ExamRun> examRuns = [];
  String reviewDate = '';
  int reviewCount = 0;
  bool notifWeekly = true;
  bool perSubjectPlant = false;
  bool pauseEnabled = true;
  int soundVol = 60;
  List<Exam> exams = [];
  bool notifSession = true;
  bool notifDaily = true;
  int dailyHour = 18;
  int dailyMinute = 0;
  List<ChatMsg> chat = [];
  int tab = 1;
  FocusPreset? preset;
  String? _undo;
  final _rnd = Random();

  bool get canUndo => _undo != null;
  String get currentWeekKey => dateKey(weekStartOf(DateTime.now()));

  // ---------- load / save ----------
  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    try {
      final s = _p.getString('subjects');
      subjects = s == null
          ? _defaultSubjects()
          : (jsonDecode(s) as List).map((e) => Subject.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      final pl = _p.getString('plan');
      plan = pl == null
          ? _defaultPlan()
          : (jsonDecode(pl) as List).map((e) => PlanItem.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      final pn = _p.getString('plants');
      plants = pn == null
          ? []
          : (jsonDecode(pn) as List).map((e) => PlantRecord.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      done = (_p.getStringList('done') ?? []).toSet();
      final a = _p.getString('active');
      active = a == null ? null : ActiveSession.fromJson(Map<String, dynamic>.from(jsonDecode(a) as Map));
      apiKey = _p.getString('apiKey') ?? '';
      model = _p.getString('model') ?? model;
      strict = _p.getBool('strict') ?? true;
      lowPower = _p.getBool('lowPower') ?? true;
      themeMode = _p.getInt('themeMode') ?? 0;
      onboarded = _p.getBool('onboarded') ?? false;
      coins = _p.getInt('coins') ?? 0;
      unlocked = (_p.getStringList('unlocked') ?? ['oak', 'pine', 'bush']).toSet();
      sound = _p.getString('sound') ?? 'none';
      water = _p.getInt('water') ?? 0;
      waterAwarded = (_p.getStringList('waterAwarded') ?? []).toSet();
      claimed = (_p.getStringList('claimed') ?? []).toSet();
      breakStartMs = _p.getInt('breakStartMs') ?? 0;
      breakMinutes = _p.getInt('breakMinutes') ?? 0;
      final nb = _p.getString('notebooks');
      notebooks = nb == null
          ? _defaultNotebooks()
          : (jsonDecode(nb) as List).map((e) => Notebook.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      final nt = _p.getString('notes');
      notes = nt == null
          ? []
          : (jsonDecode(nt) as List).map((e) => NoteEntry.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      final ex = _p.getString('exams');
      exams = ex == null
          ? _defaultExams()
          : (jsonDecode(ex) as List).map((e) => Exam.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      notifSession = _p.getBool('notifSession') ?? true;
      notifDaily = _p.getBool('notifDaily') ?? true;
      dailyHour = _p.getInt('dailyHour') ?? 18;
      dailyMinute = _p.getInt('dailyMinute') ?? 0;
      decor = (_p.getStringList('decor') ?? []).toSet();
      final er = _p.getString('examRuns');
      examRuns = er == null
          ? []
          : (jsonDecode(er) as List).map((e) => ExamRun.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      reviewDate = _p.getString('reviewDate') ?? '';
      reviewCount = _p.getInt('reviewCount') ?? 0;
      notifWeekly = _p.getBool('notifWeekly') ?? true;
      perSubjectPlant = _p.getBool('perSubjectPlant') ?? false;
      pauseEnabled = _p.getBool('pauseEnabled') ?? true;
      soundVol = _p.getInt('soundVol') ?? 60;
      final c = _p.getString('chat');
      chat = c == null
          ? []
          : (jsonDecode(c) as List).map((e) => ChatMsg.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) {
      subjects = _defaultSubjects();
      plan = _defaultPlan();
      plants = [];
      done = {};
      active = null;
      exams = _defaultExams();
      notebooks = _defaultNotebooks();
      notes = [];
    }
    if (notebooks.isEmpty) notebooks = _defaultNotebooks();
    applyThirst();
  }

  Future<void> _save() async {
    try {
      await _p.setString('subjects', jsonEncode(subjects.map((e) => e.toJson()).toList()));
      await _p.setString('plan', jsonEncode(plan.map((e) => e.toJson()).toList()));
      await _p.setString('plants', jsonEncode(plants.map((e) => e.toJson()).toList()));
      await _p.setStringList('done', done.toList());
      if (active == null) {
        await _p.remove('active');
      } else {
        await _p.setString('active', jsonEncode(active!.toJson()));
      }
      await _p.setString('apiKey', apiKey);
      await _p.setString('model', model);
      await _p.setBool('strict', strict);
      await _p.setBool('lowPower', lowPower);
      await _p.setInt('themeMode', themeMode);
      await _p.setBool('onboarded', onboarded);
      await _p.setInt('coins', coins);
      await _p.setStringList('unlocked', unlocked.toList());
      await _p.setString('sound', sound);
      await _p.setInt('water', water);
      await _p.setStringList('waterAwarded', waterAwarded.toList());
      await _p.setStringList('claimed', claimed.toList());
      await _p.setInt('breakStartMs', breakStartMs);
      await _p.setInt('breakMinutes', breakMinutes);
      await _p.setString('notebooks', jsonEncode(notebooks.map((e) => e.toJson()).toList()));
      await _p.setString('notes', jsonEncode(notes.map((e) => e.toJson()).toList()));
      await _p.setString('exams', jsonEncode(exams.map((e) => e.toJson()).toList()));
      await _p.setBool('notifSession', notifSession);
      await _p.setBool('notifDaily', notifDaily);
      await _p.setInt('dailyHour', dailyHour);
      await _p.setInt('dailyMinute', dailyMinute);
      await _p.setStringList('decor', decor.toList());
      await _p.setString('examRuns', jsonEncode(examRuns.map((e) => e.toJson()).toList()));
      await _p.setString('reviewDate', reviewDate);
      await _p.setInt('reviewCount', reviewCount);
      await _p.setBool('notifWeekly', notifWeekly);
      await _p.setBool('perSubjectPlant', perSubjectPlant);
      await _p.setBool('pauseEnabled', pauseEnabled);
      await _p.setInt('soundVol', soundVol);
      final tail = chat.length > 40 ? chat.sublist(chat.length - 40) : chat;
      await _p.setString('chat', jsonEncode(tail.map((e) => e.toJson()).toList()));
    } catch (_) {}
  }

  void _commit() {
    notifyListeners();
    _save();
  }

  String _id() => '${DateTime.now().microsecondsSinceEpoch}${_rnd.nextInt(999)}';

  // ---------- navigation ----------
  void setTab(int i) {
    tab = i;
    notifyListeners();
  }

  void startFocusFor(PlanItem item) {
    preset = FocusPreset(subjectId: item.subjectId, minutes: min(item.minutes, 50));
    setTab(1);
  }

  // ---------- subjects & plan ----------
  Subject subjectById(String id) => subjects.firstWhere(
        (s) => s.id == id,
        orElse: () => subjects.isNotEmpty
            ? subjects.first
            : Subject(id: 'x', name: 'مادة', emoji: '📘', color: 0xFF90A4AE),
      );

  List<PlanItem> itemsForDay(int d) => plan.where((e) => e.day == d).toList();
  int plannedMinutes(int d) => itemsForDay(d).fold(0, (a, b) => a + b.minutes);
  int doneMinutes(int d, String wk) =>
      itemsForDay(d).where((e) => isDone(e, wk)).fold(0, (a, b) => a + b.minutes);
  bool isDone(PlanItem i, String wk) => done.contains('$wk:${i.id}');

  /// يعيد عدد قطرات الماء الجديدة (0 إن لم تُمنح)
  int toggleDone(PlanItem i, String wk) {
    final k = '$wk:${i.id}';
    var gained = 0;
    if (!done.remove(k)) {
      done.add(k);
      if (waterAwarded.add(k)) {
        gained = 1 + i.minutes ~/ 60;
        water += gained;
      }
    }
    _commit();
    return gained;
  }

  void addItem({required int day, required String subjectId, required String title, required int minutes}) {
    plan.add(PlanItem(id: _id(), day: day, subjectId: subjectId, title: title, minutes: minutes));
    _commit();
  }

  void updateItem(PlanItem i, {int? day, String? subjectId, String? title, int? minutes}) {
    if (day != null) i.day = day;
    if (subjectId != null) i.subjectId = subjectId;
    if (title != null) i.title = title;
    if (minutes != null) i.minutes = minutes;
    _commit();
  }

  void removeItem(PlanItem i) {
    plan.removeWhere((e) => e.id == i.id);
    _commit();
  }

  // ---------- plants & sessions ----------
  List<PlantRecord> plantsFor(String weekKey, int day) =>
      plants.where((p) => p.weekKey == weekKey && p.day == day).toList();

  List<double> nextPosition(String weekKey, int day) {
    final ex = plantsFor(weekKey, day);
    double best = -1, bx = 0, bz = 0;
    for (var i = 0; i < 70; i++) {
      final a = _rnd.nextDouble() * 2 * pi;
      final d = sqrt(_rnd.nextDouble()) * 2.6;
      final x = cos(a) * d, z = sin(a) * d;
      double md = 99;
      for (final p in ex) {
        final dx = p.x - x, dz = p.z - z;
        md = min(md, sqrt(dx * dx + dz * dz));
      }
      if (ex.isEmpty) md = 5 - d;
      if (md > best) {
        best = md;
        bx = x;
        bz = z;
      }
    }
    return [bx, bz];
  }

  void startSession(String type, int minutes, String? subjectId) {
    active = ActiveSession(
      type: type,
      startMs: DateTime.now().millisecondsSinceEpoch,
      minutes: minutes,
      subjectId: subjectId,
    );
    _commit();
  }

  PlantRecord? finishSession(bool alive) {
    final a = active;
    if (a == null) return null;
    final start = DateTime.fromMillisecondsSinceEpoch(a.startMs);
    final wk = dateKey(weekStartOf(start));
    final day = weekdayIndex(start);
    final pos = nextPosition(wk, day);
    final rec = PlantRecord(
      id: _id(),
      weekKey: wk,
      day: day,
      type: a.type,
      minutes: a.minutes,
      alive: alive,
      x: pos[0],
      z: pos[1],
      seed: _rnd.nextInt(100000),
      ts: DateTime.now().millisecondsSinceEpoch,
      subjectId: a.subjectId,
    );
    plants.add(rec);
    if (alive) {
      final goldenToday = plants.any((p) => p.golden && p.weekKey == wk && p.day == day);
      if (a.minutes >= 90 || (streak() >= 7 && !goldenToday)) rec.golden = true;
    }
    if (alive) {
      coins += a.minutes;
      water += (a.minutes ~/ 10).clamp(1, 12).toInt();
    }
    active = null;
    _commit();
    return rec;
  }

  int aliveTodayCount() {
    final now = DateTime.now();
    final wk = dateKey(weekStartOf(now));
    return plantsFor(wk, weekdayIndex(now)).where((p) => p.alive).length;
  }

  // ---------- notebooks ----------
  List<NoteEntry> notesOf(String notebookId) => notes.where((n) => n.notebookId == notebookId).toList();

  String addNotebook(String name, String emoji) {
    final id = _id();
    notebooks.add(Notebook(
      id: id,
      name: name.trim().isEmpty ? 'دفتر جديد' : name.trim(),
      emoji: emoji.trim().isEmpty ? '📓' : emoji.trim(),
    ));
    _commit();
    return id;
  }

  void updateNotebook(Notebook b, String name, String emoji) {
    if (name.trim().isNotEmpty) b.name = name.trim();
    if (emoji.trim().isNotEmpty) b.emoji = emoji.trim();
    _commit();
  }

  /// يحذف الدفتر وكل إدخالاته (لا يُسمح بحذف آخر دفتر)
  bool removeNotebook(Notebook b) {
    if (notebooks.length <= 1) return false;
    notes.removeWhere((n) => n.notebookId == b.id);
    notebooks.removeWhere((x) => x.id == b.id);
    _commit();
    return true;
  }

  void saveNote({
    NoteEntry? note,
    required String notebookId,
    required String kind,
    required String title,
    required String body,
    required String fix,
    required String chapter,
    List<String>? images,
  }) {
    if (title.trim().isEmpty && body.trim().isEmpty && (images == null || images.isEmpty)) return;
    if (note == null) {
      notes.add(NoteEntry(
        id: _id(),
        notebookId: notebookId,
        kind: kind,
        title: title.trim(),
        body: body.trim(),
        fix: fix.trim(),
        chapter: chapter.trim(),
        ts: DateTime.now().millisecondsSinceEpoch,
        images: images,
      ));
    } else {
      note.kind = kind;
      note.title = title.trim();
      note.body = body.trim();
      note.fix = fix.trim();
      note.chapter = chapter.trim();
      if (images != null) note.images = images;
    }
    _commit();
  }

  void toggleStar(NoteEntry n) {
    n.starred = !n.starred;
    _commit();
  }

  void removeNote(NoteEntry n) {
    notes.removeWhere((x) => x.id == n.id);
    _commit();
  }

  // ---------- breaks (Pomodoro) ----------
  int get breakEndMs => breakStartMs + breakMinutes * 60000;
  bool get breakActive => breakMinutes > 0 && DateTime.now().millisecondsSinceEpoch < breakEndMs;

  /// بعد كل 4 جلسات في اليوم تكون الاستراحة طويلة (15 د)، وإلا 5 د
  int suggestedBreak() {
    final n = aliveTodayCount();
    return (n > 0 && n % 4 == 0) ? 15 : 5;
  }

  void startBreak(int minutes) {
    breakStartMs = DateTime.now().millisecondsSinceEpoch;
    breakMinutes = minutes;
    _commit();
  }

  void endBreak() {
    breakStartMs = 0;
    breakMinutes = 0;
    _commit();
  }

  /// عدد التحديات الجاهزة للاستلام الآن
  int get claimableChallenges =>
      dailyChallenges.where((c) => !isClaimed(c) && challengeProgress(c) >= c.target).length;

  // ---------- daily challenges ----------
  int focusMinutesToday() {
    final now = DateTime.now();
    return plantsFor(currentWeekKey, weekdayIndex(now)).where((p) => p.alive).fold(0, (a, b) => a + b.minutes);
  }

  int tasksDoneToday() {
    final d = weekdayIndex(DateTime.now());
    return itemsForDay(d).where((i) => isDone(i, currentWeekKey)).length;
  }

  int challengeProgress(Challenge c) {
    switch (c.id) {
      case 'focus60':
        return focusMinutesToday();
      case 'sessions3':
        return aliveTodayCount();
      case 'tasks3':
        return tasksDoneToday();
      case 'review3':
        return reviewedToday;
    }
    return 0;
  }

  String _ck(Challenge c) => '${dateKey(DateTime.now())}:${c.id}';
  bool isClaimed(Challenge c) => claimed.contains(_ck(c));

  bool claimChallenge(Challenge c) {
    if (isClaimed(c) || challengeProgress(c) < c.target) return false;
    final today = dateKey(DateTime.now());
    claimed.removeWhere((k) => !k.startsWith(today));
    claimed.add(_ck(c));
    coins += c.coins;
    water += c.water;
    _commit();
    return true;
  }

  // ---------- watering ----------
  List<PlantRecord> get thirstyPlants => plants.where((p) => p.needsWater()).toList();

  bool waterPlant(PlantRecord r) {
    if (water < 1 || !r.needsWater()) return false;
    water -= 1;
    r.lastWatered = DateTime.now().millisecondsSinceEpoch;
    r.charged = 0;
    r.waterCount += 1;
    _commit();
    return true;
  }

  /// يسقي أكثر الأشجار عطشاً أولاً بقدر ما يتوفر من قطرات. يعيد عدد ما سُقي.
  int waterAll() {
    final list = thirstyPlants..sort((a, b) => b.dryDays().compareTo(a.dryDays()));
    var n = 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    for (final r in list) {
      if (water < 1) break;
      water -= 1;
      r.lastWatered = now;
      r.charged = 0;
      r.waterCount += 1;
      n++;
    }
    if (n > 0) _commit();
    return n;
  }

  /// يخصم جزءاً من العملات عن الأشجار الجافة. يعيد مجموع المخصوم.
  int applyThirst() {
    var lost = 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    for (final r in plants) {
      if (!r.isSeedling(now)) continue;
      final chargeable = (r.dryDays(now) - PlantRecord.graceDays).clamp(0, PlantRecord.maxChargedDays).toInt();
      if (chargeable > r.charged) {
        final pen = (chargeable - r.charged) * r.penaltyPerDay;
        final real = pen > coins ? coins : pen;
        coins -= real;
        lost += real;
        r.charged = chargeable;
      }
    }
    if (lost > 0) _commit();
    return lost;
  }

  /// إحياء شجرة ذابلة مقابل 5 قطرات و20 عملة
  static const reviveWater = 5;
  static const reviveCoins = 20;

  bool revivePlant(PlantRecord r) {
    if (r.alive || water < reviveWater || coins < reviveCoins) return false;
    water -= reviveWater;
    coins -= reviveCoins;
    r.alive = true;
    r.lastWatered = DateTime.now().millisecondsSinceEpoch;
    r.charged = 0;
    _commit();
    return true;
  }

  // ---------- decor ----------
  bool buyDecor(String id) {
    if (decor.contains(id)) return true;
    final it = decorItems.firstWhere((d) => d.id == id);
    if (coins < it.price) return false;
    coins -= it.price;
    decor.add(id);
    _commit();
    return true;
  }

  // ---------- pause ----------
  static const maxPauseMs = 300000;
  bool get isPaused => active?.pausedAtMs != null;
  bool get canPause => active != null && pauseEnabled && !isPaused && !(active!.pauseUsed);

  void pauseSession() {
    final a = active;
    if (a == null || !canPause) return;
    a.pausedAtMs = DateTime.now().millisecondsSinceEpoch;
    a.pauseUsed = true;
    _commit();
  }

  void resumeSession() {
    final a = active;
    final p = a?.pausedAtMs;
    if (a == null || p == null) return;
    final dur = (DateTime.now().millisecondsSinceEpoch - p).clamp(0, maxPauseMs).toInt();
    a.startMs += dur;
    a.pausedAtMs = null;
    _commit();
  }

  /// يستأنف تلقائياً إذا تجاوز الإيقاف 5 دقائق
  bool autoResumeIfExpired() {
    final p = active?.pausedAtMs;
    if (p == null) return false;
    if (DateTime.now().millisecondsSinceEpoch - p >= maxPauseMs) {
      resumeSession();
      return true;
    }
    return false;
  }

  // ---------- spaced review of mistakes ----------
  static const _intervals = [1, 3, 7, 14, 30];

  List<NoteEntry> reviewDue() {
    final now = DateTime.now().millisecondsSinceEpoch;
    final l = notes.where((n) => n.kind == 'mistake' && n.nextReview <= now).toList()
      ..sort((a, b) => a.nextReview.compareTo(b.nextReview));
    return l;
  }

  int get reviewedToday => reviewDate == dateKey(DateTime.now()) ? reviewCount : 0;

  void markReview(NoteEntry n, bool ok) {
    final now = DateTime.now();
    if (ok) {
      n.box = (n.box + 1).clamp(1, 5).toInt();
      n.nextReview = now.millisecondsSinceEpoch + _intervals[n.box - 1] * 86400000;
    } else {
      n.box = 0;
      n.nextReview = now.millisecondsSinceEpoch + 86400000;
    }
    final today = dateKey(now);
    if (reviewDate != today) {
      reviewDate = today;
      reviewCount = 0;
    }
    reviewCount += 1;
    _commit();
  }

  // ---------- exam runs ----------
  void addExamRun({
    required String name,
    required int plannedMin,
    required int usedMin,
    required double score,
    required double max,
  }) {
    examRuns.add(ExamRun(
      id: _id(),
      name: name.trim().isEmpty ? 'دورة امتحانية' : name.trim(),
      plannedMin: plannedMin,
      usedMin: usedMin,
      score: score,
      max: max <= 0 ? 100 : max,
      ts: DateTime.now().millisecondsSinceEpoch,
    ));
    _commit();
  }

  void removeExamRun(ExamRun r) {
    examRuns.removeWhere((x) => x.id == r.id);
    _commit();
  }

  // ---------- sounds (mix) ----------
  Set<String> get soundSet => sound.split(',').where((e) => e.isNotEmpty && e != 'none').toSet();

  void toggleSound(String id) {
    final set = soundSet;
    if (id == 'none') {
      set.clear();
    } else if (!set.remove(id)) {
      set.add(id);
    }
    sound = set.isEmpty ? 'none' : set.join(',');
    _commit();
  }

  void setSoundVolLive(int v) {
    soundVol = v.clamp(10, 100).toInt();
    notifyListeners();
  }

  void setSoundVol(int v) {
    soundVol = v.clamp(10, 100).toInt();
    _commit();
  }

  // ---------- exams ----------
  List<Exam> get sortedExams => [...exams]..sort((a, b) => a.dateMs.compareTo(b.dateMs));

  /// آخر امتحان (الأبعد تاريخاً)
  Exam? get lastExam => exams.isEmpty ? null : sortedExams.last;

  /// أقرب امتحان لم يمضِ بعد
  Exam? get nextExam {
    for (final e in sortedExams) {
      if (e.daysLeft() >= 0) return e;
    }
    return null;
  }

  void saveExam({Exam? exam, required String name, required DateTime date, bool estimated = false}) {
    final ms = DateTime(date.year, date.month, date.day).millisecondsSinceEpoch;
    if (exam == null) {
      exams.add(Exam(id: _id(), name: name.trim().isEmpty ? 'امتحان' : name.trim(), dateMs: ms, estimated: estimated));
    } else {
      exam.name = name.trim().isEmpty ? exam.name : name.trim();
      exam.dateMs = ms;
      exam.estimated = estimated;
    }
    _commit();
  }

  void removeExam(Exam e) {
    exams.removeWhere((x) => x.id == e.id);
    _commit();
  }

  // ---------- subjects ----------
  void saveSubject({Subject? subject, required String name, required String emoji, required int color}) {
    final n = name.trim();
    if (n.isEmpty) return;
    final em = emoji.trim().isEmpty ? '📘' : emoji.trim();
    if (subject == null) {
      subjects.add(Subject(id: _id(), name: n, emoji: em, color: color));
    } else {
      subject.name = n;
      subject.emoji = em;
      subject.color = color;
    }
    _commit();
  }

  int itemsUsingSubject(String id) => plan.where((p) => p.subjectId == id).length;

  /// يحذف المادة. إن كانت عليها مهام تُنقل إلى [moveTo] أو تُحذف المهام إن لم يُحدَّد.
  void removeSubject(Subject sub, {String? moveTo}) {
    if (moveTo != null) {
      for (final p in plan.where((p) => p.subjectId == sub.id)) {
        p.subjectId = moveTo;
      }
    } else {
      plan.removeWhere((p) => p.subjectId == sub.id);
    }
    subjects.removeWhere((x) => x.id == sub.id);
    _commit();
  }

  // ---------- backup ----------
  String exportBackup() => JsonEncoder.withIndent(' ').convert({
        'app': 'stud',
        'version': 2,
        'subjects': subjects.map((e) => e.toJson()).toList(),
        'plan': plan.map((e) => e.toJson()).toList(),
        'plants': plants.map((e) => e.toJson()).toList(),
        'done': done.toList(),
        'coins': coins,
        'water': water,
        'waterAwarded': waterAwarded.toList(),
        'unlocked': unlocked.toList(),
        'exams': exams.map((e) => e.toJson()).toList(),
        'notebooks': notebooks.map((e) => e.toJson()).toList(),
        'notes': notes.map((e) {
          final j = e.toJson();
          j['images'] = <String>[];
          return j;
        }).toList(),
        'decor': decor.toList(),
        'examRuns': examRuns.map((e) => e.toJson()).toList(),
        'sound': sound,
        'themeMode': themeMode,
        'strict': strict,
        'lowPower': lowPower,
      });

  /// يستعيد نسخة احتياطية. يعيد null عند النجاح أو رسالة الخطأ.
  String? importBackup(String text) {
    try {
      final m = jsonDecode(text.trim());
      if (m is! Map || m['app'] != 'stud') return 'هذا النص ليس نسخة احتياطية من Stud';
      List<T> list<T>(String k, T Function(Map<String, dynamic>) f) =>
          ((m[k] ?? []) as List).map((e) => f(Map<String, dynamic>.from(e as Map))).toList();
      final subs = list('subjects', Subject.fromJson);
      final pl = list('plan', PlanItem.fromJson);
      final pn = list('plants', PlantRecord.fromJson);
      final ex = list('exams', Exam.fromJson);
      final nbs = list('notebooks', Notebook.fromJson);
      final nts = list('notes', NoteEntry.fromJson);
      final ers = list('examRuns', ExamRun.fromJson);
      subjects = subs;
      plan = pl;
      plants = pn;
      exams = ex;
      notebooks = nbs.isEmpty ? _defaultNotebooks() : nbs;
      notes = nts;
      examRuns = ers;
      decor = ((m['decor'] ?? []) as List).map((e) => '$e').toSet();
      done = ((m['done'] ?? []) as List).map((e) => '$e').toSet();
      coins = (m['coins'] ?? 0) as int;
      water = (m['water'] ?? 0) as int;
      waterAwarded = ((m['waterAwarded'] ?? []) as List).map((e) => '$e').toSet();
      unlocked = ((m['unlocked'] ?? ['oak', 'pine', 'bush']) as List).map((e) => '$e').toSet();
      sound = (m['sound'] ?? 'none') as String;
      themeMode = (m['themeMode'] ?? 0) as int;
      strict = (m['strict'] ?? true) as bool;
      lowPower = (m['lowPower'] ?? true) as bool;
      active = null;
      _commit();
      return null;
    } catch (_) {
      return 'تعذّرت قراءة النسخة الاحتياطية. تأكد من نسخ النص كاملاً.';
    }
  }

  // ---------- notifications settings ----------
  void setNotif({bool? session, bool? daily, int? hour, int? minute, bool? weekly}) {
    if (weekly != null) notifWeekly = weekly;
    if (session != null) notifSession = session;
    if (daily != null) notifDaily = daily;
    if (hour != null) dailyHour = hour;
    if (minute != null) dailyMinute = minute;
    _commit();
  }

  // ---------- settings ----------
  void setApi({String? key, String? mdl}) {
    if (key != null) apiKey = key.trim();
    if (mdl != null && mdl.trim().isNotEmpty) model = mdl.trim();
    _commit();
  }

  void setThemeMode(int m) {
    themeMode = m;
    _commit();
  }

  /// يُستدعى عند تغيّر سطوع النظام ليعاد بناء الواجهة
  void pokeTheme() => notifyListeners();

  void finishOnboarding() {
    onboarded = true;
    _commit();
  }

  void setSound(String id) {
    sound = id;
    _commit();
  }

  bool buyPlant(String id) {
    final t = plantById(id);
    if (unlocked.contains(id)) return true;
    if (coins < t.price) return false;
    coins -= t.price;
    unlocked.add(id);
    _commit();
    return true;
  }

  /// عدد الأيام المتتالية (حتى اليوم) التي فيها شجرة حيّة على الأقل
  int streak() {
    final days = <String>{};
    for (final r in plants) {
      if (!r.alive) continue;
      final b = DateTime.parse(r.weekKey);
      days.add(dateKey(DateTime(b.year, b.month, b.day + r.day)));
    }
    var d = DateTime.now();
    var n = 0;
    if (!days.contains(dateKey(d))) d = DateTime(d.year, d.month, d.day - 1);
    while (days.contains(dateKey(d))) {
      n++;
      d = DateTime(d.year, d.month, d.day - 1);
    }
    return n;
  }

  void setPerSubjectPlant(bool v) {
    perSubjectPlant = v;
    _commit();
  }

  void setPauseEnabled(bool v) {
    pauseEnabled = v;
    _commit();
  }

  void setLowPower(bool v) {
    lowPower = v;
    _commit();
  }

  void setStrict(bool v) {
    strict = v;
    _commit();
  }

  // ---------- chat / AI ----------
  void addChat(ChatMsg m) {
    chat.add(m);
    _commit();
  }

  void clearChat() {
    chat = [];
    _commit();
  }

  Map<String, dynamic> _aiStatus() {
    final wk = currentWeekKey;
    var planned = 0, doneMin = 0;
    for (var d = 0; d < 7; d++) {
      planned += plannedMinutes(d);
      doneMin += doneMinutes(d, wk);
    }
    final mistakes = notes.where((n) => n.kind == 'mistake').toList()..sort((a, b) => b.ts.compareTo(a.ts));
    final runs = [...examRuns]..sort((a, b) => b.ts.compareTo(a.ts));
    return {
      'today': dayNames[weekdayIndex(DateTime.now())],
      'daysToLastExam': lastExam?.daysLeft(),
      'focusMinutesToday': focusMinutesToday(),
      'streakDays': streak(),
      'weekPlannedMinutes': planned,
      'weekDoneMinutes': doneMin,
      'recordedMistakes': mistakes
          .take(12)
          .map((n) => {'title': n.title, 'chapter': n.chapter, 'what': n.body, 'correct': n.fix})
          .toList(),
      'examRuns': runs.take(5).map((r) => {'name': r.name, 'percent': r.pct.round()}).toList(),
    };
  }

  String planForAi() => jsonEncode({
        'status': _aiStatus(),
        'days': {for (var i = 0; i < 7; i++) '$i': dayNames[i]},
        'subjects': subjects.map((s) => s.name).toList(),
        'items': plan
            .map((p) => {
                  'id': p.id,
                  'day': p.day,
                  'subject': subjectById(p.subjectId).name,
                  'title': p.title,
                  'minutes': p.minutes,
                })
            .toList(),
      });

  Map<String, dynamic> _snapshot() => {
        'subjects': subjects.map((e) => e.toJson()).toList(),
        'plan': plan.map((e) => e.toJson()).toList(),
        'done': done.toList(),
      };

  void undo() {
    final u = _undo;
    if (u == null) return;
    final m = jsonDecode(u) as Map<String, dynamic>;
    subjects = (m['subjects'] as List).map((e) => Subject.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    plan = (m['plan'] as List).map((e) => PlanItem.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    done = (m['done'] as List).map((e) => '$e').toSet();
    _undo = null;
    _commit();
  }

  int? _dayOf(dynamic v) {
    if (v is num) {
      final i = v.toInt();
      return (i >= 0 && i <= 6) ? i : null;
    }
    if (v is String) {
      final n = int.tryParse(v.trim());
      if (n != null) return (n >= 0 && n <= 6) ? n : null;
      final s = normAr(v);
      for (var i = 0; i < 7; i++) {
        final d = normAr(dayNames[i]);
        if (s == d || s.contains(d) || d.contains(s) && s.length > 2) return i;
      }
    }
    return null;
  }

  int _intOf(dynamic v, int def) {
    if (v is num) return v.toInt().clamp(5, 600);
    if (v is String) return (int.tryParse(v.trim()) ?? def).clamp(5, 600);
    return def;
  }

  Subject _subjectFor(dynamic name) {
    final s = normAr('${name ?? ''}');
    for (final x in subjects) {
      final n = normAr(x.name);
      if (n == s || (s.isNotEmpty && (n.contains(s) || s.contains(n)))) return x;
    }
    const palette = [0xFF4DB6AC, 0xFFFF8A65, 0xFF9575CD, 0xFFAED581, 0xFF4DD0E1, 0xFFFFD54F];
    final ns = Subject(
      id: _id(),
      name: '${name ?? 'مادة'}'.trim().isEmpty ? 'مادة' : '${name}'.trim(),
      emoji: '📘',
      color: palette[_rnd.nextInt(palette.length)],
    );
    subjects.add(ns);
    return ns;
  }

  PlanItem? _itemById(dynamic id) {
    for (final p in plan) {
      if (p.id == '$id') return p;
    }
    return null;
  }

  List<String> applyActions(List<dynamic> actions) {
    final before = jsonEncode(_snapshot());
    final out = <String>[];
    for (final a in actions) {
      if (a is! Map) continue;
      final op = '${a['op']}';
      try {
        if (op == 'add') {
          final d = _dayOf(a['day']);
          if (d == null) continue;
          final s = _subjectFor(a['subject']);
          final m = _intOf(a['minutes'], 60);
          final t = '${a['title'] ?? ''}'.trim();
          plan.add(PlanItem(id: _id(), day: d, subjectId: s.id, title: t, minutes: m));
          out.add('➕ ${dayNames[d]}: ${s.name} ${fmtMin(m)}');
        } else if (op == 'update' || op == 'move') {
          final it = _itemById(a['id']);
          if (it == null) continue;
          if (a['day'] != null) {
            final d = _dayOf(a['day']);
            if (d != null) it.day = d;
          }
          if (a['subject'] != null) it.subjectId = _subjectFor(a['subject']).id;
          if (a['title'] != null) it.title = '${a['title']}'.trim();
          if (a['minutes'] != null) it.minutes = _intOf(a['minutes'], it.minutes);
          out.add('✏️ ${dayNames[it.day]}: ${subjectById(it.subjectId).name} ${fmtMin(it.minutes)}');
        } else if (op == 'remove') {
          final it = _itemById(a['id']);
          if (it == null) continue;
          plan.removeWhere((e) => e.id == it.id);
          out.add('🗑️ حُذف: ${subjectById(it.subjectId).name} (${dayNames[it.day]})');
        } else if (op == 'clear_day') {
          final d = _dayOf(a['day']);
          if (d == null) continue;
          plan.removeWhere((e) => e.day == d);
          out.add('🧹 أُفرغ يوم ${dayNames[d]}');
        }
      } catch (_) {}
    }
    if (out.isNotEmpty) _undo = before;
    _commit();
    return out;
  }
}

class StoreScope extends InheritedNotifier<AppStore> {
  const StoreScope({super.key, required AppStore store, required super.child}) : super(notifier: store);
  static AppStore of(BuildContext c) => c.dependOnInheritedWidgetOfExactType<StoreScope>()!.notifier!;
  static AppStore read(BuildContext c) => c.getInheritedWidgetOfExactType<StoreScope>()!.notifier!;
}

List<Notebook> _defaultNotebooks() => [
      Notebook(id: 'math-ideas', name: 'أفكار الرياضيات', emoji: '📐'),
    ];

List<Exam> _defaultExams() => [
      Exam(
        id: 'bac-last',
        name: 'آخر امتحان بكالوريا',
        dateMs: DateTime(2027, 6, 28).millisecondsSinceEpoch,
        estimated: true,
      ),
    ];

List<Subject> _defaultSubjects() => [
      Subject(id: 'math', name: 'رياضيات', emoji: '📐', color: 0xFF4FC3F7),
      Subject(id: 'physics', name: 'فيزياء', emoji: '⚡', color: 0xFFFFB74D),
      Subject(id: 'chem', name: 'كيمياء', emoji: '🧪', color: 0xFFBA68C8),
      Subject(id: 'science', name: 'علوم', emoji: '🧬', color: 0xFF81C784),
      Subject(id: 'arabic', name: 'عربي', emoji: '📖', color: 0xFFE57373),
      Subject(id: 'english', name: 'إنكليزي', emoji: '🔤', color: 0xFF64B5F6),
      Subject(id: 'french', name: 'فرنسي', emoji: '🥖', color: 0xFFF06292),
      Subject(id: 'religion', name: 'ديانة', emoji: '🕌', color: 0xFFA1887F),
    ];

List<PlanItem> _defaultPlan() {
  var n = 0;
  PlanItem p(int d, String s, String t, int m) =>
      PlanItem(id: 'd${n++}', day: d, subjectId: s, title: t, minutes: m);
  return [
    p(0, 'math', '3 فيديوهات + حل تمارين', 180),
    p(0, 'physics', 'فيديوهان + حل', 150),
    p(0, 'science', 'درس جديد', 90),
    p(0, 'english', 'درس', 60),
    p(1, 'math', '3 فيديوهات + حل تمارين', 180),
    p(1, 'arabic', 'درس', 90),
    p(1, 'science', 'مراجعة', 60),
    p(1, 'english', 'درس', 60),
    p(1, 'french', 'درس', 60),
    p(1, 'chem', 'حل أسئلة', 30),
    p(2, 'math', '3 فيديوهات + حل تمارين', 150),
    p(2, 'physics', 'فيديوهان + حل', 120),
    p(2, 'chem', 'درس جديد', 90),
    p(2, 'science', 'درس', 60),
    p(2, 'arabic', 'درس', 60),
    p(3, 'math', '3 فيديوهات + حل تمارين', 180),
    p(3, 'chem', 'حل + مراجعة', 90),
    p(3, 'science', 'مراجعة', 60),
    p(3, 'arabic', 'درس', 60),
    p(3, 'religion', 'درس', 60),
    p(3, 'english', 'مراجعة', 30),
    p(4, 'math', '3 فيديوهات + حل تمارين', 180),
    p(4, 'physics', 'فيديوهان + حل', 150),
    p(4, 'chem', 'حل أسئلة', 60),
    p(4, 'french', 'درس', 60),
    p(4, 'english', 'درس', 30),
    p(5, 'math', 'حل دورة كاملة بوقت الامتحان', 180),
    p(5, 'math', 'تصحيح الدورة وتدوين الأخطاء', 60),
    p(5, 'physics', 'مراجعة', 30),
    p(5, 'chem', 'مراجعة', 30),
    p(5, 'science', 'مراجعات مختلفة', 60),
    p(6, 'math', '3 فيديوهات + حل تمارين', 180),
    p(6, 'physics', 'فيديوهان + حل', 120),
    p(6, 'arabic', 'درس', 90),
    p(6, 'chem', 'درس', 60),
    p(6, 'religion', 'درس', 30),
  ];
}
