import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'plant_models.dart';
import 'scene3d.dart';

/// دائرة المؤقت: قرص كريمي + حلقة تقدّم
class RingPainter extends CustomPainter {
  final double progress;
  const RingPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.shortestSide / 2 - 12;
    canvas.drawCircle(c, r, Paint()..color = const Color(0xFFE6E7A8));
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..color = const Color(0xFFCDCF86);
    canvas.drawCircle(c, r, ring);
    if (progress > 0) {
      final arc = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 14
        ..strokeCap = StrokeCap.round
        ..color = const Color(0xFF8CC63F);
      canvas.drawArc(Rect.fromCircle(center: c, radius: r), -math.pi / 2, 2 * math.pi * progress, false, arc);
      final a = -math.pi / 2 + 2 * math.pi * progress;
      canvas.drawCircle(Offset(c.dx + math.cos(a) * r, c.dy + math.sin(a) * r), 11, Paint()..color = const Color(0xFF8CC63F));
    }
  }

  @override
  bool shouldRepaint(covariant RingPainter old) => old.progress != progress;
}

/// وعاء تربة تنمو فيه نبتة (يُرسم داخل الدائرة)
class BowlPainter extends CustomPainter {
  final String type;
  final double growth;
  final double plantSize;
  final bool alive;
  final double t; // زمن للتمايل (0 = ثابتة)
  final double pop; // 0..1 قوة نبضة النمو + الشرارات
  final int sparkSeed;
  const BowlPainter({
    required this.type,
    required this.growth,
    this.plantSize = 1.0,
    this.alive = true,
    this.t = 0,
    this.pop = 0,
    this.sparkSeed = 0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final cam = Cam(yaw: 0.0, pitch: 0.14, unit: w / 5.8, center: Offset(w / 2, h * 0.70), dist: 18);
    final o = cam.proj(const V3(0, 0, 0)).o;
    final rw = w * 0.30;
    final body = Path()
      ..moveTo(o.dx - rw, o.dy)
      ..quadraticBezierTo(o.dx - rw * 0.9, o.dy + h * 0.17, o.dx, o.dy + h * 0.19)
      ..quadraticBezierTo(o.dx + rw * 0.9, o.dy + h * 0.17, o.dx + rw, o.dy)
      ..close();
    canvas.drawPath(body, Paint()..color = const Color(0xFF7B4220));
    canvas.drawOval(Rect.fromCenter(center: o, width: rw * 2, height: h * 0.075), Paint()..color = const Color(0xFF9A5A2B));
    // نبضة "ارتداد" مرنة تتلاشى مع الوقت
    final bounce = pop > 0 ? 1 + 0.14 * pop * math.sin((1 - pop) * 11 + 0.6) : 1.0;
    final s = Scene3D(cam, flat: true, lite: false);
    buildPlant(s, type, const V3(0, 0, 0),
        growth: growth, size: plantSize * bounce, seed: 7, alive: alive, t: t);
    s.paint(canvas);
    if (pop > 0.02) _sparkles(canvas, size, o);
  }

  void _sparkles(Canvas canvas, Size size, Offset o) {
    final w = size.width;
    final rnd = math.Random(sparkSeed * 13 + 5);
    const cols = [Color(0xFFFFF59D), Colors.white, Color(0xFFB9F6CA), Color(0xFFFFE082)];
    final spread = 1 - pop; // 0 عند البداية → 1 عند النهاية
    for (var i = 0; i < 14; i++) {
      final a = rnd.nextDouble() * 2 * math.pi;
      final r = w * (0.08 + 0.26 * rnd.nextDouble()) * (0.4 + 0.9 * spread);
      final c = Offset(o.dx + math.cos(a) * r, o.dy - w * 0.16 + math.sin(a) * r * 0.8 - spread * w * 0.08);
      final sz = w * (0.012 + 0.022 * rnd.nextDouble()) * (0.5 + pop);
      final path = Path()
        ..moveTo(c.dx, c.dy - sz * 2)
        ..quadraticBezierTo(c.dx, c.dy, c.dx + sz * 2, c.dy)
        ..quadraticBezierTo(c.dx, c.dy, c.dx, c.dy + sz * 2)
        ..quadraticBezierTo(c.dx, c.dy, c.dx - sz * 2, c.dy)
        ..quadraticBezierTo(c.dx, c.dy, c.dx, c.dy - sz * 2)
        ..close();
      canvas.drawPath(path, Paint()..color = cols[i % cols.length].withValues(alpha: (pop * 1.2).clamp(0.0, 1.0).toDouble()));
    }
  }

  @override
  bool shouldRepaint(covariant BowlPainter old) =>
      old.type != type ||
      old.growth != growth ||
      old.alive != alive ||
      old.plantSize != plantSize ||
      old.t != t ||
      old.pop != pop ||
      old.sparkSeed != sparkSeed;
}

/// نبتة تنمو بسلاسة: تنعيم للنمو، نبضة عند كل مرحلة، وشرارات احتفال.
/// [celebrate] يُزاد رقمه لإطلاق احتفال كبير (عند اكتمال الجلسة).
class GrowingBowl extends StatefulWidget {
  final String type;
  final double growth; // الهدف 0..1
  final double plantSize;
  final bool alive;
  final bool lite; // وضع الأداء المنخفض: بلا تمايل مستمر
  final int celebrate;
  final bool growIn; // يبدأ من الصفر وينمو عند الظهور
  const GrowingBowl({
    super.key,
    required this.type,
    required this.growth,
    this.plantSize = 1.0,
    this.alive = true,
    this.lite = true,
    this.celebrate = 0,
    this.growIn = false,
  });

  @override
  State<GrowingBowl> createState() => _GrowingBowlState();
}

class _GrowingBowlState extends State<GrowingBowl> with SingleTickerProviderStateMixin {
  Ticker? _ticker;
  Duration _last = Duration.zero;
  double _shown = 0;
  double _t = 0;
  double _pop = 0;
  int _seed = 1;

  static const _stages = [0.1, 0.35, 0.65, 0.9];

  @override
  void initState() {
    super.initState();
    _shown = widget.growIn ? 0.0 : widget.growth;
    if (widget.growIn) _kick(0.7);
    _syncTicker();
  }

  @override
  void didUpdateWidget(GrowingBowl old) {
    super.didUpdateWidget(old);
    final prev = old.growth, now = widget.growth;
    if (old.type != widget.type) {
      _shown = now;
      _kick(0.6);
    } else if (now < prev - 0.3) {
      // جلسة جديدة: تنبت البذرة من جديد
      _shown = now;
      _kick(0.8);
    } else {
      for (final th in _stages) {
        if (prev < th && now >= th) _kick(0.65);
      }
    }
    if (widget.celebrate != old.celebrate) _kick(1.0);
    _syncTicker();
  }

  void _kick(double power) {
    if (power > _pop) _pop = power;
    _seed++;
  }

  bool get _busy => _pop > 0.001 || (widget.growth - _shown).abs() > 0.0005;

  void _syncTicker() {
    _ticker ??= createTicker(_onTick);
    if ((!widget.lite || _busy) && !_ticker!.isActive) {
      _last = Duration.zero;
      _ticker!.start();
    }
  }

  void _onTick(Duration e) {
    final ms = (e - _last).inMilliseconds;
    if (ms < 30) return;
    _last = e;
    final dt = (ms / 1000.0).clamp(0.0, 0.1).toDouble();
    _t = widget.lite ? 0.0 : e.inMilliseconds / 1000.0;
    final target = widget.growth;
    _shown += (target - _shown) * (1 - math.exp(-dt * 4.5));
    if ((target - _shown).abs() < 0.0005) _shown = target;
    _pop = math.max(0.0, _pop - dt * 0.55);
    if (widget.lite && !_busy) _ticker?.stop();
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _ticker?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: CustomPaint(
        painter: BowlPainter(
          type: widget.type,
          growth: _shown,
          plantSize: widget.plantSize,
          alive: widget.alive,
          t: _t,
          pop: _pop,
          sparkSeed: _seed,
        ),
      ),
    );
  }
}

/// شخصية المساعد: برعم صغير (تصميم أصلي لتطبيق Stud)
class SproutPainter extends CustomPainter {
  const SproutPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final c = Offset(w / 2, h * 0.58);
    final r = w * 0.34;
    // ظل
    canvas.drawOval(Rect.fromCenter(center: Offset(w / 2, h * 0.93), width: r * 1.6, height: h * 0.07),
        Paint()..color = Colors.black.withValues(alpha: 0.12));
    // الجسم (بذرة كريمية)
    final body = Rect.fromCenter(center: c, width: r * 2, height: r * 2.15);
    canvas.drawOval(body, Paint()..color = const Color(0xFFFFE9B8));
    canvas.drawOval(
      Rect.fromCenter(center: Offset(c.dx - r * 0.12, c.dy - r * 0.15), width: r * 1.6, height: r * 1.7),
      Paint()..color = const Color(0xFFFFF4D6),
    );
    // ساق وورقتان
    final stem = Paint()
      ..color = const Color(0xFF4E9F5B)
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.03
      ..strokeCap = StrokeCap.round;
    final top = Offset(c.dx, c.dy - r * 1.05);
    canvas.drawLine(top, Offset(top.dx, top.dy - h * 0.08), stem);
    Path leaf(double dir) => Path()
      ..moveTo(top.dx, top.dy - h * 0.07)
      ..quadraticBezierTo(top.dx + dir * w * 0.16, top.dy - h * 0.2, top.dx + dir * w * 0.22, top.dy - h * 0.1)
      ..quadraticBezierTo(top.dx + dir * w * 0.1, top.dy - h * 0.05, top.dx, top.dy - h * 0.07)
      ..close();
    canvas.drawPath(leaf(1), Paint()..color = const Color(0xFF66BB6A));
    canvas.drawPath(leaf(-1), Paint()..color = const Color(0xFF8BD17C));
    // الوجه
    final eye = Paint()..color = const Color(0xFF2A3B2F);
    final ey = c.dy - r * 0.05;
    canvas.drawCircle(Offset(c.dx - r * 0.38, ey), r * 0.11, eye);
    canvas.drawCircle(Offset(c.dx + r * 0.38, ey), r * 0.11, eye);
    final hi = Paint()..color = Colors.white;
    canvas.drawCircle(Offset(c.dx - r * 0.35, ey - r * 0.04), r * 0.04, hi);
    canvas.drawCircle(Offset(c.dx + r * 0.41, ey - r * 0.04), r * 0.04, hi);
    final blush = Paint()..color = const Color(0xFFFFA8A0).withValues(alpha: 0.65);
    canvas.drawOval(Rect.fromCenter(center: Offset(c.dx - r * 0.62, ey + r * 0.28), width: r * 0.26, height: r * 0.16), blush);
    canvas.drawOval(Rect.fromCenter(center: Offset(c.dx + r * 0.62, ey + r * 0.28), width: r * 0.26, height: r * 0.16), blush);
    final mouth = Paint()
      ..color = const Color(0xFF2A3B2F)
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.014
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(Rect.fromCenter(center: Offset(c.dx, ey + r * 0.3), width: r * 0.3, height: r * 0.22), 0.2, math.pi - 0.4, false, mouth);
  }

  @override
  bool shouldRepaint(covariant SproutPainter old) => false;
}

class Sprout extends StatelessWidget {
  final double size;
  const Sprout({super.key, this.size = 56});
  @override
  Widget build(BuildContext context) =>
      SizedBox(width: size, height: size, child: const CustomPaint(painter: SproutPainter()));
}

/// دائرة المؤقت مع الوعاء والنبتة
class TimerCircle extends StatelessWidget {
  final double size;
  final double progress; // 0..1 (حلقة)
  final String type;
  final double growth;
  final double plantSize;
  final bool alive;
  final bool lite;
  final int celebrate;
  final bool growIn;
  const TimerCircle({
    super.key,
    required this.size,
    required this.progress,
    required this.type,
    required this.growth,
    this.plantSize = 1.0,
    this.alive = true,
    this.lite = true,
    this.celebrate = 0,
    this.growIn = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        children: [
          Positioned.fill(child: CustomPaint(painter: RingPainter(progress))),
          Positioned.fill(
            child: GrowingBowl(
              type: type,
              growth: growth,
              plantSize: plantSize,
              alive: alive,
              lite: lite,
              celebrate: celebrate,
              growIn: growIn,
            ),
          ),
        ],
      ),
    );
  }
}
