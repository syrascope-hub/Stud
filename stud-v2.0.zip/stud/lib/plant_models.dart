import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'scene3d.dart';

class PlantCtx {
  final Scene3D s;
  final V3 pos;
  final double S; // الحجم الكلي
  final double cf; // نمو التاج 0..1
  final int seed;
  final bool alive;
  final double t;
  final double thirst; // 0 مرتوية .. 1 جافة
  final bool golden;
  PlantCtx(this.s, this.pos, this.S, this.cf, this.seed, this.alive, this.t, [this.thirst = 0, this.golden = false]);

  bool get lite => s.lite;
  double get crown => 0.3 + 0.7 * cf;
  // ألوان أفتح قليلاً لإعطاء طابع كرتوني ناعم
  Color c(Color x) {
    if (!alive) return Color.lerp(x, const Color(0xFF7C6A52), 0.82)!;
    var base = Color.lerp(x, Colors.white, 0.1)!;
    if (golden) base = Color.lerp(base, const Color(0xFFFFC83D), 0.55)!;
    if (thirst <= 0) return base;
    return Color.lerp(base, const Color(0xFFB9A24E), 0.6 * thirst)!;
  }
  V3 sway(double h) {
    final k = h * 0.04;
    return V3(math.sin(t * 1.4 + seed * 0.7) * k, 0, math.cos(t * 1.1 + seed * 0.5) * k * 0.6);
  }

  V3 at(double dx, double dy, double dz) => V3(pos.x + dx, pos.y + dy, pos.z + dz);
}

/// يبني نبتة كاملة في المشهد حسب نوعها ومرحلة نموها.
void buildPlant(
  Scene3D s,
  String type,
  V3 pos, {
  required double growth,
  required double size,
  required int seed,
  required bool alive,
  required double t,
  double thirst = 0,
  bool golden = false,
  bool bloom = false,
}) {
  final g = growth.clamp(0.0, 1.0).toDouble();
  final S = size * (0.22 + 0.78 * math.pow(g, 0.7).toDouble());
  final cf = alive ? ((g - 0.1) / 0.55).clamp(0.0, 1.0).toDouble() : 0.45;
  final k = PlantCtx(s, pos, S, cf, seed, alive, t, thirst, golden);
  s.shadow(pos, 0.5 * S + 0.12, 0.22);
  if (g < 0.1 && alive) {
    _seedling(k);
    return;
  }
  switch (type) {
    case 'pine':
      _pine(k);
      break;
    case 'cypress':
      _cypress(k);
      break;
    case 'cherry':
      _cherry(k);
      break;
    case 'palm':
      _palm(k);
      break;
    case 'olive':
      _olive(k);
      break;
    case 'maple':
      _maple(k);
      break;
    case 'birch':
      _birch(k);
      break;
    case 'bamboo':
      _bamboo(k);
      break;
    case 'cactus':
      _cactus(k);
      break;
    case 'sunflower':
      _sunflower(k);
      break;
    case 'tulip':
      _tulip(k);
      break;
    case 'mushroom':
      _mushroom(k);
      break;
    case 'bush':
      _bush(k);
      break;
    default:
      _oak(k);
  }
  if (alive && g >= 0.9 && (bloom || golden)) _extras(k, bloom, golden);
}

/// أزهار صغيرة حول تاج الشجرة المسقية جيداً، وثمار/شرارات ذهبية للشجرة النادرة
void _extras(PlantCtx k, bool bloom, bool golden) {
  final rnd = math.Random(k.seed * 17 + 3);
  final n = k.lite ? 4 : 8;
  const petals = [Color(0xFFFFB7D5), Colors.white, Color(0xFFFFC1E3), Color(0xFFFFE0F0)];
  for (var i = 0; i < n; i++) {
    final a = rnd.nextDouble() * 2 * math.pi;
    final d = (0.25 + rnd.nextDouble() * 0.4) * k.S;
    final y = (1.05 + rnd.nextDouble() * 0.75) * k.S;
    final c = V3(k.pos.x + math.cos(a) * d, k.pos.y + y, k.pos.z + math.sin(a) * d);
    if (bloom) k.s.sphere(c, 0.05 * k.S + 0.012, petals[i % petals.length]);
    if (golden && i.isEven) k.s.sphere(V3(c.x, c.y + 0.12 * k.S, c.z), 0.045 * k.S + 0.01, const Color(0xFFFFE066));
  }
  if (golden) {
    k.s.sphere(V3(k.pos.x, k.pos.y + 2.35 * k.S, k.pos.z), 0.08 * k.S + 0.015, const Color(0xFFFFF59D));
  }
}

void _crown(PlantCtx k, V3 center, double r, List<Color> cols, int n,
    {double spread = 0.6, double squash = 1.0, int salt = 0}) {
  final rnd = math.Random(k.seed * 31 + salt);
  if (k.lite) n = math.max(3, (n * 0.5).round());
  for (var i = 0; i < n; i++) {
    final a = rnd.nextDouble() * 2 * math.pi;
    final d = rnd.nextDouble() * r * spread;
    final dy = (rnd.nextDouble() - 0.35) * r * spread * 0.9;
    final rr = r * (0.55 + rnd.nextDouble() * 0.35);
    k.s.sphere(
      V3(center.x + math.cos(a) * d, center.y + dy, center.z + math.sin(a) * d),
      rr,
      k.c(cols[i % cols.length]),
      squash: squash,
    );
  }
  k.s.sphere(center, r * 0.8, k.c(cols[0]), squash: squash);
}

void _seedling(PlantCtx k) {
  k.s.sphere(k.at(0, 0.03, 0), 0.17, const Color(0xFF6D4C2F), squash: 0.5);
  const c = Color(0xFF66BB6A);
  k.s.ribbon([k.at(0, 0.05, 0), k.at(0.12, 0.2, 0), k.at(0.22, 0.22, 0)], 0.07, c);
  k.s.ribbon([k.at(0, 0.05, 0), k.at(-0.12, 0.2, 0.02), k.at(-0.22, 0.22, 0.02)], 0.07, c);
}

void _oak(PlantCtx k) {
  final h = 1.0 * k.S;
  final sw = k.sway(h);
  final top = k.at(sw.x, h, sw.z);
  final bark = k.c(const Color(0xFF6B4A2B));
  k.s.stem(k.pos, top, 0.13 * k.S, 0.08 * k.S, bark);
  k.s.stem(top, k.at(sw.x + 0.32 * k.S, h + 0.32 * k.S, sw.z), 0.05 * k.S, 0.03 * k.S, bark);
  k.s.stem(top, k.at(sw.x - 0.3 * k.S, h + 0.28 * k.S, sw.z + 0.1), 0.05 * k.S, 0.03 * k.S, bark);
  final r = 0.8 * k.S * k.crown;
  _crown(k, V3(top.x, top.y + 0.6 * r, top.z), r,
      const [Color(0xFF3E8E41), Color(0xFF4CAF50), Color(0xFF2E7D32), Color(0xFF66BB6A)], 7);
}

void _pine(PlantCtx k) {
  final sw = k.sway(1.4 * k.S);
  k.s.stem(k.pos, k.at(sw.x * 0.5, 0.5 * k.S, 0), 0.08 * k.S, 0.06 * k.S, k.c(const Color(0xFF5D4037)));
  for (var i = 0; i < 4; i++) {
    final f = k.crown;
    final base = k.at(sw.x * (0.4 + i * 0.2), (0.28 + i * 0.4) * k.S, sw.z * 0.5);
    final shadeF = 0.8 + i * 0.1;
    k.s.cone(base, (0.85 - i * 0.17) * k.S * f, 0.85 * k.S * f,
        shade(k.c(const Color(0xFF2D6A4F)), shadeF));
  }
}

void _cypress(PlantCtx k) {
  final sw = k.sway(1.8 * k.S);
  k.s.stem(k.pos, k.at(0, 0.3 * k.S, 0), 0.06 * k.S, 0.05 * k.S, k.c(const Color(0xFF5D4037)));
  final radii = [0.4, 0.32, 0.22];
  for (var i = 0; i < 3; i++) {
    final base = k.at(sw.x * (0.4 + i * 0.4), (0.2 + i * 0.6) * k.S, sw.z * 0.4);
    k.s.cone(base, radii[i] * k.S * k.crown, 1.05 * k.S * k.crown,
        shade(k.c(const Color(0xFF2F5D3A)), 0.9 + i * 0.1), seg: 12);
  }
}

void _cherry(PlantCtx k) {
  final h = 0.95 * k.S;
  final sw = k.sway(h);
  final mid = k.at(sw.x * 0.4 + 0.1 * k.S, h * 0.55, 0);
  final top = k.at(sw.x, h, sw.z);
  final bark = k.c(const Color(0xFF5D4037));
  k.s.stem(k.pos, mid, 0.1 * k.S, 0.08 * k.S, bark);
  k.s.stem(mid, top, 0.08 * k.S, 0.06 * k.S, bark);
  final r = 0.78 * k.S * k.crown;
  _crown(k, V3(top.x, top.y + 0.55 * r, top.z), r,
      const [Color(0xFFF8BBD0), Color(0xFFF48FB1), Color(0xFFFFCDD2), Color(0xFFF06292)], 8, spread: 0.75);
  if (k.alive && k.cf > 0.8) {
    for (var i = 0; i < 6; i++) {
      final a = i / 6 * 2 * math.pi + k.seed;
      final fall = ((k.t * 0.25 + i / 6) % 1.0);
      k.s.sphere(
        V3(top.x + math.cos(a) * r * (0.6 + fall * 0.5), top.y + r * 0.4 - fall * (top.y + r * 0.4), top.z + math.sin(a) * r * (0.6 + fall * 0.5)),
        0.03 * k.S + 0.01,
        const Color(0xFFFFC1D6),
      );
    }
  }
}

void _palm(PlantCtx k) {
  final h = 1.7 * k.S;
  final sw = k.sway(h);
  final lean = 0.35 * k.S;
  V3 pt(double u) => k.at(lean * u * u + sw.x * u, h * u, sw.z * u);
  final bark = k.c(const Color(0xFF8D6E63));
  const n = 7;
  for (var i = 0; i < n; i++) {
    final u0 = i / n, u1 = (i + 1) / n;
    k.s.stem(pt(u0), pt(u1), (0.1 - 0.04 * u0) * k.S, (0.1 - 0.04 * u1) * k.S, shade(bark, i.isEven ? 1.0 : 0.88));
  }
  final top = pt(1.0);
  final L = 1.15 * k.S * k.crown;
  for (var f = 0; f < 8; f++) {
    final ang = f / 8 * 2 * math.pi + k.seed * 0.1;
    final dx = math.cos(ang), dz = math.sin(ang);
    final pts = <V3>[];
    for (var j = 0; j <= 5; j++) {
      final u = j / 5;
      pts.add(V3(top.x + dx * L * u, top.y + L * (0.4 * u - 0.95 * u * u) + 0.05, top.z + dz * L * u));
    }
    k.s.ribbon(pts, 0.2 * k.S * k.crown, k.c(f.isEven ? const Color(0xFF2E7D32) : const Color(0xFF43A047)));
  }
  for (var i = 0; i < 3; i++) {
    final a = i / 3 * 2 * math.pi;
    k.s.sphere(V3(top.x + math.cos(a) * 0.1 * k.S, top.y - 0.08 * k.S, top.z + math.sin(a) * 0.1 * k.S),
        0.07 * k.S * k.crown, k.c(const Color(0xFFB26A00)));
  }
}

void _olive(PlantCtx k) {
  final h = 0.7 * k.S;
  final sw = k.sway(h);
  final bark = k.c(const Color(0xFF6D5B4B));
  final m = k.at(-0.12 * k.S, h * 0.5, 0.05 * k.S);
  final top = k.at(sw.x + 0.1 * k.S, h, sw.z);
  k.s.stem(k.pos, m, 0.15 * k.S, 0.11 * k.S, bark);
  k.s.stem(m, top, 0.11 * k.S, 0.08 * k.S, bark);
  k.s.stem(m, k.at(-0.3 * k.S, h * 0.9, 0.1), 0.05 * k.S, 0.03 * k.S, bark);
  final r = 0.85 * k.S * k.crown;
  _crown(k, V3(top.x, top.y + 0.42 * r, top.z), r,
      const [Color(0xFF8A9A5B), Color(0xFF6B7F4A), Color(0xFFA3B18A), Color(0xFF7D8F57)], 8,
      spread: 0.9, squash: 0.78);
  if (k.cf > 0.7) {
    final rnd = math.Random(k.seed);
    for (var i = 0; i < 6; i++) {
      final a = rnd.nextDouble() * 2 * math.pi;
      k.s.sphere(V3(top.x + math.cos(a) * r * 0.7, top.y + r * 0.2 + rnd.nextDouble() * 0.2 * r, top.z + math.sin(a) * r * 0.7),
          0.035 * k.S, k.c(const Color(0xFF3B3B1E)));
    }
  }
}

void _maple(PlantCtx k) {
  final h = 0.95 * k.S;
  final sw = k.sway(h);
  final top = k.at(sw.x, h, sw.z);
  k.s.stem(k.pos, top, 0.11 * k.S, 0.07 * k.S, k.c(const Color(0xFF4E342E)));
  final r = 0.78 * k.S * k.crown;
  _crown(k, V3(top.x, top.y + 0.6 * r, top.z), r,
      const [Color(0xFFD84315), Color(0xFFEF6C00), Color(0xFFFFA000), Color(0xFFBF360C)], 8, spread: 0.7);
  if (k.alive) {
    final rnd = math.Random(k.seed + 5);
    for (var i = 0; i < 5; i++) {
      final a = rnd.nextDouble() * 2 * math.pi;
      final d = (0.4 + rnd.nextDouble() * 0.5) * k.S;
      k.s.sphere(k.at(math.cos(a) * d, 0.02, math.sin(a) * d), 0.05 * k.S + 0.01,
          const Color(0xFFE65100), squash: 0.35);
    }
  }
}

void _birch(PlantCtx k) {
  final h = 1.5 * k.S;
  final sw = k.sway(h);
  final top = k.at(sw.x, h, sw.z);
  k.s.stem(k.pos, top, 0.09 * k.S, 0.06 * k.S, k.c(const Color(0xFFEFEBE9)));
  for (var i = 1; i <= 5; i++) {
    final u = i / 6.0;
    final y = h * u;
    final cx = k.pos.x + sw.x * u;
    k.s.stem(V3(cx - 0.075 * k.S, k.pos.y + y, k.pos.z), V3(cx + 0.075 * k.S, k.pos.y + y + 0.015, k.pos.z),
        0.018 * k.S, 0.018 * k.S, k.c(const Color(0xFF424242)));
  }
  final r = 0.55 * k.S * k.crown;
  _crown(k, V3(top.x, top.y + 0.25 * k.S, top.z), r,
      const [Color(0xFF9CCC65), Color(0xFFAED581), Color(0xFF8BC34A), Color(0xFFC5E1A5)], 6, spread: 0.9, salt: 3);
  _crown(k, V3(top.x, top.y - 0.15 * k.S, top.z), r * 0.8,
      const [Color(0xFFAED581), Color(0xFF9CCC65)], 4, spread: 0.9, salt: 9);
}

void _bamboo(PlantCtx k) {
  final rnd = math.Random(k.seed);
  for (var i = 0; i < 5; i++) {
    final ox = (rnd.nextDouble() - 0.5) * 0.5 * k.S;
    final oz = (rnd.nextDouble() - 0.5) * 0.5 * k.S;
    final h = (1.4 + rnd.nextDouble() * 0.7) * k.S;
    final sw = k.sway(h);
    final base = k.at(ox, 0, oz);
    final top = k.at(ox + sw.x, h, oz + sw.z);
    final col = k.c(const Color(0xFF7CB342));
    k.s.stem(base, top, 0.045 * k.S, 0.035 * k.S, col);
    for (var n = 1; n <= 4; n++) {
      final u = n / 5.0;
      final p = k.at(ox + sw.x * u, h * u, oz + sw.z * u);
      k.s.stem(p, V3(p.x, p.y + 0.03, p.z), 0.058 * k.S, 0.058 * k.S, shade(col, 0.6));
    }
    for (var l = 0; l < 3; l++) {
      final a = l / 3 * 2 * math.pi + i;
      final len = 0.5 * k.S * k.crown;
      k.s.ribbon([
        top,
        V3(top.x + math.cos(a) * len * 0.5, top.y + len * 0.15, top.z + math.sin(a) * len * 0.5),
        V3(top.x + math.cos(a) * len, top.y - len * 0.2, top.z + math.sin(a) * len),
      ], 0.07 * k.S + 0.02, k.c(const Color(0xFF9CCC65)));
    }
  }
}

void _cactus(PlantCtx k) {
  final col = k.c(const Color(0xFF2E8B57));
  final h = 1.15 * k.S;
  final top = k.at(0, h, 0);
  k.s.stem(k.pos, top, 0.17 * k.S, 0.15 * k.S, col, round: true);
  final armY = 0.5 * k.S;
  final a1 = k.at(0.34 * k.S, armY, 0);
  k.s.stem(k.at(0.12 * k.S, armY, 0), a1, 0.08 * k.S, 0.08 * k.S, col, round: true);
  k.s.stem(a1, k.at(0.34 * k.S, armY + 0.38 * k.S * k.crown, 0), 0.08 * k.S, 0.07 * k.S, col, round: true);
  final a2 = k.at(-0.3 * k.S, 0.72 * k.S, 0);
  k.s.stem(k.at(-0.1 * k.S, 0.72 * k.S, 0), a2, 0.07 * k.S, 0.07 * k.S, col, round: true);
  k.s.stem(a2, k.at(-0.3 * k.S, 0.72 * k.S + 0.28 * k.S * k.crown, 0), 0.07 * k.S, 0.06 * k.S, col, round: true);
  if (k.alive && k.cf > 0.6) {
    k.s.sphere(k.at(0, h + 0.07 * k.S, 0), 0.08 * k.S, const Color(0xFFFF4081));
  }
}

void _sunflower(PlantCtx k) {
  final rnd = math.Random(k.seed);
  for (var i = 0; i < 3; i++) {
    final ox = (i - 1) * 0.42 * k.S + (rnd.nextDouble() - 0.5) * 0.1;
    final oz = (rnd.nextDouble() - 0.5) * 0.3 * k.S;
    final h = (1.15 + i % 2 * 0.3 + rnd.nextDouble() * 0.2) * k.S;
    final sw = k.sway(h);
    final base = k.at(ox, 0, oz);
    final top = k.at(ox + sw.x, h, oz + sw.z);
    final green = k.c(const Color(0xFF558B2F));
    k.s.stem(base, top, 0.04 * k.S, 0.03 * k.S, green);
    k.s.ribbon([k.at(ox, h * 0.3, oz), k.at(ox + 0.18 * k.S, h * 0.38, oz), k.at(ox + 0.34 * k.S, h * 0.3, oz)], 0.1 * k.S, green);
    k.s.ribbon([k.at(ox, h * 0.5, oz), k.at(ox - 0.18 * k.S, h * 0.57, oz), k.at(ox - 0.34 * k.S, h * 0.5, oz)], 0.1 * k.S, green);
    k.s.billboardFlower(top, 0.32 * k.S * k.crown, k.c(const Color(0xFFFFC107)), k.c(const Color(0xFF5D4037)), 14);
  }
}

void _tulip(PlantCtx k) {
  const cols = [Color(0xFFE53935), Color(0xFFEC407A), Color(0xFFFFCA28), Color(0xFF8E24AA)];
  final rnd = math.Random(k.seed);
  final cup = cols[k.seed % cols.length];
  for (var i = 0; i < 4; i++) {
    final ox = (rnd.nextDouble() - 0.5) * 0.6 * k.S;
    final oz = (rnd.nextDouble() - 0.5) * 0.6 * k.S;
    final h = (0.65 + rnd.nextDouble() * 0.3) * k.S;
    final sw = k.sway(h);
    final green = k.c(const Color(0xFF43A047));
    final top = k.at(ox + sw.x, h, oz + sw.z);
    k.s.stem(k.at(ox, 0, oz), top, 0.03 * k.S, 0.025 * k.S, green);
    k.s.ribbon([k.at(ox, 0, oz), k.at(ox + 0.12 * k.S, h * 0.45, oz), k.at(ox + 0.22 * k.S, h * 0.7, oz)], 0.07 * k.S, green);
    final cc = k.c(cup);
    final r = 0.1 * k.S * k.crown + 0.02;
    k.s.sphere(V3(top.x - r * 0.5, top.y + r * 0.9, top.z), r, shade(cc, 0.9), squash: 1.25);
    k.s.sphere(V3(top.x + r * 0.5, top.y + r * 0.9, top.z), r, shade(cc, 0.9), squash: 1.25);
    k.s.sphere(V3(top.x, top.y + r * 1.1, top.z), r * 1.05, cc, squash: 1.3);
  }
}

void _mushroom(PlantCtx k) {
  void one(double ox, double oz, double sc) {
    final h = 0.5 * k.S * sc;
    final top = k.at(ox, h, oz);
    k.s.stem(k.at(ox, 0, oz), top, 0.1 * k.S * sc, 0.085 * k.S * sc, k.c(const Color(0xFFF5E6D3)));
    final r = 0.36 * k.S * sc * (0.5 + 0.5 * k.crown);
    final c = V3(top.x, top.y + r * 0.2, top.z);
    k.s.sphere(c, r, k.c(const Color(0xFFD32F2F)), squash: 0.62);
    if (k.alive) {
      k.s.spots(c, r, 0.62, const [Offset(-0.45, -0.25), Offset(0.35, -0.4), Offset(0.05, -0.1), Offset(0.55, -0.05), Offset(-0.15, -0.55)], const Color(0xFFFFFFFF));
    }
  }

  one(0, 0, 1.0);
  one(0.45 * k.S, 0.25 * k.S, 0.55);
  one(-0.4 * k.S, 0.3 * k.S, 0.4);
}

void _bush(PlantCtx k) {
  final r = 0.5 * k.S * (0.5 + 0.5 * k.crown);
  final c = V3(k.pos.x, k.pos.y + r * 0.7, k.pos.z);
  _crown(k, c, r, const [Color(0xFF388E3C), Color(0xFF43A047), Color(0xFF2E7D32), Color(0xFF4CAF50)], 6,
      spread: 1.1, squash: 0.85);
  if (k.alive && k.cf > 0.6) {
    final rnd = math.Random(k.seed);
    for (var i = 0; i < 9; i++) {
      final a = rnd.nextDouble() * 2 * math.pi;
      final b = rnd.nextDouble() * 0.9;
      k.s.sphere(
        V3(c.x + math.cos(a) * r * 1.0, c.y + b * r * 0.8, c.z + math.sin(a) * r * 1.0),
        0.045 * k.S + 0.01,
        const Color(0xFF3F51B5),
      );
    }
  }
}
