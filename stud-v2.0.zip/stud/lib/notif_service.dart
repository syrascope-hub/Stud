import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'models.dart';
import 'store.dart';

/// إشعارات محلية: نهاية جلسة التركيز + تذكير يومي بالدراسة.
/// كل شيء داخل try/catch: فشل الإشعارات لا يجب أن يكسر التطبيق أبداً.
class NotifService {
  static final FlutterLocalNotificationsPlugin _p = FlutterLocalNotificationsPlugin();
  static bool _ready = false;
  static const _sessionId = 1;
  static const _breakId = 2;
  static const _dailyBase = 100;
  static const _weeklyBase = 200;

  static const _details = NotificationDetails(
    android: AndroidNotificationDetails(
      'stud_main',
      'تنبيهات Stud',
      channelDescription: 'نهاية جلسات التركيز والتذكير اليومي',
      importance: Importance.high,
      priority: Priority.high,
    ),
  );

  static Future<void> init() async {
    try {
      tzdata.initializeTimeZones();
      const android = AndroidInitializationSettings('@mipmap/ic_launcher');
      await _p.initialize(const InitializationSettings(android: android));
      final a = _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      await a?.requestNotificationsPermission();
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  static Future<void> _at(int id, DateTime local, String title, String body, {bool exact = false}) async {
    final when = tz.TZDateTime.from(local, tz.UTC);
    if (exact) {
      try {
        await _p.zonedSchedule(id, title, body, when, _details,
            androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle);
        return;
      } catch (_) {
        // لا صلاحية للمنبّهات الدقيقة: نرجع للجدولة التقريبية
      }
    }
    await _p.zonedSchedule(id, title, body, when, _details,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle);
  }

  static Future<void> scheduleSessionEnd(DateTime end, String plantName) async {
    if (!_ready) return;
    try {
      await _p.cancel(_sessionId);
      if (!end.isAfter(DateTime.now())) return;
      await _at(_sessionId, end, 'نمت شجرتك 🌳', 'أنهيت جلسة التركيز ($plantName). افتح التطبيق لتجمع عملاتك.',
          exact: true);
    } catch (_) {}
  }

  static Future<void> scheduleBreakEnd(DateTime end) async {
    if (!_ready) return;
    try {
      await _p.cancel(_breakId);
      if (!end.isAfter(DateTime.now())) return;
      await _at(_breakId, end, 'انتهت الاستراحة ☕', 'حان وقت جلسة تركيز جديدة. ازرع شجرة جديدة 🌱', exact: true);
    } catch (_) {}
  }

  static Future<void> cancelBreak() async {
    if (!_ready) return;
    try {
      await _p.cancel(_breakId);
    } catch (_) {}
  }

  static Future<void> cancelSession() async {
    if (!_ready) return;
    try {
      await _p.cancel(_sessionId);
    } catch (_) {}
  }

  /// يجدول تذكير الأيام السبعة القادمة (يُعاد الجدولة عند كل فتح للتطبيق).
  static Future<void> scheduleDaily({
    required bool enabled,
    required int hour,
    required int minute,
    int? examDays,
  }) async {
    if (!_ready) return;
    try {
      for (var i = 0; i < 7; i++) {
        await _p.cancel(_dailyBase + i);
      }
      if (!enabled) return;
      final now = DateTime.now();
      for (var i = 0; i < 7; i++) {
        final t = DateTime(now.year, now.month, now.day + i, hour, minute);
        if (!t.isAfter(now)) continue;
        final left = examDays == null ? null : examDays - i;
        final body = (left != null && left > 0)
            ? 'باقي $left يوماً على آخر امتحان. افتح Stud، أنجز مهامك واسقِ أشجارك 💧'
            : 'حان وقت الدراسة! أنجز مهام اليوم واسقِ أشجارك 💧';
        await _at(_dailyBase + i, t, 'تذكير الدراسة 📚', body);
      }
    } catch (_) {}
  }

  /// تنبيه أسبوعي (الجمعة 8 مساءً) للأسابيع الأربعة القادمة
  static Future<void> scheduleWeekly({required bool enabled}) async {
    if (!_ready) return;
    try {
      for (var i = 0; i < 4; i++) {
        await _p.cancel(_weeklyBase + i);
      }
      if (!enabled) return;
      final now = DateTime.now();
      final until = (DateTime.friday - now.weekday + 7) % 7;
      for (var i = 0; i < 4; i++) {
        final t = DateTime(now.year, now.month, now.day + until + 7 * i, 20, 0);
        if (!t.isAfter(now)) continue;
        await _at(_weeklyBase + i, t, 'تقريرك الأسبوعي جاهز 📊',
            'افتح المخطط ← القائمة ⋮ ← تقرير الأسبوع لترى تقدّمك وما أهملته.');
      }
    } catch (_) {}
  }

  /// يزامن كل الإشعارات مع حالة التطبيق الحالية
  static Future<void> sync(AppStore s) async {
    if (!_ready) return;
    final last = s.lastExam;
    final d = last?.daysLeft();
    await scheduleDaily(
      enabled: s.notifDaily,
      hour: s.dailyHour,
      minute: s.dailyMinute,
      examDays: (d != null && d >= 0) ? d : null,
    );
    await scheduleWeekly(enabled: s.notifWeekly);
    final a = s.active;
    if (a != null && s.notifSession && a.pausedAtMs == null) {
      await scheduleSessionEnd(DateTime.fromMillisecondsSinceEpoch(a.endMs), plantById(a.type).name);
    } else {
      await cancelSession();
    }
  }
}
