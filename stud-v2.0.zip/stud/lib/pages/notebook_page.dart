import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../math_text.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import 'review_page.dart';

const _symbols = [
  '√', '²', '³', 'ⁿ', 'π', '∞', '≤', '≥', '≠', '≈', '±', '×', '÷', '∫', 'Σ', 'Δ', 'θ', 'α', 'β', 'λ', 'ℝ', 'ℂ', 'ℕ', '∈', '→', '⇒', '⇔', '∀', '∃', '|z|', 'lim', "f'(x)", 'ln', 'eˣ', '()', '[ ]', '{ }',
];

const _mathChapters = [
  'النهايات والاستمرار',
  'الاشتقاق',
  'دراسة التوابع',
  'اللوغاريتم والأسّي',
  'التكامل',
  'المتتاليات',
  'الأعداد العقدية',
  'الهندسة الفراغية',
  'الاحتمالات',
  'المعادلات التفاضلية',
];

const _latex = [
  ['كسر', r'$\frac{a}{b}$'],
  ['جذر', r'$\sqrt{x}$'],
  ['قوة', r'$x^{2}$'],
  ['تكامل', r'$\int_{a}^{b} f(x)\,dx$'],
  ['نهاية', r'$\lim_{x\to\infty} f(x)$'],
  ['مجموع', r'$\sum_{i=1}^{n} u_i$'],
  ['مرافق', r'$\overline{z}$'],
  ['شعاع', r'$\vec{u}$'],
];

Future<String?> _pickImage() async {
  try {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
    if (x == null) return null;
    final dir = await getApplicationDocumentsDirectory();
    final folder = Directory('${dir.path}/notes');
    if (!await folder.exists()) await folder.create(recursive: true);
    final dest = '${folder.path}/${DateTime.now().microsecondsSinceEpoch}.jpg';
    await File(x.path).copy(dest);
    return dest;
  } catch (_) {
    return null;
  }
}

Widget _thumb(String path, double size) => ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: Image.file(
        File(path),
        width: size,
        height: size,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          width: size,
          height: size,
          color: C.surface2,
          child: Icon(Icons.broken_image_outlined, color: C.sub),
        ),
      ),
    );

Color _kindColor(String k) => k == 'mistake' ? C.danger : (k == 'rule' ? C.accent : C.amber);
String _kindEmoji(String k) => noteKinds.firstWhere((x) => x[0] == k, orElse: () => noteKinds.first)[1];
String _kindName(String k) => noteKinds.firstWhere((x) => x[0] == k, orElse: () => noteKinds.first)[2];

class NotebookPage extends StatefulWidget {
  const NotebookPage({super.key});
  @override
  State<NotebookPage> createState() => _NotebookPageState();
}

class _NotebookPageState extends State<NotebookPage> {
  String? _bookId;
  String _kind = 'all'; // all | idea | mistake | rule | star
  String _chapter = '';
  String _query = '';
  bool _searching = false;
  final _search = TextEditingController();

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Notebook _current(AppStore s) {
    final found = s.notebooks.where((b) => b.id == _bookId);
    return found.isNotEmpty ? found.first : s.notebooks.first;
  }

  bool _match(NoteEntry n) {
    if (_kind == 'star' && !n.starred) return false;
    if (_kind != 'all' && _kind != 'star' && n.kind != _kind) return false;
    if (_chapter.isNotEmpty && n.chapter != _chapter) return false;
    if (_query.isNotEmpty) {
      final q = normAr(_query);
      final hay = normAr('${n.title} ${n.body} ${n.fix} ${n.chapter}');
      if (!hay.contains(q)) return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    final book = _current(s);
    final all = s.notesOf(book.id)..sort((a, b) => b.ts.compareTo(a.ts));
    final list = all.where(_match).toList();
    final chapters = <String>{for (final n in all) if (n.chapter.isNotEmpty) n.chapter}.toList();
    if (_chapter.isNotEmpty && !chapters.contains(_chapter)) _chapter = '';
    final mistakes = all.where((n) => n.kind == 'mistake').length;

    return Scaffold(
      backgroundColor: C.bg,
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: C.accent,
        foregroundColor: C.onAccent,
        onPressed: () => showNoteEditor(context, s, notebookId: book.id),
        icon: const Icon(Icons.add),
        label: const Text('إضافة'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 8, 6),
              child: Row(
                children: [
                  Expanded(
                    child: _searching
                        ? TextField(
                            controller: _search,
                            autofocus: true,
                            onChanged: (v) => setState(() => _query = v.trim()),
                            decoration: fieldDeco('ابحث في الدفتر'),
                          )
                        : const Text('دفتري', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                  ),
                  IconButton(
                    onPressed: () => setState(() {
                      _searching = !_searching;
                      if (!_searching) {
                        _query = '';
                        _search.clear();
                      }
                    }),
                    icon: Icon(_searching ? Icons.close : Icons.search),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 44,
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                children: [
                  for (final b in s.notebooks)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: GestureDetector(
                        onLongPress: () => _editBook(s, b),
                        child: ChoiceChip(
                          label: Text('${b.emoji} ${b.name}'),
                          selected: b.id == book.id,
                          onSelected: (_) => setState(() {
                            _bookId = b.id;
                            _kind = 'all';
                            _chapter = '';
                          }),
                        ),
                      ),
                    ),
                  ActionChip(
                    avatar: const Icon(Icons.add, size: 18),
                    label: const Text('دفتر جديد'),
                    onPressed: () => _editBook(s, null),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 46,
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                children: [
                  _filter('الكل (${all.length})', 'all'),
                  for (final k in noteKinds)
                    _filter('${k[1]} ${k[2]}', k[0]),
                  _filter('⭐ المميّزة', 'star'),
                ],
              ),
            ),
            if (chapters.isNotEmpty)
              SizedBox(
                height: 40,
                child: ListView(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  scrollDirection: Axis.horizontal,
                  children: [
                    for (final c in chapters)
                      Padding(
                        padding: const EdgeInsetsDirectional.only(end: 8),
                        child: FilterChip(
                          label: Text(c, style: const TextStyle(fontSize: 12)),
                          selected: _chapter == c,
                          onSelected: (v) => setState(() => _chapter = v ? c : ''),
                        ),
                      ),
                  ],
                ),
              ),
            if (!_searching && s.reviewDue().isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: GestureDetector(
                  onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const ReviewPage())),
                  child: Panel(
                    color: C.surface2,
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        const Text('✍️', style: TextStyle(fontSize: 22)),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text('${s.reviewDue().length} من أخطائك تستحق المراجعة اليوم',
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                        ),
                        Icon(Icons.chevron_left, color: C.sub),
                      ],
                    ),
                  ),
                ),
              ),
            if (mistakes > 0 && _kind == 'all' && _query.isEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
                child: Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Text('عندك $mistakes ${mistakes == 1 ? 'خطأ مدوَّن' : 'أخطاء مدوَّنة'} — راجعها قبل كل دورة ✍️',
                      style: TextStyle(color: C.sub, fontSize: 12.5)),
                ),
              ),
            Expanded(
              child: list.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(40),
                        child: Text(
                          all.isEmpty
                              ? 'دفترك فارغ.\nدوّن فكرة حلّ أو خطأً وقعت فيه أو قانوناً تريد حفظه 📐'
                              : 'لا نتائج مطابقة.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: C.sub, height: 1.8),
                        ),
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                      itemCount: list.length,
                      itemBuilder: (_, i) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: _card(s, book, list[i]),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  void _viewImage(String path) {
    showDialog<void>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: const EdgeInsets.all(12),
        child: InteractiveViewer(
          child: Image.file(
            File(path),
            errorBuilder: (_, __, ___) => const Padding(
              padding: EdgeInsets.all(40),
              child: Icon(Icons.broken_image_outlined, color: Colors.white54, size: 48),
            ),
          ),
        ),
      ),
    );
  }

  Widget _filter(String label, String v) => Padding(
        padding: const EdgeInsetsDirectional.only(end: 8),
        child: ChoiceChip(
          label: Text(label),
          selected: _kind == v,
          onSelected: (_) => setState(() => _kind = v),
        ),
      );

  Widget _card(AppStore s, Notebook book, NoteEntry n) {
    final col = _kindColor(n.kind);
    final t = DateTime.fromMillisecondsSinceEpoch(n.ts);
    return GestureDetector(
      onTap: () => showNoteEditor(context, s, notebookId: book.id, note: n),
      child: Panel(
        padding: const EdgeInsets.fromLTRB(14, 12, 6, 12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 5,
              height: 54,
              decoration: BoxDecoration(color: col, borderRadius: BorderRadius.circular(4)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: col.withValues(alpha: 0.18),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text('${_kindEmoji(n.kind)} ${_kindName(n.kind)}',
                            style: TextStyle(fontSize: 11.5, color: col, fontWeight: FontWeight.w700)),
                      ),
                      if (n.chapter.isNotEmpty) ...[
                        const SizedBox(width: 8),
                        Flexible(
                          child: Text(n.chapter,
                              overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: C.sub)),
                        ),
                      ],
                    ],
                  ),
                  if (n.title.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    MathText(n.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                  ],
                  if (n.body.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    MathText(n.body, maxLines: 5, style: const TextStyle(height: 1.6)),
                  ],
                  if (n.kind == 'mistake' && n.fix.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: C.accent.withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: MathText('✅ الصحيح: ${n.fix}', style: const TextStyle(height: 1.6)),
                    ),
                  ],
                  if (n.images.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 64,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        children: [
                          for (final p in n.images)
                            GestureDetector(
                              onTap: () => _viewImage(p),
                              child: Padding(
                                padding: const EdgeInsetsDirectional.only(end: 6),
                                child: _thumb(p, 64),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 6),
                  Text('${t.day}/${t.month}/${t.year}', style: TextStyle(fontSize: 11, color: C.sub)),
                ],
              ),
            ),
            IconButton(
              onPressed: () => s.toggleStar(n),
              icon: Icon(n.starred ? Icons.star : Icons.star_border, color: n.starred ? C.amber : C.sub),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _editBook(AppStore s, Notebook? b) {
    final name = TextEditingController(text: b?.name ?? '');
    final emoji = TextEditingController(text: b?.emoji ?? '📓');
    return showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: Text(b == null ? 'دفتر جديد' : 'تعديل الدفتر'),
        content: Row(
          children: [
            SizedBox(
              width: 76,
              child: TextField(
                controller: emoji,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 22),
                decoration: fieldDeco('الرمز'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(child: TextField(controller: name, decoration: fieldDeco('اسم الدفتر'))),
          ],
        ),
        actions: [
          if (b != null && s.notebooks.length > 1)
            TextButton(
              onPressed: () async {
                final n = s.notesOf(b.id).length;
                final ok = await showDialog<bool>(
                  context: ctx,
                  builder: (c2) => AlertDialog(
                    backgroundColor: C.surface,
                    title: Text('حذف ${b.name}؟'),
                    content: Text(n == 0 ? 'الدفتر فارغ.' : 'سيُحذف الدفتر مع $n إدخالاً فيه.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(c2, false), child: const Text('إلغاء')),
                      TextButton(
                        onPressed: () => Navigator.pop(c2, true),
                        child: Text('حذف', style: TextStyle(color: C.danger)),
                      ),
                    ],
                  ),
                );
                if (ok == true) {
                  s.removeNotebook(b);
                  if (_bookId == b.id) setState(() => _bookId = null);
                  if (ctx.mounted) Navigator.pop(ctx);
                }
              },
              child: Text('حذف', style: TextStyle(color: C.danger)),
            ),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              if (b == null) {
                final id = s.addNotebook(name.text, emoji.text);
                setState(() {
                  _bookId = id;
                  _kind = 'all';
                  _chapter = '';
                });
              } else {
                s.updateNotebook(b, name.text, emoji.text);
              }
              Navigator.pop(ctx);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }
}

/// نافذة إضافة / تعديل إدخال في الدفتر
Future<void> showNoteEditor(BuildContext context, AppStore s, {required String notebookId, NoteEntry? note}) {
  var kind = note?.kind ?? 'idea';
  final title = TextEditingController(text: note?.title ?? '');
  final chapter = TextEditingController(text: note?.chapter ?? '');
  final body = TextEditingController(text: note?.body ?? '');
  final fix = TextEditingController(text: note?.fix ?? '');
  var target = body;
  final images = <String>[...(note?.images ?? <String>[])];

  void insert(String sym) {
    final c = target;
    final t = c.text;
    final sel = c.selection;
    final a = sel.isValid ? sel.start : t.length;
    final b = sel.isValid ? sel.end : t.length;
    c.value = TextEditingValue(
      text: t.replaceRange(a, b, sym),
      selection: TextSelection.collapsed(offset: a + sym.length),
    );
  }

  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => Padding(
        padding: EdgeInsets.fromLTRB(20, 4, 20, 16 + MediaQuery.of(ctx).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(note == null ? 'إدخال جديد' : 'تعديل الإدخال',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                children: [
                  for (final k in noteKinds)
                    ChoiceChip(
                      label: Text('${k[1]} ${k[2]}'),
                      selected: kind == k[0],
                      onSelected: (_) => set(() => kind = k[0]),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: title,
                decoration: fieldDeco(
                  'العنوان',
                  hint: kind == 'mistake' ? 'مثال: نسيت شرط الاشتقاق' : 'مثال: التعويض بـ t = tan(x/2)',
                ),
              ),
              const SizedBox(height: 10),
              TextField(controller: chapter, decoration: fieldDeco('الدرس / الوحدة (اختياري)')),
              const SizedBox(height: 6),
              SizedBox(
                height: 38,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    for (final c in _mathChapters)
                      Padding(
                        padding: const EdgeInsetsDirectional.only(end: 6),
                        child: ActionChip(
                          label: Text(c, style: const TextStyle(fontSize: 11.5)),
                          onPressed: () => set(() => chapter.text = c),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              Focus(
                onFocusChange: (f) {
                  if (f) target = body;
                },
                child: TextField(
                  controller: body,
                  minLines: 4,
                  maxLines: 10,
                  textDirection: TextDirection.rtl,
                  decoration: fieldDeco(kind == 'mistake' ? 'ماذا حدث (خطئي)' : 'الفكرة / الحل / الشرح'),
                ),
              ),
              if (kind == 'mistake') ...[
                const SizedBox(height: 10),
                Focus(
                  onFocusChange: (f) {
                    if (f) target = fix;
                  },
                  child: TextField(
                    controller: fix,
                    minLines: 2,
                    maxLines: 6,
                    decoration: fieldDeco('الصحيح'),
                  ),
                ),
              ],
              const SizedBox(height: 8),
              Text('رموز رياضية (تُدرج في الحقل الذي تكتب فيه):', style: TextStyle(color: C.sub, fontSize: 12)),
              const SizedBox(height: 4),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final sym in _symbols)
                    InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: () => insert(sym),
                      child: Container(
                        constraints: const BoxConstraints(minWidth: 38),
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(color: C.surface2, borderRadius: BorderRadius.circular(10)),
                        child: Text(sym, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              Text('قوالب LaTeX (تُعرض منسّقة بين علامتي \$):', style: TextStyle(color: C.sub, fontSize: 12)),
              const SizedBox(height: 4),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final t in _latex)
                    InkWell(
                      borderRadius: BorderRadius.circular(10),
                      onTap: () => insert(t[1]),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                        decoration: BoxDecoration(
                          color: C.accent.withValues(alpha: 0.16),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(t[0], style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: OutlinedButton.icon(
                  onPressed: () async {
                    final p = await _pickImage();
                    if (p != null) set(() => images.add(p));
                  },
                  icon: const Icon(Icons.add_photo_alternate_outlined),
                  label: const Text('إضافة صورة'),
                ),
              ),
              if (images.isNotEmpty) ...[
                const SizedBox(height: 8),
                SizedBox(
                  height: 72,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      for (final p in images)
                        Padding(
                          padding: const EdgeInsetsDirectional.only(end: 8),
                          child: Stack(
                            children: [
                              _thumb(p, 72),
                              PositionedDirectional(
                                top: 2,
                                end: 2,
                                child: GestureDetector(
                                  onTap: () => set(() => images.remove(p)),
                                  child: Container(
                                    decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                                    padding: const EdgeInsets.all(3),
                                    child: const Icon(Icons.close, size: 14, color: Colors.white),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () {
                  s.saveNote(
                    note: note,
                    notebookId: notebookId,
                    kind: kind,
                    title: title.text,
                    body: body.text,
                    fix: kind == 'mistake' ? fix.text : '',
                    chapter: chapter.text,
                    images: images,
                  );
                  Navigator.pop(ctx);
                },
                child: const Text('حفظ'),
              ),
              if (note != null)
                TextButton.icon(
                  onPressed: () {
                    s.removeNote(note);
                    Navigator.pop(ctx);
                  },
                  icon: Icon(Icons.delete_outline, color: C.danger),
                  label: Text('حذف', style: TextStyle(color: C.danger)),
                ),
            ],
          ),
        ),
      ),
    ),
  );
}
