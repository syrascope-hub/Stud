import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

const _palette = [
  0xFF4FC3F7, 0xFFFFB74D, 0xFFBA68C8, 0xFF81C784, 0xFFE57373, 0xFF64B5F6,
  0xFFF06292, 0xFFA1887F, 0xFF4DB6AC, 0xFFFF8A65, 0xFF9575CD, 0xFFAED581,
  0xFF4DD0E1, 0xFFFFD54F, 0xFF90A4AE, 0xFFDCE775,
];

Future<void> showSubjectsSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (ctx) {
      final s = StoreScope.of(ctx);
      return Padding(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('موادي', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              for (final x in s.subjects)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Container(
                    width: 42,
                    height: 42,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: x.c.withValues(alpha: 0.25), shape: BoxShape.circle),
                    child: Text(x.emoji, style: const TextStyle(fontSize: 20)),
                  ),
                  title: Text(x.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text('${s.itemsUsingSubject(x.id)} مهمة'),
                  onTap: () {
                    Navigator.pop(ctx);
                    showSubjectEditor(context, subject: x);
                  },
                ),
              const SizedBox(height: 8),
              FilledButton.icon(
                onPressed: () {
                  Navigator.pop(ctx);
                  showSubjectEditor(context);
                },
                icon: const Icon(Icons.add),
                label: const Text('إضافة مادة'),
              ),
            ],
          ),
        ),
      );
    },
  );
}

Future<void> showSubjectEditor(BuildContext context, {Subject? subject}) {
  final s = StoreScope.read(context);
  final name = TextEditingController(text: subject?.name ?? '');
  final emoji = TextEditingController(text: subject?.emoji ?? '📘');
  var color = subject?.color ?? _palette.first;
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => Padding(
        padding: EdgeInsets.fromLTRB(20, 4, 20, 20 + MediaQuery.of(ctx).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(subject == null ? 'مادة جديدة' : 'تعديل المادة',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 14),
              Row(
                children: [
                  SizedBox(
                    width: 84,
                    child: TextField(
                      controller: emoji,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 22),
                      decoration: fieldDeco('الرمز'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: TextField(controller: name, decoration: fieldDeco('اسم المادة'))),
                ],
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  for (final c in _palette)
                    GestureDetector(
                      onTap: () => set(() => color = c),
                      child: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: Color(c),
                          shape: BoxShape.circle,
                          border: Border.all(color: color == c ? C.text : Colors.transparent, width: 3),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 18),
              FilledButton(
                onPressed: () {
                  s.saveSubject(subject: subject, name: name.text, emoji: emoji.text, color: color);
                  Navigator.pop(ctx);
                },
                child: const Text('حفظ'),
              ),
              if (subject != null && s.subjects.length > 1)
                TextButton.icon(
                  onPressed: () {
                    Navigator.pop(ctx);
                    _confirmDelete(context, s, subject);
                  },
                  icon: Icon(Icons.delete_outline, color: C.danger),
                  label: Text('حذف المادة', style: TextStyle(color: C.danger)),
                ),
            ],
          ),
        ),
      ),
    ),
  );
}

Future<void> _confirmDelete(BuildContext context, AppStore s, Subject sub) {
  final n = s.itemsUsingSubject(sub.id);
  String? moveTo = n > 0 ? s.subjects.firstWhere((x) => x.id != sub.id).id : null;
  return showDialog<void>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        backgroundColor: C.surface,
        title: Text('حذف ${sub.name}؟'),
        content: n == 0
            ? const Text('لا توجد مهام على هذه المادة.')
            : Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('على المادة $n مهمة. ماذا تفعل بها؟'),
                  const SizedBox(height: 8),
                  _opt('حذفها', moveTo == null, () => set(() => moveTo = null)),
                  for (final x in s.subjects.where((x) => x.id != sub.id))
                    _opt('نقلها إلى ${x.emoji} ${x.name}', moveTo == x.id, () => set(() => moveTo = x.id)),
                ],
              ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              s.removeSubject(sub, moveTo: moveTo);
              Navigator.pop(ctx);
            },
            child: const Text('حذف'),
          ),
        ],
      ),
    ),
  );
}

Widget _opt(String t, bool sel, VoidCallback onTap) => ListTile(
      contentPadding: EdgeInsets.zero,
      dense: true,
      onTap: onTap,
      title: Text(t),
      trailing: Icon(sel ? Icons.radio_button_checked : Icons.radio_button_unchecked, color: sel ? C.accent : C.sub),
    );
