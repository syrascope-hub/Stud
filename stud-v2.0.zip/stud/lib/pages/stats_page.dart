import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

DateTime _plantDate(PlantRecord r) {
  final p = r.weekKey.split('-');
  return DateTime(int.parse(p[0]), int.parse(p[1]), int.parse(p[2]) + r.day);
}

class StatsPage extends StatelessWidget {
  const StatsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final alive = s.plants.where((p) => p.alive).toList();

    int sumWhere(bool Function(DateTime d) test) =>
        alive.where((p) => test(_plantDate(p))).fold(0, (a, b) => a + b.minutes);

    final todayMin = sumWhere((d) => d == today);
    final weekStart = weekStartOf(today);
    final weekMin = sumWhere((d) => !d.isBefore(weekStart));
    final monthMin = sumWhere((d) => d.year == today.year && d.month == today.month);
    final totalMin = alive.fold(0, (a, b) => a + b.minutes);

    // آخر 7 أيام
    final days = [for (var i = 6; i >= 0; i--) DateTime(today.year, today.month, today.day - i)];
    final perDay = [for (final d in days) sumWhere((x) => x == d)];
    final maxDay = perDay.fold(0, (a, b) => a > b ? a : b);

    // توزيع المواد خلال آخر 30 يوماً
    final since = DateTime(today.year, today.month, today.day - 29);
    final bySubject = <String, int>{};
    for (final p in alive) {
      if (_plantDate(p).isBefore(since)) continue;
      final k = p.subjectId ?? '';
      bySubject[k] = (bySubject[k] ?? 0) + p.minutes;
    }
    final subjEntries = bySubject.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final subjMax = subjEntries.isEmpty ? 1 : subjEntries.first.value;

    // المخطط مقابل المنجز هذا الأسبوع
    final wk = s.currentWeekKey;
    var planned = 0, doneMin = 0;
    for (var d = 0; d < 7; d++) {
      planned += s.plannedMinutes(d);
      doneMin += s.doneMinutes(d, wk);
    }

    final aliveCnt = alive.length;
    final deadCnt = s.plants.length - aliveCnt;

    return Scaffold(
      backgroundColor: C.bg,
      appBar: AppBar(
        backgroundColor: C.bg,
        surfaceTintColor: Colors.transparent,
        title: const Text('الإحصائيات', style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
        children: [
          Row(
            children: [
              Expanded(child: _tile('اليوم', fmtMin(todayMin), '☀️')),
              const SizedBox(width: 10),
              Expanded(child: _tile('هذا الأسبوع', fmtMin(weekMin), '📅')),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _tile('هذا الشهر', fmtMin(monthMin), '🗓️')),
              const SizedBox(width: 10),
              Expanded(child: _tile('الإجمالي', fmtMin(totalMin), '🏆')),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _tile('سلسلة الأيام', '${s.streak()} 🔥', '')),
              const SizedBox(width: 10),
              Expanded(child: _tile('الأشجار', '$aliveCnt 🌳 / $deadCnt 🥀', '')),
            ],
          ),
          const SizedBox(height: 16),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('آخر 7 أيام', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 14),
                SizedBox(
                  height: 140,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      for (var i = 0; i < 7; i++)
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(perDay[i] == 0 ? '' : '${(perDay[i] / 60).toStringAsFixed(1)}',
                                  style: TextStyle(fontSize: 10, color: C.sub)),
                              const SizedBox(height: 3),
                              Container(
                                margin: const EdgeInsets.symmetric(horizontal: 6),
                                height: maxDay == 0 ? 4 : (4 + 90 * perDay[i] / maxDay).toDouble(),
                                decoration: BoxDecoration(
                                  color: i == 6 ? C.accent : C.accent.withValues(alpha: 0.45),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(dayShort[weekdayIndex(days[i])], style: TextStyle(fontSize: 11, color: C.sub)),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Text('الأرقام بالساعات', style: TextStyle(fontSize: 11, color: C.sub)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('المخطط مقابل المنجز (هذا الأسبوع)',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: planned == 0 ? 0 : (doneMin / planned).clamp(0.0, 1.0).toDouble(),
                    minHeight: 12,
                    backgroundColor: C.surface2,
                    color: C.accent,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '${fmtMin(doneMin)} من ${fmtMin(planned)}'
                  '${planned == 0 ? '' : ' (${(100 * doneMin / planned).round()}٪)'}',
                  style: TextStyle(color: C.sub),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('وقت التركيز حسب المادة (آخر 30 يوماً)',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),
                if (subjEntries.isEmpty)
                  Text('لا توجد جلسات بعد. اختر مادة قبل بدء التركيز لتظهر هنا.', style: TextStyle(color: C.sub)),
                for (final e in subjEntries)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _subjectBar(s, e.key, e.value, subjMax),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tile(String label, String value, String emoji) => Panel(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(emoji.isEmpty ? label : '$emoji $label', style: TextStyle(color: C.sub, fontSize: 12.5)),
            const SizedBox(height: 6),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: AlignmentDirectional.centerStart,
              child: Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            ),
          ],
        ),
      );

  Widget _subjectBar(AppStore s, String id, int mins, int max) {
    final sub = id.isEmpty ? null : s.subjects.where((x) => x.id == id).firstOrNull;
    final color = sub?.c ?? C.sub;
    final name = id.isEmpty ? 'بدون وسم' : (sub == null ? 'مادة محذوفة' : '${sub.emoji} ${sub.name}');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.w600))),
            Text(fmtMin(mins), style: TextStyle(color: C.sub, fontSize: 12.5)),
          ],
        ),
        const SizedBox(height: 5),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: mins / max,
            minHeight: 9,
            backgroundColor: C.surface2,
            color: color,
          ),
        ),
      ],
    );
  }
}
