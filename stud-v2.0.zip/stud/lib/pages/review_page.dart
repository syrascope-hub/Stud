import 'package:flutter/material.dart';
import '../math_text.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

/// مراجعة متباعدة لأخطاء الدفتر: اليوم، 3 أيام، أسبوع، أسبوعان، شهر
class ReviewPage extends StatefulWidget {
  const ReviewPage({super.key});
  @override
  State<ReviewPage> createState() => _ReviewPageState();
}

class _ReviewPageState extends State<ReviewPage> {
  late final List<NoteEntry> _queue;
  int _i = 0;
  int _ok = 0;
  bool _reveal = false;

  @override
  void initState() {
    super.initState();
    _queue = StoreScope.read(context).reviewDue().take(8).toList();
  }

  void _answer(AppStore s, bool ok) {
    s.markReview(_queue[_i], ok);
    setState(() {
      if (ok) _ok++;
      _i++;
      _reveal = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    return Scaffold(
      backgroundColor: C.bg,
      appBar: AppBar(
        backgroundColor: C.bg,
        surfaceTintColor: Colors.transparent,
        title: const Text('مراجعة الأخطاء ✍️', style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: _body(s),
    );
  }

  Widget _body(AppStore s) {
    if (_queue.isEmpty) {
      return _center('لا أخطاء مستحقة للمراجعة اليوم 🎉', 'دوّن أخطاءك في الدفتر وستعود إليك في موعدها.');
    }
    if (_i >= _queue.length) {
      return _center('أحسنت! 🌟', 'راجعت ${_queue.length} ${_queue.length == 1 ? 'خطأ' : 'أخطاء'}، وأتقنت $_ok منها.',
          action: FilledButton(onPressed: () => Navigator.pop(context), child: const Text('إنهاء')));
    }
    final n = _queue[_i];
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        LinearProgressIndicator(
          value: _i / _queue.length,
          minHeight: 8,
          borderRadius: BorderRadius.circular(6),
          backgroundColor: C.surface2,
          color: C.accent,
        ),
        const SizedBox(height: 6),
        Text('${_i + 1} / ${_queue.length}', style: TextStyle(color: C.sub, fontSize: 12)),
        const SizedBox(height: 12),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (n.chapter.isNotEmpty) Text(n.chapter, style: TextStyle(color: C.sub, fontSize: 12.5)),
              if (n.title.isNotEmpty) ...[
                const SizedBox(height: 6),
                MathText(n.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              ],
              if (n.body.isNotEmpty) ...[
                const SizedBox(height: 8),
                MathText(n.body, style: const TextStyle(height: 1.7)),
              ],
              const SizedBox(height: 10),
              Text('حاول أن تحلّها أو تتذكر الصواب قبل أن تكشف الإجابة 🤔',
                  style: TextStyle(color: C.sub, fontSize: 12.5)),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (!_reveal)
          FilledButton(onPressed: () => setState(() => _reveal = true), child: const Text('اعرض الصحيح')),
        if (_reveal) ...[
          Panel(
            color: C.accent.withValues(alpha: 0.14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('✅ الصحيح', style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                n.fix.isEmpty
                    ? Text('لم تدوّن الصحيح لهذا الخطأ. أضفه من الدفتر.', style: TextStyle(color: C.sub))
                    : MathText(n.fix, style: const TextStyle(height: 1.7)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => _answer(s, false),
                  child: Text('أخطأت مجدداً ❌', style: TextStyle(color: C.danger)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton(onPressed: () => _answer(s, true), child: const Text('عرفتها ✅')),
              ),
            ],
          ),
        ],
      ],
    );
  }

  Widget _center(String title, String sub, {Widget? action}) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800), textAlign: TextAlign.center),
              const SizedBox(height: 10),
              Text(sub, style: TextStyle(color: C.sub, height: 1.7), textAlign: TextAlign.center),
              if (action != null) ...[const SizedBox(height: 20), action],
            ],
          ),
        ),
      );
}
