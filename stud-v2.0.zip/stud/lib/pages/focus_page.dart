import 'dart:async';
import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../art.dart';
import '../forest_view.dart' show sizeForMinutes;
import '../models.dart';
import '../notif_service.dart';
import 'challenges_ui.dart';
import '../settings.dart';
import '../sound.dart';
import '../store.dart';
import '../theme.dart';

class FocusPage extends StatefulWidget {
  const FocusPage({super.key});
  @override
  State<FocusPage> createState() => _FocusPageState();
}

class _FocusPageState extends State<FocusPage> with WidgetsBindingObserver {
  String plant = 'oak';
  int minutes = 25;
  String? subjectId;
  Timer? _tick;
  Timer? _bTick;
  int _celebrate = 0;
  int? _leftAt;
  bool _finishing = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final s = StoreScope.read(context);
      if (s.breakMinutes > 0) {
        if (s.breakActive) {
          _startBreakTicker();
        } else {
          s.endBreak();
        }
      }
      final a = s.active;
      if (a == null) return;
      _startTicker();
      s.autoResumeIfExpired();
      final eff = a.pausedAtMs ?? DateTime.now().millisecondsSinceEpoch;
      if (eff >= a.endMs) {
        _complete();
      } else {
        WakelockPlus.enable();
        if (a.pausedAtMs == null) SoundService.play(s.sound, vol: s.soundVol / 100);
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _tick?.cancel();
    _bTick?.cancel();
    super.dispose();
  }

  void _startTicker() {
    _tick?.cancel();
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      final st = StoreScope.read(context);
      final a = st.active;
      if (a == null) {
        _tick?.cancel();
        return;
      }
      if (st.autoResumeIfExpired()) {
        _rescheduleEnd(st);
        SoundService.play(st.sound, vol: st.soundVol / 100);
      }
      final eff = a.pausedAtMs ?? DateTime.now().millisecondsSinceEpoch;
      if (eff >= a.endMs) {
        _complete();
      } else {
        setState(() {});
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState st) {
    if (!mounted) return;
    final s = StoreScope.read(context);
    final a = s.active;
    if (a == null) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (st == AppLifecycleState.paused) {
      _leftAt = now;
    } else if (st == AppLifecycleState.resumed) {
      final left = _leftAt;
      _leftAt = null;
      if (s.autoResumeIfExpired()) {
        _rescheduleEnd(s);
        SoundService.play(s.sound, vol: s.soundVol / 100);
      }
      final eff = a.pausedAtMs ?? now;
      if (eff >= a.endMs) {
        _complete();
      } else if (left != null && s.strict && a.pausedAtMs == null && now - left > 8000) {
        _fail('خرجت من التطبيق أثناء التركيز فذبلت الشجرة 🥀');
      }
    }
  }

  void _startBreakTicker() {
    _bTick?.cancel();
    _bTick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      final s = StoreScope.read(context);
      if (s.breakMinutes == 0) {
        _bTick?.cancel();
        return;
      }
      if (!s.breakActive) {
        _bTick?.cancel();
        s.endBreak();
        NotifService.cancelBreak();
      } else {
        setState(() {});
      }
    });
  }

  void _startBreak(AppStore s, int minutes) {
    s.startBreak(minutes);
    if (s.notifSession) {
      NotifService.scheduleBreakEnd(DateTime.fromMillisecondsSinceEpoch(s.breakEndMs));
    }
    _startBreakTicker();
  }

  void _endBreak(AppStore s) {
    _bTick?.cancel();
    s.endBreak();
    NotifService.cancelBreak();
  }

  void _rescheduleEnd(AppStore s) {
    final a = s.active;
    if (a != null && s.notifSession) {
      NotifService.scheduleSessionEnd(DateTime.fromMillisecondsSinceEpoch(a.endMs), plantById(a.type).name);
    }
  }

  void _pause(AppStore s) {
    s.pauseSession();
    NotifService.cancelSession();
    SoundService.stop();
  }

  void _resume(AppStore s) {
    s.resumeSession();
    _rescheduleEnd(s);
    SoundService.play(s.sound, vol: s.soundVol / 100);
  }

  void _autoPlant(AppStore s, String? id) {
    if (!s.perSubjectPlant || id == null) return;
    final open = plantTypes.where((p) => s.unlocked.contains(p.id)).toList();
    if (open.isEmpty) return;
    final idx = s.subjects.indexWhere((x) => x.id == id);
    plant = open[(idx < 0 ? 0 : idx) % open.length].id;
  }

  void _begin(AppStore s) {
    s.startSession(plant, minutes, subjectId);
    if (s.notifSession && s.active != null) {
      NotifService.scheduleSessionEnd(
          DateTime.fromMillisecondsSinceEpoch(s.active!.endMs), plantById(plant).name);
    }
    WakelockPlus.enable();
    SoundService.play(s.sound, vol: s.soundVol / 100);
    _startTicker();
  }

  void _complete() {
    if (_finishing) return;
    final s = StoreScope.read(context);
    if (s.active == null) return;
    _finishing = true;
    _tick?.cancel();
    final p = plantById(s.active!.type);
    final mins = s.active!.minutes;
    _celebrate++;
    s.finishSession(true);
    NotifService.cancelSession();
    WakelockPlus.disable();
    SoundService.stop();
    _finishing = false;
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: Text('${p.emoji} نمت شجرتك!'),
        content: Text(
            'أنهيت ${fmtMin(mins)} من التركيز وربحت $mins عملة 🪙 و${(mins ~/ 10).clamp(1, 12)} قطرة ماء 💧'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('متابعة')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              _startBreak(s, s.suggestedBreak());
            },
            child: Text('☕ استراحة ${s.suggestedBreak()} د'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(ctx);
              s.setTab(2);
            },
            child: const Text('عرض الغابة'),
          ),
        ],
      ),
    );
  }

  void _fail(String why) {
    final s = StoreScope.read(context);
    if (s.active == null) return;
    _tick?.cancel();
    s.finishSession(false);
    NotifService.cancelSession();
    WakelockPlus.disable();
    SoundService.stop();
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('🥀 ذبلت الشجرة'),
        content: Text(why),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('حسناً'))],
      ),
    );
  }

  Future<void> _giveUp() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('التخلي عن الجلسة؟'),
        content: const Text('ستذبل الشجرة وتبقى في الغابة كشجرة ميتة.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('أكمل التركيز')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('تخلَّ', style: TextStyle(color: C.danger)),
          ),
        ],
      ),
    );
    if (ok == true && mounted) _fail('تخليت عن الجلسة قبل الانتهاء.');
  }

  // ---------------- اختيار النبتة ----------------
  void _pickPlant(AppStore s) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  const Text('اختر نبتتك', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                  const Spacer(),
                  Text('🪙 ${s.coins}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                ],
              ),
              const SizedBox(height: 12),
              Flexible(
                child: GridView.count(
                  shrinkWrap: true,
                  crossAxisCount: 4,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 0.82,
                  children: [
                    for (final p in plantTypes)
                      GestureDetector(
                        onTap: () {
                          if (s.unlocked.contains(p.id)) {
                            setState(() => plant = p.id);
                            Navigator.pop(ctx);
                          } else if (s.coins >= p.price) {
                            s.buyPlant(p.id);
                            setState(() => plant = p.id);
                            Navigator.pop(ctx);
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('تحتاج ${p.price - s.coins} عملة إضافية لفتح ${p.name}')),
                            );
                          }
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color: plant == p.id ? C.accent.withValues(alpha: 0.2) : C.surface2,
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: plant == p.id ? C.accent : Colors.transparent, width: 1.6),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Opacity(
                                opacity: s.unlocked.contains(p.id) ? 1 : 0.45,
                                child: Text(p.emoji, style: const TextStyle(fontSize: 30)),
                              ),
                              const SizedBox(height: 4),
                              Text(p.name, style: const TextStyle(fontSize: 11), maxLines: 1, overflow: TextOverflow.ellipsis),
                              Text(
                                s.unlocked.contains(p.id) ? 'مفتوحة' : '🪙 ${p.price}',
                                style: TextStyle(fontSize: 11, color: C.sub),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _pickSound(AppStore s) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) {
        final st = StoreScope.of(ctx);
        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('أصوات هادئة أثناء التركيز', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text('اختر صوتاً أو أكثر ليُمزجا معاً', style: TextStyle(color: C.sub, fontSize: 12.5)),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  for (final o in soundOptions)
                    FilterChip(
                      label: Text('${o[2]} ${o[1]}'),
                      selected: o[0] == 'none' ? st.soundSet.isEmpty : st.soundSet.contains(o[0]),
                      onSelected: (_) {
                        st.toggleSound(o[0]);
                        if (st.active != null && !st.isPaused) {
                          SoundService.play(st.sound, vol: st.soundVol / 100);
                        }
                      },
                    ),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  const Icon(Icons.volume_down),
                  Expanded(
                    child: Slider(
                      value: st.soundVol.toDouble(),
                      min: 10,
                      max: 100,
                      divisions: 9,
                      onChanged: (v) {
                        st.setSoundVolLive(v.round());
                        SoundService.setVolume(v / 100);
                      },
                      onChangeEnd: (v) => st.setSoundVol(v.round()),
                    ),
                  ),
                  const Icon(Icons.volume_up),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    final pr = s.preset;
    if (pr != null) {
      if (pr.subjectId != null) {
        subjectId = pr.subjectId;
        _autoPlant(s, pr.subjectId);
      }
      if (pr.minutes != null) minutes = ((pr.minutes! / 5).round() * 5).clamp(5, 120).toInt();
      s.preset = null;
    }
    if (!s.unlocked.contains(plant)) plant = 'oak';
    if (s.breakActive && s.active == null) return _breakView(s);
    final running = s.active != null;
    final a = s.active;
    final now = (running ? a!.pausedAtMs : null) ?? DateTime.now().millisecondsSinceEpoch;
    final totalMin = running ? a!.minutes : minutes;
    final g = running ? ((now - a!.startMs) / (a.minutes * 60000)).clamp(0.0, 1.0).toDouble() : 1.0;
    final remSec = running ? ((a!.endMs - now) / 1000).ceil().clamp(0, 999999).toInt() : minutes * 60;
    final mm = (remSec ~/ 60).toString().padLeft(2, '0');
    final ss = (remSec % 60).toString().padLeft(2, '0');
    final pauseLeft = (running && a!.pausedAtMs != null)
        ? ((a!.pausedAtMs! + AppStore.maxPauseMs - DateTime.now().millisecondsSinceEpoch) / 1000).ceil().clamp(0, 300).toInt()
        : 0;
    final curType = running ? a!.type : plant;
    final sub = (running ? a!.subjectId : subjectId) == null
        ? null
        : s.subjectById(running ? a!.subjectId! : subjectId!);
    final w = MediaQuery.of(context).size.width;
    final circle = (w * 0.74).clamp(200.0, 320.0).toDouble();

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [C.stage, Color.lerp(C.stage, Colors.black, 0.18)!],
        ),
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
          child: Column(
            children: [
              Row(
                children: [
                  IconButton(
                    onPressed: () => showSettingsSheet(context),
                    icon: const Icon(Icons.settings_outlined, color: Colors.white),
                  ),
                  Stack(
                    children: [
                      IconButton(
                        onPressed: () => showChallengesSheet(context),
                        icon: const Icon(Icons.emoji_events_outlined, color: Colors.white),
                      ),
                      if (s.claimableChallenges > 0)
                        Positioned(
                          top: 8,
                          right: 8,
                          child: Container(
                            width: 11,
                            height: 11,
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFD166),
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 1.5),
                            ),
                          ),
                        ),
                    ],
                  ),
                  const Spacer(),
                  _pill('🔥 ${s.streak()}'),
                  const SizedBox(width: 8),
                  _pill('💧 ${s.water}'),
                  const SizedBox(width: 8),
                  _pill('🪙 ${s.coins}'),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                running ? 'ابقَ مركّزاً… شجرتك تنمو 🌱' : 'ابدأ الزراعة اليوم!',
                style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 18),
              GestureDetector(
                onTap: running ? null : () => _pickPlant(s),
                child: TimerCircle(
                  size: circle,
                  progress: running ? g : 0,
                  type: curType,
                  growth: running ? g : 1.0,
                  plantSize: sizeForMinutes(totalMin),
                  lite: s.lowPower,
                  celebrate: _celebrate,
                ),
              ),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (!running)
                    IconButton(
                      onPressed: () => setState(() => minutes = (minutes - 5).clamp(5, 120).toInt()),
                      icon: const Icon(Icons.remove_circle_outline, color: Colors.white70, size: 30),
                    ),
                  Text(
                    '$mm:$ss',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 58,
                      fontWeight: FontWeight.w300,
                      fontFeatures: [FontFeature.tabularFigures()],
                    ),
                  ),
                  if (!running)
                    IconButton(
                      onPressed: () => setState(() => minutes = (minutes + 5).clamp(5, 120).toInt()),
                      icon: const Icon(Icons.add_circle_outline, color: Colors.white70, size: 30),
                    ),
                ],
              ),
              if (sub != null && running)
                Text('${sub.emoji} ${sub.name}', style: const TextStyle(color: Colors.white70)),
              if (!running) ...[
                const SizedBox(height: 4),
                SizedBox(
                  height: 40,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      _tag('بدون وسم', subjectId == null, () => setState(() => subjectId = null)),
                      for (final x in s.subjects)
                        _tag('${x.emoji} ${x.name}', subjectId == x.id, () => setState(() {
                          subjectId = x.id;
                          _autoPlant(s, x.id);
                        })),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 18),
              if (!running)
                FilledButton(
                  style: bigButton(bg: const Color(0xFF6FD3A8), fg: const Color(0xFF0B3B2A)),
                  onPressed: () => _begin(s),
                  child: const Text('ازرع'),
                )
              else ...[
                if (s.isPaused) ...[
                  Text(
                    'إيقاف مؤقت — يُستأنف تلقائياً بعد ${pauseLeft ~/ 60}:${(pauseLeft % 60).toString().padLeft(2, '0')}',
                    style: const TextStyle(color: Colors.white70, fontSize: 13),
                  ),
                  const SizedBox(height: 8),
                  FilledButton(
                    style: bigButton(bg: const Color(0xFF6FD3A8), fg: const Color(0xFF0B3B2A)),
                    onPressed: () => _resume(s),
                    child: const Text('استئناف'),
                  ),
                ] else if (s.canPause) ...[
                  FilledButton(
                    style: bigButton(bg: Colors.white.withValues(alpha: 0.28), fg: Colors.white),
                    onPressed: () => _pause(s),
                    child: const Text('إيقاف مؤقت (حتى 5 دقائق)'),
                  ),
                  const SizedBox(height: 8),
                ],
                FilledButton(
                  style: bigButton(bg: Colors.white.withValues(alpha: 0.18), fg: Colors.white),
                  onPressed: _giveUp,
                  child: const Text('تخلَّ'),
                ),
              ],
              const SizedBox(height: 6),
              TextButton.icon(
                onPressed: () => _pickSound(s),
                icon: const Icon(Icons.headphones, color: Colors.white70),
                label: Text(
                  soundLabel(s.soundSet),
                  style: const TextStyle(color: Colors.white70),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _breakView(AppStore s) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final remSec = ((s.breakEndMs - now) / 1000).ceil().clamp(0, 999999).toInt();
    final mm = (remSec ~/ 60).toString().padLeft(2, '0');
    final ss = (remSec % 60).toString().padLeft(2, '0');
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [C.stage, Color.lerp(C.stage, Colors.black, 0.18)!],
        ),
      ),
      child: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('☕', style: TextStyle(fontSize: 72)),
                const SizedBox(height: 8),
                const Text('وقت الاستراحة',
                    style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                const Text('قم وتحرّك قليلاً، اشرب ماءً، وأرح عينيك عن الشاشة',
                    textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, height: 1.6)),
                const SizedBox(height: 18),
                Text(
                  '$mm:$ss',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 64,
                    fontWeight: FontWeight.w300,
                    fontFeatures: [FontFeature.tabularFigures()],
                  ),
                ),
                const SizedBox(height: 22),
                FilledButton(
                  style: bigButton(bg: const Color(0xFF6FD3A8), fg: const Color(0xFF0B3B2A)),
                  onPressed: () => _endBreak(s),
                  child: const Text('جاهز، لنبدأ جلسة جديدة'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _pill(String t) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(color: Colors.black.withValues(alpha: 0.22), borderRadius: BorderRadius.circular(20)),
        child: Text(t, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      );

  Widget _tag(String t, bool sel, VoidCallback onTap) => Padding(
        padding: const EdgeInsetsDirectional.only(end: 8),
        child: GestureDetector(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: sel ? Colors.white : Colors.white.withValues(alpha: 0.16),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(t, style: TextStyle(color: sel ? const Color(0xFF1C5A44) : Colors.white, fontWeight: FontWeight.w600)),
          ),
        ),
      );
}
