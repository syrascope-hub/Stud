import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

Future<void> showChallengesSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (ctx) {
      final s = StoreScope.of(ctx);
      return Padding(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('تحديات اليوم 🏅', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text('تتجدد كل يوم. أكملها واستلم العملات وقطرات الماء.',
                  style: TextStyle(color: C.sub, fontSize: 12.5)),
              const SizedBox(height: 12),
              for (final c in dailyChallenges) _row(ctx, s, c),
            ],
          ),
        ),
      );
    },
  );
}

Widget _row(BuildContext ctx, AppStore s, Challenge c) {
  final p = s.challengeProgress(c);
  final done = p >= c.target;
  final claimed = s.isClaimed(c);
  final shown = p > c.target ? c.target : p;
  return Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Panel(
      color: claimed ? C.surface2 : null,
      child: Row(
        children: [
          Text(c.emoji, style: const TextStyle(fontSize: 28)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(c.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: shown / c.target,
                    minHeight: 8,
                    backgroundColor: C.surface2,
                    color: C.accent,
                  ),
                ),
                const SizedBox(height: 4),
                Text('$shown / ${c.target}  ·  🪙 ${c.coins}  ·  💧 ${c.water}',
                    style: TextStyle(color: C.sub, fontSize: 12)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          if (claimed)
            Icon(Icons.check_circle, color: C.accent)
          else
            FilledButton(
              onPressed: done ? () => s.claimChallenge(c) : null,
              child: const Text('استلم'),
            ),
        ],
      ),
    ),
  );
}
