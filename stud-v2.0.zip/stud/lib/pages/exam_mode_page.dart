import 'dart:async';
import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

/// وضع الدورة الامتحانية: مؤقت بوقت الامتحان الحقيقي بلا إيقاف، ثم تسجيل العلامة وتتبّع التطور.
class ExamModePage extends StatefulWidget {
  const ExamModePage({super.key});
  @override
  State<ExamModePage> createState() => _ExamModePageState();
}

class _ExamModePageState extends State<ExamModePage> {
  final _name = TextEditingController();
  int _minutes = 180;
  bool _running = false;
  int _startMs = 0;
  Timer? _tick;

  @override
  void dispose() {
    _tick?.cancel();
    _name.dispose();
    WakelockPlus.disable();
    super.dispose();
  }

  int get _endMs => _startMs + _minutes * 60000;

  Future<void> _start() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('بدء الدورة الامتحانية؟'),
        content: Text('سيعمل المؤقت ${fmtMin(_minutes)} بلا إيقاف مؤقت. ضع هاتفك جانباً وأحضر الورقة والقلم ✏️'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ابدأ')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    WakelockPlus.enable();
    setState(() {
      _running = true;
      _startMs = DateTime.now().millisecondsSinceEpoch;
    });
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (DateTime.now().millisecondsSinceEpoch >= _endMs) {
        _finish(timeUp: true);
      } else {
        setState(() {});
      }
    });
  }

  Future<void> _finish({bool timeUp = false}) async {
    _tick?.cancel();
    WakelockPlus.disable();
    final used = ((DateTime.now().millisecondsSinceEpoch - _startMs) / 60000).round().clamp(1, _minutes).toInt();
    setState(() => _running = false);
    if (!mounted) return;
    final score = TextEditingController();
    final max = TextEditingController(text: '100');
    final saved = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: Text(timeUp ? '⏰ انتهى الوقت' : 'أنهيت الدورة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('بعد تصحيح الدورة، سجّل علامتك لتتبّع تطورك:', style: TextStyle(color: C.sub, fontSize: 13)),
            const SizedBox(height: 10),
            TextField(
              controller: score,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: fieldDeco('علامتي'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: max,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: fieldDeco('من'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لاحقاً')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (saved == true && mounted) {
      final sc = double.tryParse(score.text.trim().replaceAll(',', '.'));
      final mx = double.tryParse(max.text.trim().replaceAll(',', '.')) ?? 100;
      if (sc != null) {
        StoreScope.read(context).addExamRun(
          name: _name.text,
          plannedMin: _minutes,
          usedMin: used,
          score: sc,
          max: mx,
        );
      }
    }
  }

  Future<bool> _confirmLeave() async {
    final r = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('التخلي عن الدورة؟'),
        content: const Text('لن تُسجَّل هذه الدورة.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('أكمل')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('تخلَّ', style: TextStyle(color: C.danger)),
          ),
        ],
      ),
    );
    return r == true;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_running,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        final nav = Navigator.of(context);
        if (await _confirmLeave()) {
          _tick?.cancel();
          WakelockPlus.disable();
          nav.pop();
        }
      },
      child: _running ? _runView() : _setupView(),
    );
  }

  Widget _runView() {
    final remSec = ((_endMs - DateTime.now().millisecondsSinceEpoch) / 1000).ceil().clamp(0, 999999).toInt();
    final h = (remSec ~/ 3600).toString().padLeft(2, '0');
    final m = ((remSec % 3600) ~/ 60).toString().padLeft(2, '0');
    final sec = (remSec % 60).toString().padLeft(2, '0');
    return Scaffold(
      backgroundColor: const Color(0xFF14352A),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(_name.text.trim().isEmpty ? 'دورة امتحانية' : _name.text.trim(),
                    style: const TextStyle(color: Colors.white70, fontSize: 16)),
                const SizedBox(height: 14),
                Text(
                  '$h:$m:$sec',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 56,
                    fontWeight: FontWeight.w300,
                    fontFeatures: [FontFeature.tabularFigures()],
                  ),
                ),
                const SizedBox(height: 10),
                const Text('بالتوفيق ✏️\nلا إيقاف مؤقت في الامتحان الحقيقي',
                    textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, height: 1.7)),
                const SizedBox(height: 28),
                FilledButton(
                  style: bigButton(bg: Colors.white.withValues(alpha: 0.18), fg: Colors.white),
                  onPressed: () => _finish(),
                  child: const Text('أنهيت قبل الوقت'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _setupView() {
    final s = StoreScope.of(context);
    final runs = [...s.examRuns]..sort((a, b) => b.ts.compareTo(a.ts));
    final avg = runs.isEmpty ? 0 : runs.fold<double>(0, (a, b) => a + b.pct) / runs.length;
    return Scaffold(
      backgroundColor: C.bg,
      appBar: AppBar(
        backgroundColor: C.bg,
        surfaceTintColor: Colors.transparent,
        title: const Text('الدورة الامتحانية 📝', style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
        children: [
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(controller: _name, decoration: fieldDeco('اسم الدورة', hint: 'مثال: رياضيات — دورة 2024')),
                const SizedBox(height: 14),
                Text('مدة الامتحان', style: TextStyle(color: C.sub)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final m in const [60, 90, 120, 150, 180, 240])
                      ChoiceChip(
                        label: Text(fmtMin(m)),
                        selected: _minutes == m,
                        onSelected: (_) => setState(() => _minutes = m),
                      ),
                  ],
                ),
                const SizedBox(height: 16),
                FilledButton(onPressed: _start, child: const Text('ابدأ الدورة')),
              ],
            ),
          ),
          const SizedBox(height: 16),
          if (runs.isNotEmpty) ...[
            Row(
              children: [
                const Text('سجل الدورات', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                const Spacer(),
                Text('المتوسط ${avg.round()}٪', style: TextStyle(color: C.sub)),
              ],
            ),
            const SizedBox(height: 8),
            for (final r in runs.take(15))
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: GestureDetector(
                  onLongPress: () => s.removeExamRun(r),
                  child: Panel(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(child: Text(r.name, style: const TextStyle(fontWeight: FontWeight.w700))),
                            Text('${r.score % 1 == 0 ? r.score.toInt() : r.score} / ${r.max % 1 == 0 ? r.max.toInt() : r.max}',
                                style: const TextStyle(fontWeight: FontWeight.w800)),
                          ],
                        ),
                        const SizedBox(height: 8),
                        LinearProgressIndicator(
                          value: r.pct / 100,
                          minHeight: 8,
                          borderRadius: BorderRadius.circular(6),
                          backgroundColor: C.surface2,
                          color: r.pct >= 80 ? C.accent : (r.pct >= 60 ? C.amber : C.danger),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '${DateTime.fromMillisecondsSinceEpoch(r.ts).day}/${DateTime.fromMillisecondsSinceEpoch(r.ts).month} · '
                          '${fmtMin(r.usedMin)} من ${fmtMin(r.plannedMin)} · ${r.pct.round()}٪',
                          style: TextStyle(color: C.sub, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            Text('اضغط مطوّلاً على دورة لحذفها.', style: TextStyle(color: C.sub, fontSize: 11.5)),
          ] else
            Padding(
              padding: const EdgeInsets.all(24),
              child: Text('لا دورات مسجّلة بعد. أول دورة تحلّها ستظهر هنا مع علامتك.',
                  textAlign: TextAlign.center, style: TextStyle(color: C.sub, height: 1.7)),
            ),
        ],
      ),
    );
  }
}
