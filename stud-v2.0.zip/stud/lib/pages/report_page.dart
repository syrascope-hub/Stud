import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

DateTime _pd(PlantRecord r) {
  final p = r.weekKey.split('-');
  return DateTime(int.parse(p[0]), int.parse(p[1]), int.parse(p[2]) + r.day);
}

/// تقرير الأسبوع: تركيزك مقارنة بالأسبوع الماضي، أفضل يوم، المادة المهملة، الأخطاء، الدورات
class ReportPage extends StatelessWidget {
  const ReportPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    final now = DateTime.now();
    final ws = weekStartOf(DateTime(now.year, now.month, now.day));
    final next = DateTime(ws.year, ws.month, ws.day + 7);
    final prev = DateTime(ws.year, ws.month, ws.day - 7);
    final alive = s.plants.where((p) => p.alive).toList();

    int minutesIn(DateTime a, DateTime b) =>
        alive.where((p) => !_pd(p).isBefore(a) && _pd(p).isBefore(b)).fold(0, (x, y) => x + y.minutes);

    final thisWeek = minutesIn(ws, next);
    final lastWeek = minutesIn(prev, ws);
    final perDay = [
      for (var i = 0; i < 7; i++)
        minutesIn(DateTime(ws.year, ws.month, ws.day + i), DateTime(ws.year, ws.month, ws.day + i + 1))
    ];
    var best = 0;
    for (var i = 1; i < 7; i++) {
      if (perDay[i] > perDay[best]) best = i;
    }

    final wk = s.currentWeekKey;
    final rows = <List<Object>>[]; // [subject, planned, done]
    for (final sub in s.subjects) {
      final items = s.plan.where((p) => p.subjectId == sub.id);
      final planned = items.fold(0, (a, b) => a + b.minutes);
      final done = items.where((p) => s.isDone(p, wk)).fold(0, (a, b) => a + b.minutes);
      if (planned > 0) rows.add([sub, planned, done]);
    }
    rows.sort((a, b) => ((a[2] as int) / (a[1] as int)).compareTo((b[2] as int) / (b[1] as int)));

    final treesAlive = s.plants.where((p) => p.alive && !_pd(p).isBefore(ws) && _pd(p).isBefore(next)).length;
    final treesDead = s.plants.where((p) => !p.alive && !_pd(p).isBefore(ws) && _pd(p).isBefore(next)).length;
    final newMistakes = s.notes
        .where((n) => n.kind == 'mistake' && n.ts >= ws.millisecondsSinceEpoch)
        .length;
    final runs = s.examRuns.where((r) => r.ts >= ws.millisecondsSinceEpoch).toList();

    final diff = thisWeek - lastWeek;
    final String headline;
    if (lastWeek == 0 && thisWeek == 0) {
      headline = 'ابدأ جلسة تركيز لتظهر أرقام أسبوعك 🌱';
    } else if (diff > 0) {
      headline = 'تركيزك أعلى بـ ${fmtMin(diff)} من الأسبوع الماضي 👏';
    } else if (diff < 0) {
      headline = 'تركيزك أقل بـ ${fmtMin(-diff)} من الأسبوع الماضي. ما زال أمامك وقت 💪';
    } else {
      headline = 'تركيزك مماثل للأسبوع الماضي ⚖️';
    }

    return Scaffold(
      backgroundColor: C.bg,
      appBar: AppBar(
        backgroundColor: C.bg,
        surfaceTintColor: Colors.transparent,
        title: const Text('تقرير الأسبوع 🗓️', style: TextStyle(fontWeight: FontWeight.w800)),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
        children: [
          Panel(
            color: C.surface2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(fmtMin(thisWeek), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
                Text('وقت التركيز هذا الأسبوع', style: TextStyle(color: C.sub)),
                const SizedBox(height: 10),
                Text(headline, style: const TextStyle(fontWeight: FontWeight.w700, height: 1.5)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _tile('🔥 السلسلة', '${s.streak()} يوم')),
              const SizedBox(width: 10),
              Expanded(child: _tile('🌳 الأشجار', '$treesAlive حيّة / $treesDead ذابلة')),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _tile('⭐ أفضل يوم', perDay[best] == 0 ? '—' : '${dayNames[best]} (${fmtMin(perDay[best])})'),
              ),
              const SizedBox(width: 10),
              Expanded(child: _tile('❌ أخطاء جديدة', '$newMistakes')),
            ],
          ),
          const SizedBox(height: 12),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('إنجاز المخطط حسب المادة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                if (rows.isNotEmpty && (rows.first[2] as int) < (rows.first[1] as int))
                  Text('أكثر مادة مهملة: ${(rows.first[0] as Subject).emoji} ${(rows.first[0] as Subject).name}',
                      style: TextStyle(color: C.danger, fontWeight: FontWeight.w700, fontSize: 13)),
                const SizedBox(height: 10),
                for (final r in rows)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text('${(r[0] as Subject).emoji} ${(r[0] as Subject).name}',
                                  style: const TextStyle(fontWeight: FontWeight.w600)),
                            ),
                            Text('${fmtMin(r[2] as int)} / ${fmtMin(r[1] as int)}',
                                style: TextStyle(color: C.sub, fontSize: 12.5)),
                          ],
                        ),
                        const SizedBox(height: 5),
                        LinearProgressIndicator(
                          value: ((r[2] as int) / (r[1] as int)).clamp(0.0, 1.0).toDouble(),
                          minHeight: 8,
                          borderRadius: BorderRadius.circular(6),
                          backgroundColor: C.surface2,
                          color: (r[0] as Subject).c,
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          if (runs.isNotEmpty) ...[
            const SizedBox(height: 12),
            Panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('دورات هذا الأسبوع', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  for (final r in runs) Text('• ${r.name}: ${r.pct.round()}٪', style: const TextStyle(height: 1.8)),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _tile(String label, String value) => Panel(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(color: C.sub, fontSize: 12.5)),
            const SizedBox(height: 6),
            Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
          ],
        ),
      );
}
