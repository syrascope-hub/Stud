import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

const _monthsAr = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
];

String fmtDateAr(DateTime d) => '${d.day} ${_monthsAr[d.month - 1]} ${d.year}';

/// بطاقة العدّاد التنازلي لآخر امتحان وأقرب امتحان
class ExamCountdownCard extends StatelessWidget {
  const ExamCountdownCard({super.key});

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    final last = s.lastExam;
    final next = s.nextExam;
    return GestureDetector(
      onTap: () => showExamsSheet(context),
      child: Panel(
        color: C.surface2,
        child: last == null
            ? Row(
                children: [
                  const Text('🎓', style: TextStyle(fontSize: 26)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text('أضف تاريخ امتحانك لتظهر الأيام المتبقية', style: TextStyle(color: C.sub)),
                  ),
                  Icon(Icons.add_circle_outline, color: C.accent),
                ],
              )
            : _body(last, next),
      ),
    );
  }

  Widget _body(Exam last, Exam? next) {
    final d = last.daysLeft();
    final over = d < 0;
    final weeks = d ~/ 7;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 74,
              height: 74,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: C.accent, borderRadius: BorderRadius.circular(20)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    over ? '✓' : '${d < 0 ? 0 : d}',
                    style: TextStyle(color: C.onAccent, fontSize: 28, fontWeight: FontWeight.w800, height: 1.1),
                  ),
                  Text(over ? 'انتهى' : (d == 1 ? 'يوم' : 'يوماً'),
                      style: TextStyle(color: C.onAccent, fontSize: 12, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(last.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 2),
                  Text(
                    '${fmtDateAr(last.date)}${last.estimated ? ' · تاريخ تقديري' : ''}',
                    style: TextStyle(color: C.sub, fontSize: 12.5),
                  ),
                  if (!over && d >= 7)
                    Text('≈ $weeks أسبوعاً', style: TextStyle(color: C.sub, fontSize: 12.5)),
                ],
              ),
            ),
            Icon(Icons.edit_calendar_outlined, color: C.sub),
          ],
        ),
        if (next != null && next.id != last.id) ...[
          const SizedBox(height: 10),
          Text(
            'الأقرب: ${next.name} — بعد ${next.daysLeft()} ${next.daysLeft() == 1 ? 'يوم' : 'يوماً'}',
            style: TextStyle(color: C.text, fontSize: 13, fontWeight: FontWeight.w600),
          ),
        ],
      ],
    );
  }
}

Future<void> showExamsSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (ctx) {
      final s = StoreScope.of(ctx);
      final list = s.sortedExams;
      return Padding(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('الامتحانات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text('يظهر العدّاد لآخر امتحان في القائمة. غيّر التاريخ عندما تصدر الوزارة البرنامج الرسمي.',
                  style: TextStyle(color: C.sub, fontSize: 12.5, height: 1.5)),
              const SizedBox(height: 12),
              if (list.isEmpty) Text('لا توجد امتحانات بعد.', style: TextStyle(color: C.sub)),
              for (final e in list)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(e.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(
                    '${fmtDateAr(e.date)}${e.estimated ? ' · تقديري' : ''} · '
                    '${e.daysLeft() < 0 ? 'انتهى' : 'بعد ${e.daysLeft()} يوم'}',
                  ),
                  onTap: () {
                    Navigator.pop(ctx);
                    showExamEditor(context, exam: e);
                  },
                  trailing: IconButton(
                    icon: Icon(Icons.delete_outline, color: C.danger),
                    onPressed: () {
                      s.removeExam(e);
                      Navigator.pop(ctx);
                    },
                  ),
                ),
              const SizedBox(height: 8),
              FilledButton.icon(
                onPressed: () {
                  Navigator.pop(ctx);
                  showExamEditor(context);
                },
                icon: const Icon(Icons.add),
                label: const Text('إضافة امتحان'),
              ),
            ],
          ),
        ),
      );
    },
  );
}

Future<void> showExamEditor(BuildContext context, {Exam? exam}) {
  final s = StoreScope.read(context);
  final name = TextEditingController(text: exam?.name ?? '');
  var date = exam?.date ?? DateTime.now().add(const Duration(days: 30));
  var estimated = exam?.estimated ?? false;
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => Padding(
        padding: EdgeInsets.fromLTRB(20, 4, 20, 20 + MediaQuery.of(ctx).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(exam == null ? 'امتحان جديد' : 'تعديل الامتحان',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 14),
              TextField(controller: name, decoration: fieldDeco('اسم الامتحان', hint: 'مثال: الرياضيات')),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () async {
                  final p = await showDatePicker(
                    context: ctx,
                    initialDate: date,
                    firstDate: DateTime(2024),
                    lastDate: DateTime(2035),
                  );
                  if (p != null) set(() => date = p);
                },
                icon: const Icon(Icons.event),
                label: Text(fmtDateAr(date)),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: estimated,
                onChanged: (v) => set(() => estimated = v),
                title: const Text('تاريخ تقديري'),
              ),
              const SizedBox(height: 6),
              FilledButton(
                onPressed: () {
                  s.saveExam(exam: exam, name: name.text, date: date, estimated: estimated);
                  Navigator.pop(ctx);
                },
                child: const Text('حفظ'),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
