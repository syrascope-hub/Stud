import 'package:flutter/material.dart';
import 'package:flutter_math_fork/flutter_math.dart';

/// نص عادي يمكن أن يحتوي معادلات LaTeX بين علامتي $ ... $ فتُعرض منسّقة.
/// مثال: النهاية $\lim_{x\to 0}\frac{\sin x}{x}=1$
class MathText extends StatelessWidget {
  final String text;
  final TextStyle? style;
  final int? maxLines;
  const MathText(this.text, {super.key, this.style, this.maxLines});

  @override
  Widget build(BuildContext context) {
    final st = style ?? DefaultTextStyle.of(context).style;
    final overflow = maxLines == null ? null : TextOverflow.ellipsis;
    if (!text.contains(r'$')) {
      return Text(text, style: st, maxLines: maxLines, overflow: overflow);
    }
    final parts = text.split(r'$');
    final closed = parts.length.isOdd; // عدد فردي من الأجزاء = كل $ له إغلاق
    final spans = <InlineSpan>[];
    for (var i = 0; i < parts.length; i++) {
      final p = parts[i];
      if (p.isEmpty) continue;
      final isMath = i.isOdd && (closed || i < parts.length - 1);
      if (!isMath) {
        spans.add(TextSpan(text: (i.isOdd && !closed && i == parts.length - 1) ? '\$$p' : p));
        continue;
      }
      spans.add(WidgetSpan(
        alignment: PlaceholderAlignment.middle,
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: Math.tex(
            p,
            textStyle: st,
            mathStyle: MathStyle.text,
            onErrorFallback: (_) => Text(p, style: st),
          ),
        ),
      ));
    }
    return Text.rich(TextSpan(style: st, children: spans), maxLines: maxLines, overflow: overflow);
  }
}
