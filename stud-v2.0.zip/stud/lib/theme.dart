import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// لوحة ألوان بنمط Forest (فاتحة / داكنة)
class Pal {
  final bool dark;
  final Color bg, surface, surface2, accent, onAccent, text, sub, danger, amber;
  final Color stage; // خلفية شاشة المؤقت
  final Color forestTop, forestBottom; // خلفية شاشة الغابة
  const Pal({
    required this.dark,
    required this.bg,
    required this.surface,
    required this.surface2,
    required this.accent,
    required this.onAccent,
    required this.text,
    required this.sub,
    required this.danger,
    required this.amber,
    required this.stage,
    required this.forestTop,
    required this.forestBottom,
  });

  static const lightPal = Pal(
    dark: false,
    bg: Color(0xFFF0F7F2),
    surface: Color(0xFFFFFFFF),
    surface2: Color(0xFFE2EFE7),
    accent: Color(0xFF3FA57F),
    onAccent: Color(0xFFFFFFFF),
    text: Color(0xFF1C3A2E),
    sub: Color(0xFF688476),
    danger: Color(0xFFE0645C),
    amber: Color(0xFFF2B94B),
    stage: Color(0xFF57AB8B),
    forestTop: Color(0xFF1F4D38),
    forestBottom: Color(0xFF14352A),
  );

  static const darkPal = Pal(
    dark: true,
    bg: Color(0xFF0F211A),
    surface: Color(0xFF1A3328),
    surface2: Color(0xFF244435),
    accent: Color(0xFF7FD6A8),
    onAccent: Color(0xFF08281B),
    text: Color(0xFFEAF6EE),
    sub: Color(0xFF9BB8A8),
    danger: Color(0xFFFF7A70),
    amber: Color(0xFFFFD166),
    stage: Color(0xFF2B6F59),
    forestTop: Color(0xFF173A2B),
    forestBottom: Color(0xFF0C241B),
  );
}

/// الوصول للّوحة الحالية. القيم ليست ثابتة (const) لأنها تتغير مع الوضع.
class C {
  static Pal p = Pal.lightPal;
  static bool get dark => p.dark;
  static Color get bg => p.bg;
  static Color get surface => p.surface;
  static Color get surface2 => p.surface2;
  static Color get accent => p.accent;
  static Color get onAccent => p.onAccent;
  static Color get text => p.text;
  static Color get sub => p.sub;
  static Color get danger => p.danger;
  static Color get amber => p.amber;
  static Color get stage => p.stage;
}

ThemeData buildTheme(Pal p) {
  final base = ThemeData(
    brightness: p.dark ? Brightness.dark : Brightness.light,
    useMaterial3: true,
    scaffoldBackgroundColor: p.bg,
    colorScheme: ColorScheme.fromSeed(
      seedColor: p.accent,
      brightness: p.dark ? Brightness.dark : Brightness.light,
    ).copyWith(
      primary: p.accent,
      onPrimary: p.onAccent,
      secondary: p.amber,
      surface: p.surface,
      onSurface: p.text,
    ),
  );
  return base.copyWith(
    textTheme: GoogleFonts.cairoTextTheme(base.textTheme).apply(bodyColor: p.text, displayColor: p.text),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: p.surface,
      indicatorColor: p.accent.withValues(alpha: 0.2),
      labelTextStyle: WidgetStatePropertyAll(GoogleFonts.cairo(fontSize: 12, fontWeight: FontWeight.w600)),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: p.surface,
      surfaceTintColor: Colors.transparent,
    ),
  );
}

class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final Color? color;
  final EdgeInsets margin;
  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.color,
    this.margin = EdgeInsets.zero,
  });
  @override
  Widget build(BuildContext context) => Container(
        margin: margin,
        padding: padding,
        decoration: BoxDecoration(
          color: color ?? C.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: C.text.withValues(alpha: C.dark ? 0.06 : 0.05)),
        ),
        child: child,
      );
}

ButtonStyle bigButton({Color? bg, Color? fg}) => FilledButton.styleFrom(
      backgroundColor: bg ?? C.accent,
      foregroundColor: fg ?? C.onAccent,
      minimumSize: const Size.fromHeight(54),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      textStyle: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w700),
    );

InputDecoration fieldDeco(String label, {String? hint}) => InputDecoration(
      labelText: label,
      hintText: hint,
      filled: true,
      fillColor: C.surface2,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
    );
