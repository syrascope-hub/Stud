import 'package:audioplayers/audioplayers.dart';

const soundOptions = [
  ['none', 'بدون', '🔇'],
  ['rain', 'مطر', '🌧️'],
  ['wind', 'رياح', '🍃'],
  ['waves', 'أمواج', '🌊'],
  ['brown', 'ضوضاء هادئة', '🌙'],
];

String soundLabel(Set<String> ids) {
  if (ids.isEmpty) return 'أصوات محيطة';
  return ids.map((id) => soundOptions.firstWhere((o) => o[0] == id, orElse: () => soundOptions.first)[1]).join(' + ');
}

/// تشغيل أصوات محيطة متكررة (يمكن مزج أكثر من صوت). ملفات مضمّنة تعمل بدون إنترنت.
class SoundService {
  static final Map<String, AudioPlayer> _ps = {};

  /// [ids] نص مفصول بفواصل مثل "rain,wind" أو "none"
  static Future<void> play(String ids, {double vol = 0.6}) async {
    try {
      final want = ids.split(',').where((e) => e.isNotEmpty && e != 'none').toSet();
      for (final k in _ps.keys.toList()) {
        if (!want.contains(k)) {
          final p = _ps.remove(k);
          await p?.stop();
          await p?.dispose();
        }
      }
      for (final id in want) {
        final existing = _ps[id];
        if (existing != null) {
          await existing.setVolume(vol);
          continue;
        }
        final p = AudioPlayer();
        _ps[id] = p;
        await p.setReleaseMode(ReleaseMode.loop);
        await p.setVolume(vol);
        await p.play(AssetSource('sounds/$id.wav'));
      }
    } catch (_) {}
  }

  static Future<void> setVolume(double vol) async {
    try {
      for (final p in _ps.values) {
        await p.setVolume(vol);
      }
    } catch (_) {}
  }

  static Future<void> stop() async {
    try {
      for (final p in _ps.values) {
        await p.stop();
        await p.dispose();
      }
    } catch (_) {}
    _ps.clear();
  }
}
