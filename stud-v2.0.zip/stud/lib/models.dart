import 'dart:ui' show Color;

const dayNames = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const dayShort = ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];

/// الأحد = 0 ... السبت = 6
int weekdayIndex(DateTime d) => d.weekday % 7;

DateTime weekStartOf(DateTime d) {
  final b = DateTime(d.year, d.month, d.day);
  return DateTime(b.year, b.month, b.day - weekdayIndex(b));
}

String dateKey(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

String fmtMin(int m) {
  final h = m ~/ 60;
  final r = m % 60;
  if (h == 0) return '$r د';
  if (r == 0) return '$h س';
  return '$h س $r د';
}

String normAr(String s) => s
    .replaceAll(RegExp('[أإآ]'), 'ا')
    .replaceAll('ى', 'ي')
    .replaceAll('ة', 'ه')
    .trim();

class Subject {
  final String id;
  String name;
  String emoji;
  int color;
  Subject({required this.id, required this.name, required this.emoji, required this.color});
  Color get c => Color(color);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'emoji': emoji, 'color': color};
  factory Subject.fromJson(Map<String, dynamic> j) => Subject(
        id: j['id'] as String,
        name: j['name'] as String,
        emoji: (j['emoji'] ?? '📘') as String,
        color: j['color'] as int,
      );
}

class PlanItem {
  final String id;
  int day;
  String subjectId;
  String title;
  int minutes;
  PlanItem({
    required this.id,
    required this.day,
    required this.subjectId,
    this.title = '',
    required this.minutes,
  });
  Map<String, dynamic> toJson() =>
      {'id': id, 'day': day, 'subjectId': subjectId, 'title': title, 'minutes': minutes};
  factory PlanItem.fromJson(Map<String, dynamic> j) => PlanItem(
        id: j['id'] as String,
        day: j['day'] as int,
        subjectId: j['subjectId'] as String,
        title: (j['title'] ?? '') as String,
        minutes: j['minutes'] as int,
      );
}

class PlantRecord {
  final String id;
  final String weekKey;
  final int day;
  final String type;
  final int minutes;
  bool alive;
  final double x;
  final double z;
  final int seed;
  final int ts;
  final String? subjectId;
  int lastWatered; // آخر وقت سقي (ms)، 0 = لم تُسقَ بعد
  bool golden; // شجرة ذهبية نادرة
  int waterCount; // عدد مرات السقي (الأشجار المسقية جيداً تزهر)
  int charged; // عدد أيام العطش التي خُصمت عنها العملات
  PlantRecord({
    required this.id,
    required this.weekKey,
    required this.day,
    required this.type,
    required this.minutes,
    required this.alive,
    required this.x,
    required this.z,
    required this.seed,
    required this.ts,
    this.subjectId,
    this.lastWatered = 0,
    this.charged = 0,
    this.golden = false,
    this.waterCount = 0,
  });
  Map<String, dynamic> toJson() => {
        'id': id,
        'weekKey': weekKey,
        'day': day,
        'type': type,
        'minutes': minutes,
        'alive': alive,
        'x': x,
        'z': z,
        'seed': seed,
        'ts': ts,
        'subjectId': subjectId,
        'lastWatered': lastWatered,
        'charged': charged,
        'golden': golden,
        'waterCount': waterCount,
      };
  factory PlantRecord.fromJson(Map<String, dynamic> j) => PlantRecord(
        id: j['id'] as String,
        weekKey: j['weekKey'] as String,
        day: j['day'] as int,
        type: j['type'] as String,
        minutes: j['minutes'] as int,
        alive: j['alive'] as bool,
        x: (j['x'] as num).toDouble(),
        z: (j['z'] as num).toDouble(),
        seed: j['seed'] as int,
        ts: j['ts'] as int,
        subjectId: j['subjectId'] as String?,
        lastWatered: (j['lastWatered'] ?? 0) as int,
        charged: (j['charged'] ?? 0) as int,
        golden: (j['golden'] ?? false) as bool,
        waterCount: (j['waterCount'] ?? 0) as int,
      );

  /// شجرة مزهرة: سُقيت 3 مرات على الأقل
  bool get bloom => alive && waterCount >= 3;

  /// الشتلات الصغيرة فقط (أقل من 14 يوماً) تحتاج سقياً
  static const seedlingDays = 14;
  static const graceDays = 2;
  static const maxChargedDays = 3;

  int get _refMs => lastWatered > ts ? lastWatered : ts;

  /// عدد الأيام الكاملة منذ آخر سقي (أو منذ الزراعة)
  int dryDays([int? nowMs]) {
    final now = nowMs ?? DateTime.now().millisecondsSinceEpoch;
    return ((now - _refMs) / 86400000).floor().clamp(0, 9999).toInt();
  }

  bool isSeedling([int? nowMs]) {
    final now = nowMs ?? DateTime.now().millisecondsSinceEpoch;
    return alive && now - ts < seedlingDays * 86400000;
  }

  /// درجة العطش من 0 (مرتوية) إلى 1 (جافة جداً)
  double thirst([int? nowMs]) {
    if (!isSeedling(nowMs)) return 0;
    final d = dryDays(nowMs);
    if (d <= 0) return 0;
    return (d / (graceDays + maxChargedDays)).clamp(0.0, 1.0).toDouble();
  }

  bool needsWater([int? nowMs]) => isSeedling(nowMs) && dryDays(nowMs) >= 1;

  /// الخصم اليومي من العملات عن كل يوم عطش بعد فترة السماح
  int get penaltyPerDay => (minutes ~/ 10).clamp(1, 12).toInt();
}

class Exam {
  final String id;
  String name;
  int dateMs; // بداية اليوم بالتوقيت المحلي
  bool estimated;
  Exam({required this.id, required this.name, required this.dateMs, this.estimated = false});
  DateTime get date => DateTime.fromMillisecondsSinceEpoch(dateMs);
  int daysLeft() {
    final n = DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    final d = DateTime(date.year, date.month, date.day);
    return d.difference(today).inDays;
  }

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'dateMs': dateMs, 'estimated': estimated};
  factory Exam.fromJson(Map<String, dynamic> j) => Exam(
        id: j['id'] as String,
        name: j['name'] as String,
        dateMs: j['dateMs'] as int,
        estimated: (j['estimated'] ?? false) as bool,
      );
}

class PlantType {
  final String id;
  final String name;
  final String emoji;
  final int price; // 0 = مجاني
  const PlantType(this.id, this.name, this.emoji, [this.price = 0]);
}

const plantTypes = [
  PlantType('oak', 'بلوط', '🌳'),
  PlantType('pine', 'صنوبر', '🌲'),
  PlantType('cypress', 'سرو', '🌿', 60),
  PlantType('cherry', 'كرز', '🌸', 120),
  PlantType('palm', 'نخيل', '🌴', 90),
  PlantType('olive', 'زيتون', '🫒', 70),
  PlantType('maple', 'قيقب', '🍁', 100),
  PlantType('birch', 'بتولا', '🪵', 80),
  PlantType('bamboo', 'خيزران', '🎋', 110),
  PlantType('cactus', 'صبار', '🌵', 50),
  PlantType('sunflower', 'عباد الشمس', '🌻', 60),
  PlantType('tulip', 'توليب', '🌷', 70),
  PlantType('mushroom', 'فطر', '🍄', 140),
  PlantType('bush', 'شجيرة توت', '🫐'),
];

PlantType plantById(String id) =>
    plantTypes.firstWhere((p) => p.id == id, orElse: () => plantTypes.first);

class Challenge {
  final String id, title, emoji;
  final int target, coins, water;
  const Challenge(this.id, this.title, this.emoji, this.target, this.coins, this.water);
}

const dailyChallenges = [
  Challenge('focus60', 'ركّز 60 دقيقة', '⏱️', 60, 20, 3),
  Challenge('sessions3', 'أكمل 3 جلسات تركيز', '🌳', 3, 15, 2),
  Challenge('tasks3', 'أنجز 3 مهام من مخططك', '✅', 3, 15, 3),
  Challenge('review3', 'راجع 3 أخطاء من دفترك', '✍️', 3, 10, 2),
];

/// دفتر (مثلاً: أفكار الرياضيات)
class Notebook {
  final String id;
  String name;
  String emoji;
  Notebook({required this.id, required this.name, this.emoji = '📓'});
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'emoji': emoji};
  factory Notebook.fromJson(Map<String, dynamic> j) =>
      Notebook(id: j['id'] as String, name: j['name'] as String, emoji: (j['emoji'] ?? '📓') as String);
}

/// أنواع الإدخالات في الدفتر
const noteKinds = [
  ['idea', '💡', 'فكرة'],
  ['mistake', '❌', 'خطأ'],
  ['rule', '📌', 'قانون'],
];

/// إدخال في الدفتر: فكرة / خطأ مع تصحيحه / قانون
class NoteEntry {
  final String id;
  String notebookId;
  String kind; // idea | mistake | rule
  String title;
  String body;
  String fix; // الصحيح (للأخطاء)
  String chapter;
  bool starred;
  final int ts;
  List<String> images; // مسارات صور محلية
  int box; // مستوى المراجعة 0..5 (للأخطاء)
  int nextReview; // وقت المراجعة القادمة (ms)
  NoteEntry({
    required this.id,
    required this.notebookId,
    required this.kind,
    required this.title,
    this.body = '',
    this.fix = '',
    this.chapter = '',
    this.starred = false,
    required this.ts,
    List<String>? images,
    this.box = 0,
    this.nextReview = 0,
  }) : images = images ?? <String>[];
  Map<String, dynamic> toJson() => {
        'id': id,
        'notebookId': notebookId,
        'kind': kind,
        'title': title,
        'body': body,
        'fix': fix,
        'chapter': chapter,
        'starred': starred,
        'ts': ts,
        'images': images,
        'box': box,
        'nextReview': nextReview,
      };
  factory NoteEntry.fromJson(Map<String, dynamic> j) => NoteEntry(
        id: j['id'] as String,
        notebookId: j['notebookId'] as String,
        kind: (j['kind'] ?? 'idea') as String,
        title: (j['title'] ?? '') as String,
        body: (j['body'] ?? '') as String,
        fix: (j['fix'] ?? '') as String,
        chapter: (j['chapter'] ?? '') as String,
        starred: (j['starred'] ?? false) as bool,
        ts: j['ts'] as int,
        images: ((j['images'] ?? []) as List).map((e) => '$e').toList(),
        box: (j['box'] ?? 0) as int,
        nextReview: (j['nextReview'] ?? 0) as int,
      );
}

/// زينة الجزيرة وحيواناتها (تُشترى بالعملات)
class DecorItem {
  final String id, name, emoji;
  final int price;
  final String note;
  const DecorItem(this.id, this.name, this.emoji, this.price, this.note);
}

const decorItems = [
  DecorItem('lake', 'بحيرة', '🏞️', 150, 'تظهر في الجزيرة'),
  DecorItem('house', 'بيت صغير', '🏡', 250, 'يظهر في الجزيرة'),
  DecorItem('bench', 'مقعد', '🪑', 80, 'يظهر في الجزيرة'),
  DecorItem('lantern', 'فانوس', '🏮', 100, 'يظهر في الجزيرة'),
  DecorItem('butterflies', 'فراشات', '🦋', 120, 'في الجزيرة والشبكة'),
  DecorItem('birds', 'طيور', '🐦', 120, 'في الجزيرة والشبكة'),
];

/// جلسة دورة امتحانية كاملة
class ExamRun {
  final String id;
  final String name;
  final int plannedMin;
  final int usedMin;
  final double score;
  final double max;
  final int ts;
  const ExamRun({
    required this.id,
    required this.name,
    required this.plannedMin,
    required this.usedMin,
    required this.score,
    required this.max,
    required this.ts,
  });
  double get pct => max <= 0 ? 0 : (100 * score / max).clamp(0.0, 100.0).toDouble();
  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'plannedMin': plannedMin,
        'usedMin': usedMin,
        'score': score,
        'max': max,
        'ts': ts,
      };
  factory ExamRun.fromJson(Map<String, dynamic> j) => ExamRun(
        id: j['id'] as String,
        name: (j['name'] ?? '') as String,
        plannedMin: (j['plannedMin'] ?? 0) as int,
        usedMin: (j['usedMin'] ?? 0) as int,
        score: ((j['score'] ?? 0) as num).toDouble(),
        max: ((j['max'] ?? 100) as num).toDouble(),
        ts: j['ts'] as int,
      );
}
