import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';

class V3 {
  final double x, y, z;
  const V3(this.x, this.y, this.z);
  V3 operator +(V3 o) => V3(x + o.x, y + o.y, z + o.z);
  V3 operator -(V3 o) => V3(x - o.x, y - o.y, z - o.z);
  V3 operator *(double s) => V3(x * s, y * s, z * s);
  double dot(V3 o) => x * o.x + y * o.y + z * o.z;
  double get len => math.sqrt(x * x + y * y + z * z);
  V3 norm() {
    final l = len;
    return l == 0 ? this : V3(x / l, y / l, z / l);
  }
}

class P {
  final double x, y, depth, k;
  const P(this.x, this.y, this.depth, this.k);
  Offset get o => Offset(x, y);
}

/// كاميرا منظورية: دوران حول المحور الرأسي (yaw) وميل (pitch).
class Cam {
  final double yaw, pitch, unit, dist;
  final Offset center;
  final double _cy, _sy, _cp, _sp;
  Cam({required this.yaw, required this.pitch, required this.unit, required this.center, this.dist = 11})
      : _cy = math.cos(yaw),
        _sy = math.sin(yaw),
        _cp = math.cos(pitch),
        _sp = math.sin(pitch);

  P proj(V3 p) {
    final x1 = p.x * _cy - p.z * _sy;
    final z1 = p.x * _sy + p.z * _cy;
    final y2 = p.y * _cp + z1 * _sp;
    final z2 = z1 * _cp - p.y * _sp;
    final k = dist / (dist + z2);
    return P(center.dx + x1 * k * unit, center.dy - y2 * k * unit, z2, k * unit);
  }
}

final V3 kLight = const V3(-0.45, 0.8, -0.4).norm();

Color shade(Color c, double f) => Color.from(
      alpha: c.a,
      red: (c.r * f).clamp(0.0, 1.0),
      green: (c.g * f).clamp(0.0, 1.0),
      blue: (c.b * f).clamp(0.0, 1.0),
    );

class Cmd {
  final double depth;
  final void Function(Canvas) draw;
  Cmd(this.depth, this.draw);
}

class Scene3D {
  final Cam cam;
  /// أسلوب مسطّح كرتوني (ألوان ناعمة بدون تدرجات ثقيلة)
  final bool flat;
  /// وضع أداء منخفض: تفاصيل أقل
  final bool lite;
  final List<void Function(Canvas)> ground = [];
  final List<Cmd> cmds = [];
  Scene3D(this.cam, {this.flat = true, this.lite = false});

  void paint(Canvas cv) {
    for (final g in ground) {
      g(cv);
    }
    cmds.sort((a, b) => b.depth.compareTo(a.depth));
    for (final c in cmds) {
      c.draw(cv);
    }
  }

  // ---------- كرة (تاج شجرة، ثمرة...) ----------
  void sphere(V3 c, double r, Color col, {double squash = 1.0}) {
    final p = cam.proj(c);
    final pr = r * p.k;
    if (pr < 0.3) return;
    cmds.add(Cmd(p.depth, (cv) {
      final rect = Rect.fromCenter(center: p.o, width: pr * 2, height: pr * 2 * squash);
      if (flat) {
        cv.drawOval(rect, Paint()..color = shade(col, 0.9));
        final hr = Rect.fromCenter(
          center: Offset(rect.center.dx - rect.width * 0.09, rect.center.dy - rect.height * 0.12),
          width: rect.width * 0.74,
          height: rect.height * 0.74,
        );
        cv.drawOval(hr, Paint()..color = shade(col, 1.1));
        return;
      }
      final paint = Paint()
        ..shader = ui.Gradient.radial(
          Offset(rect.center.dx - rect.width * 0.18, rect.center.dy - rect.height * 0.22),
          rect.width * 0.62,
          [shade(col, 1.28), col, shade(col, 0.6)],
          const [0.0, 0.55, 1.0],
        );
      cv.drawOval(rect, paint);
    }));
  }

  /// بقع بيضاء فوق كرة (قبعة الفطر)
  void spots(V3 c, double r, double squash, List<Offset> rel, Color col) {
    final p = cam.proj(c);
    final pr = r * p.k;
    cmds.add(Cmd(p.depth - 0.01, (cv) {
      final paint = Paint()..color = col;
      for (final o in rel) {
        cv.drawCircle(Offset(p.x + o.dx * pr, p.y + o.dy * pr * squash), pr * 0.13, paint);
      }
    }));
  }

  // ---------- مخروط مظلّل ----------
  void cone(V3 base, double r, double h, Color col, {int seg = 14}) {
    if (lite && seg > 8) seg = 8;
    final apex = V3(base.x, base.y + h, base.z);
    final pa = cam.proj(apex);
    final pp = <P>[];
    for (var i = 0; i < seg; i++) {
      final a = i / seg * 2 * math.pi;
      pp.add(cam.proj(V3(base.x + math.cos(a) * r, base.y, base.z + math.sin(a) * r)));
    }
    for (var i = 0; i < seg; i++) {
      final j = (i + 1) % seg;
      final am = (i + 0.5) / seg * 2 * math.pi;
      final n = V3(math.cos(am) * h, r, math.sin(am) * h).norm();
      final f = flat ? 0.8 + 0.3 * math.max(0.0, n.dot(kLight)) : 0.55 + 0.6 * math.max(0.0, n.dot(kLight));
      final c = shade(col, f);
      final depth = (pa.depth + pp[i].depth + pp[j].depth) / 3;
      final path = Path()
        ..moveTo(pa.x, pa.y)
        ..lineTo(pp[i].x, pp[i].y)
        ..lineTo(pp[j].x, pp[j].y)
        ..close();
      cmds.add(Cmd(depth, (cv) {
        cv.drawPath(path, Paint()..color = c);
        cv.drawPath(
          path,
          Paint()
            ..color = c
            ..style = PaintingStyle.stroke
            ..strokeWidth = 0.8,
        );
      }));
    }
  }

  // ---------- جذع / ساق ----------
  void stem(V3 a, V3 b, double ra, double rb, Color col, {bool round = false}) {
    final pa = cam.proj(a), pb = cam.proj(b);
    final dx = pb.x - pa.x, dy = pb.y - pa.y;
    final l = math.sqrt(dx * dx + dy * dy);
    if (l < 0.001) return;
    final nx = -dy / l, ny = dx / l;
    final wa = math.max(ra * pa.k, 0.4), wb = math.max(rb * pb.k, 0.4);
    final path = Path()
      ..moveTo(pa.x + nx * wa, pa.y + ny * wa)
      ..lineTo(pb.x + nx * wb, pb.y + ny * wb)
      ..lineTo(pb.x - nx * wb, pb.y - ny * wb)
      ..lineTo(pa.x - nx * wa, pa.y - ny * wa)
      ..close();
    final depth = (pa.depth + pb.depth) / 2;
    cmds.add(Cmd(depth, (cv) {
      if (flat) {
        cv.drawPath(path, Paint()..color = col);
        if (round) cv.drawCircle(pb.o, wb, Paint()..color = col);
        return;
      }
      final paint = Paint()
        ..shader = ui.Gradient.linear(
          Offset(pa.x - nx * wa, pa.y - ny * wa),
          Offset(pa.x + nx * wa, pa.y + ny * wa),
          [shade(col, 1.18), shade(col, 0.68)],
        );
      cv.drawPath(path, paint);
      if (round) {
        cv.drawCircle(pb.o, wb, Paint()..color = shade(col, 1.05));
      }
    }));
  }

  // ---------- شريط (ورقة / عشبة / سعفة) ----------
  void ribbon(List<V3> pts, double width, Color col, {bool leaf = true}) {
    if (pts.length < 2) return;
    final pr = pts.map(cam.proj).toList();
    final left = <Offset>[], right = <Offset>[];
    var dsum = 0.0;
    for (var i = 0; i < pr.length; i++) {
      final a = pr[math.max(i - 1, 0)], b = pr[math.min(i + 1, pr.length - 1)];
      var dx = b.x - a.x, dy = b.y - a.y;
      final l = math.sqrt(dx * dx + dy * dy);
      if (l < 0.0001) {
        dx = 0;
        dy = 1;
      } else {
        dx /= l;
        dy /= l;
      }
      final t = i / (pr.length - 1);
      final w = leaf ? width * math.max(math.sin(math.pi * t), 0.06) : width * (1 - t * 0.95);
      final ww = w * pr[i].k;
      left.add(Offset(pr[i].x - dy * ww, pr[i].y + dx * ww));
      right.add(Offset(pr[i].x + dy * ww, pr[i].y - dx * ww));
      dsum += pr[i].depth;
    }
    final path = Path()..moveTo(left[0].dx, left[0].dy);
    for (var i = 1; i < left.length; i++) {
      path.lineTo(left[i].dx, left[i].dy);
    }
    for (var i = right.length - 1; i >= 0; i--) {
      path.lineTo(right[i].dx, right[i].dy);
    }
    path.close();
    final c = col;
    cmds.add(Cmd(dsum / pr.length, (cv) {
      cv.drawPath(path, Paint()..color = c);
      cv.drawPath(
        path,
        Paint()
          ..color = shade(c, 0.78)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.7,
      );
    }));
  }

  /// زهرة تواجه الكاميرا (عباد الشمس)
  void billboardFlower(V3 c, double r, Color petal, Color center, int petals) {
    final p = cam.proj(c);
    final pr = r * p.k;
    cmds.add(Cmd(p.depth - 0.02, (cv) {
      final pp = Paint()..color = petal;
      final pd = Paint()..color = shade(petal, 0.8);
      for (var i = 0; i < petals; i++) {
        final a = i / petals * 2 * math.pi;
        cv.save();
        cv.translate(p.x, p.y);
        cv.rotate(a);
        final rect = Rect.fromCenter(center: Offset(pr * 0.78, 0), width: pr * 0.7, height: pr * 0.3);
        cv.drawOval(rect, i.isEven ? pp : pd);
        cv.restore();
      }
      final rect = Rect.fromCircle(center: p.o, radius: pr * 0.55);
      cv.drawCircle(
        p.o,
        pr * 0.55,
        Paint()
          ..shader = ui.Gradient.radial(
            Offset(p.x - pr * 0.15, p.y - pr * 0.15),
            rect.width * 0.6,
            [shade(center, 1.5), center, shade(center, 0.55)],
            const [0.0, 0.5, 1.0],
          ),
      );
    }));
  }

  // ---------- ظل على الأرض ----------
  void shadow(V3 c, double r, double alpha) {
    ground.add((cv) {
      for (var layer = 0; layer < 2; layer++) {
        final rr = r * (1.0 - layer * 0.35);
        final path = Path();
        for (var i = 0; i < 20; i++) {
          final a = i / 20 * 2 * math.pi;
          final p = cam.proj(V3(c.x + math.cos(a) * rr + rr * 0.25, 0.004, c.z + math.sin(a) * rr + rr * 0.15));
          if (i == 0) {
            path.moveTo(p.x, p.y);
          } else {
            path.lineTo(p.x, p.y);
          }
        }
        path.close();
        cv.drawPath(path, Paint()..color = Colors.black.withValues(alpha: alpha * (layer == 0 ? 0.55 : 0.6)));
      }
    });
  }

  // ---------- الجزيرة ----------
  void island(double R) {
    const seg = 56;
    const depthY = -0.75;
    final top = <P>[], bot = <P>[];
    for (var i = 0; i < seg; i++) {
      final a = i / seg * 2 * math.pi;
      top.add(cam.proj(V3(math.cos(a) * R, 0, math.sin(a) * R)));
      bot.add(cam.proj(V3(math.cos(a) * R * 0.78, depthY, math.sin(a) * R * 0.78)));
    }
    final walls = <Cmd>[];
    for (var i = 0; i < seg; i++) {
      final j = (i + 1) % seg;
      final am = (i + 0.5) / seg * 2 * math.pi;
      final f = 0.5 + 0.55 * math.max(0.0, V3(math.cos(am), 0.25, math.sin(am)).norm().dot(kLight));
      final c = flat ? shade(const Color(0xFFB8844F), 0.72 + 0.3 * f) : shade(const Color(0xFF7A5230), f);
      final path = Path()
        ..moveTo(top[i].x, top[i].y)
        ..lineTo(top[j].x, top[j].y)
        ..lineTo(bot[j].x, bot[j].y)
        ..lineTo(bot[i].x, bot[i].y)
        ..close();
      final d = (top[i].depth + top[j].depth + bot[i].depth + bot[j].depth) / 4;
      walls.add(Cmd(d, (cv) {
        cv.drawPath(path, Paint()..color = c);
        cv.drawPath(
          path,
          Paint()
            ..color = c
            ..style = PaintingStyle.stroke
            ..strokeWidth = 0.8,
        );
      }));
    }
    walls.sort((a, b) => b.depth.compareTo(a.depth));
    final topPath = Path()..moveTo(top[0].x, top[0].y);
    for (var i = 1; i < seg; i++) {
      topPath.lineTo(top[i].x, top[i].y);
    }
    topPath.close();
    final c0 = cam.proj(const V3(0, 0, 0));
    ground.add((cv) {
      for (final w in walls) {
        w.draw(cv);
      }
      if (flat) {
        cv.drawPath(topPath, Paint()..color = const Color(0xFF9BDB74));
        cv.drawPath(
          topPath,
          Paint()
            ..color = const Color(0xFFC4F0A0)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3,
        );
        return;
      }
      cv.drawPath(
        topPath,
        Paint()
          ..shader = ui.Gradient.radial(
            c0.o,
            R * c0.k,
            const [Color(0xFF93D86F), Color(0xFF65B85C), Color(0xFF3F8F4A)],
            const [0.0, 0.65, 1.0],
          ),
      );
      cv.drawPath(
        topPath,
        Paint()
          ..color = const Color(0xFFB9E88F)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5,
      );
    });
  }

  // ---------- زينة الجزيرة: أعشاب وأزهار وصخور ----------
  void decor(double R) {
    final r = math.Random(11);
    final n = lite ? (R * R * 1.5).round() : (R * R * (flat ? 3.5 : 7)).round();
    for (var i = 0; i < n; i++) {
      final a = r.nextDouble() * 2 * math.pi;
      final d = math.sqrt(r.nextDouble()) * (R - 0.18);
      final x = math.cos(a) * d, z = math.sin(a) * d;
      final h = 0.13 + r.nextDouble() * 0.12;
      final c = shade(const Color(0xFF4FA652), 0.85 + r.nextDouble() * 0.4);
      for (var k = 0; k < 3; k++) {
        final ox = (k - 1) * 0.045;
        ribbon([
          V3(x + ox, 0, z),
          V3(x + ox * 1.8 + 0.03 * (k - 1), h * 0.6, z),
          V3(x + ox * 2.6 + 0.06 * (k - 1), h, z),
        ], 0.025, c, leaf: false);
      }
    }
    const cols = [Color(0xFFFFFFFF), Color(0xFFFFEB3B), Color(0xFFFF8A80), Color(0xFFB39DDB)];
    final nf = lite ? (R * R * 0.5).round() : (R * R * 1.3).round();
    for (var i = 0; i < nf; i++) {
      final a = r.nextDouble() * 2 * math.pi;
      final d = math.sqrt(r.nextDouble()) * (R - 0.25);
      final x = math.cos(a) * d, z = math.sin(a) * d;
      stem(V3(x, 0, z), V3(x, 0.17, z), 0.008, 0.008, const Color(0xFF3E8E41));
      sphere(V3(x, 0.19, z), 0.045, cols[i % cols.length]);
    }
    for (var i = 0; i < 4; i++) {
      final a = r.nextDouble() * 2 * math.pi;
      final d = (R - 0.35) * (0.7 + r.nextDouble() * 0.3);
      sphere(V3(math.cos(a) * d, 0.07, math.sin(a) * d), 0.11 + r.nextDouble() * 0.07,
          const Color(0xFF9AA5A0), squash: 0.75);
    }
  }
}
