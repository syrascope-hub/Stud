# Stud

مخطط دراسي (يومي + أسبوعي) + Pomodoro بنمط غابة ثلاثية الأبعاد (غابة لكل يوم) + مساعد ذكاء اصطناعي عبر OpenRouter يعدّل المخطط.

## البناء
- محلياً: `flutter create . --platforms=android` ثم أضف صلاحية INTERNET في AndroidManifest ثم `flutter run`
- أو ادفع المشروع إلى GitHub، وسيبني `.github/workflows/build.yml` ملف APK تلقائياً (Actions → stud-apk).
