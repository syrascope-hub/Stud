import 'dart:ui' show Color;

const dayNames = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const dayShort = ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];

/// الأحد = 0 ... السبت = 6
int weekdayIndex(DateTime d) => d.weekday % 7;

DateTime weekStartOf(DateTime d) {
  final b = DateTime(d.year, d.month, d.day);
  return DateTime(b.year, b.month, b.day - weekdayIndex(b));
}

String dateKey(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

String fmtMin(int m) {
  final h = m ~/ 60;
  final r = m % 60;
  if (h == 0) return '$r د';
  if (r == 0) return '$h س';
  return '$h س $r د';
}

String normAr(String s) => s
    .replaceAll(RegExp('[أإآ]'), 'ا')
    .replaceAll('ى', 'ي')
    .replaceAll('ة', 'ه')
    .trim();

class Subject {
  final String id;
  String name;
  String emoji;
  int color;
  Subject({required this.id, required this.name, required this.emoji, required this.color});
  Color get c => Color(color);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'emoji': emoji, 'color': color};
  factory Subject.fromJson(Map<String, dynamic> j) => Subject(
        id: j['id'] as String,
        name: j['name'] as String,
        emoji: (j['emoji'] ?? '📘') as String,
        color: j['color'] as int,
      );
}

class PlanItem {
  final String id;
  int day;
  String subjectId;
  String title;
  int minutes;
  PlanItem({
    required this.id,
    required this.day,
    required this.subjectId,
    this.title = '',
    required this.minutes,
  });
  Map<String, dynamic> toJson() =>
      {'id': id, 'day': day, 'subjectId': subjectId, 'title': title, 'minutes': minutes};
  factory PlanItem.fromJson(Map<String, dynamic> j) => PlanItem(
        id: j['id'] as String,
        day: j['day'] as int,
        subjectId: j['subjectId'] as String,
        title: (j['title'] ?? '') as String,
        minutes: j['minutes'] as int,
      );
}

class PlantRecord {
  final String id;
  final String weekKey;
  final int day;
  final String type;
  final int minutes;
  final bool alive;
  final double x;
  final double z;
  final int seed;
  final int ts;
  final String? subjectId;
  PlantRecord({
    required this.id,
    required this.weekKey,
    required this.day,
    required this.type,
    required this.minutes,
    required this.alive,
    required this.x,
    required this.z,
    required this.seed,
    required this.ts,
    this.subjectId,
  });
  Map<String, dynamic> toJson() => {
        'id': id,
        'weekKey': weekKey,
        'day': day,
        'type': type,
        'minutes': minutes,
        'alive': alive,
        'x': x,
        'z': z,
        'seed': seed,
        'ts': ts,
        'subjectId': subjectId,
      };
  factory PlantRecord.fromJson(Map<String, dynamic> j) => PlantRecord(
        id: j['id'] as String,
        weekKey: j['weekKey'] as String,
        day: j['day'] as int,
        type: j['type'] as String,
        minutes: j['minutes'] as int,
        alive: j['alive'] as bool,
        x: (j['x'] as num).toDouble(),
        z: (j['z'] as num).toDouble(),
        seed: j['seed'] as int,
        ts: j['ts'] as int,
        subjectId: j['subjectId'] as String?,
      );
}

class PlantType {
  final String id;
  final String name;
  final String emoji;
  final int price; // 0 = مجاني
  const PlantType(this.id, this.name, this.emoji, [this.price = 0]);
}

const plantTypes = [
  PlantType('oak', 'بلوط', '🌳'),
  PlantType('pine', 'صنوبر', '🌲'),
  PlantType('cypress', 'سرو', '🌿', 60),
  PlantType('cherry', 'كرز', '🌸', 120),
  PlantType('palm', 'نخيل', '🌴', 90),
  PlantType('olive', 'زيتون', '🫒', 70),
  PlantType('maple', 'قيقب', '🍁', 100),
  PlantType('birch', 'بتولا', '🪵', 80),
  PlantType('bamboo', 'خيزران', '🎋', 110),
  PlantType('cactus', 'صبار', '🌵', 50),
  PlantType('sunflower', 'عباد الشمس', '🌻', 60),
  PlantType('tulip', 'توليب', '🌷', 70),
  PlantType('mushroom', 'فطر', '🍄', 140),
  PlantType('bush', 'شجيرة توت', '🫐'),
];

PlantType plantById(String id) =>
    plantTypes.firstWhere((p) => p.id == id, orElse: () => plantTypes.first);
