import 'package:flutter/material.dart';
import 'store.dart';
import 'theme.dart';

Future<void> showSettingsSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (ctx) {
      final s = StoreScope.of(ctx);
      return Padding(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('الإعدادات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              Text('المظهر', style: TextStyle(color: C.sub)),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: SegmentedButton<int>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(value: 0, label: Text('تلقائي'), icon: Icon(Icons.brightness_auto)),
                    ButtonSegment(value: 1, label: Text('نهاري'), icon: Icon(Icons.light_mode)),
                    ButtonSegment(value: 2, label: Text('ليلي'), icon: Icon(Icons.dark_mode)),
                  ],
                  selected: {s.themeMode},
                  onSelectionChanged: (v) => s.setThemeMode(v.first),
                ),
              ),
              const SizedBox(height: 8),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: s.strict,
                onChanged: s.setStrict,
                title: const Text('وضع الصرامة'),
                subtitle: Text('تذبل الشجرة إن غادرت التطبيق أكثر من 8 ثوانٍ',
                    style: TextStyle(fontSize: 12, color: C.sub)),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: s.lowPower,
                onChanged: s.setLowPower,
                title: const Text('وضع الأداء المنخفض'),
                subtitle: Text('تفاصيل أقل في الأشجار للهواتف الضعيفة',
                    style: TextStyle(fontSize: 12, color: C.sub)),
              ),
              const SizedBox(height: 4),
              TextButton.icon(
                onPressed: () {
                  s.onboarded = false;
                  s.pokeTheme();
                  Navigator.pop(ctx);
                },
                icon: const Icon(Icons.slideshow),
                label: const Text('إعادة عرض شاشة الترحيب'),
              ),
            ],
          ),
        ),
      );
    },
  );
}
