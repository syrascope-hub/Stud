import 'dart:convert';
import 'package:http/http.dart' as http;

class AiResult {
  final String reply;
  final List<dynamic> actions;
  AiResult(this.reply, this.actions);
}

class AiService {
  static const endpoint = 'https://openrouter.ai/api/v1/chat/completions';

  static String _system(String planJson) => '''
أنت مساعد داخل تطبيق Stud لتنظيم دراسة طالب بكالوريا سوري (الفرع العلمي). مهمتك تعديل مخطط الدراسة الأسبوعي بناءً على طلب الطالب.
أيام الأسبوع مرقمة: 0=الأحد، 1=الاثنين، 2=الثلاثاء، 3=الأربعاء، 4=الخميس، 5=الجمعة، 6=السبت.
المخطط الحالي (JSON): $planJson

أجب دائماً بكائن JSON واحد فقط، بدون أي نص خارجه وبدون Markdown، بهذا الشكل:
{"reply":"رد قصير ودود بالعربية","actions":[ ... ]}

العمليات المتاحة داخل actions:
{"op":"add","day":0-6,"subject":"اسم المادة","title":"وصف قصير","minutes":عدد_الدقائق}
{"op":"update","id":"معرّف المهمة","day":0-6,"subject":"..","title":"..","minutes":..}  (اذكر الحقول المتغيرة فقط)
{"op":"remove","id":"معرّف المهمة"}
{"op":"clear_day","day":0-6}

قواعد:
- استخدم المعرّفات (id) الموجودة في المخطط تماماً.
- إن كان الطلب سؤالاً أو طلب نصيحة فقط فاجعل actions فارغة.
- لا تتجاوز 10 ساعات دراسة يومياً، ونبّه الطالب إن طلب أكثر.
- حافظ على أسماء المواد الموجودة، وتحدث بإيجاز.
''';

  static Future<AiResult> ask({
    required String apiKey,
    required String model,
    required String planJson,
    required List<Map<String, String>> history,
    required String userText,
  }) async {
    final messages = <Map<String, String>>[
      {'role': 'system', 'content': _system(planJson)},
      ...history,
      {'role': 'user', 'content': userText},
    ];
    final res = await http
        .post(
          Uri.parse(endpoint),
          headers: {
            'Authorization': 'Bearer $apiKey',
            'Content-Type': 'application/json',
            'HTTP-Referer': 'https://stud.app',
            'X-Title': 'Stud',
          },
          body: jsonEncode({'model': model, 'messages': messages, 'temperature': 0.3}),
        )
        .timeout(const Duration(seconds: 70));

    final body = utf8.decode(res.bodyBytes);
    if (res.statusCode != 200) {
      var msg = 'خطأ ${res.statusCode}';
      try {
        final j = jsonDecode(body);
        final m = j['error']?['message'];
        if (m != null) msg = '$msg: $m';
      } catch (_) {}
      throw Exception(msg);
    }
    final j = jsonDecode(body) as Map<String, dynamic>;
    final content = '${j['choices']?[0]?['message']?['content'] ?? ''}'.trim();
    return _parse(content);
  }

  static AiResult _parse(String content) {
    var s = content.trim();
    s = s.replaceAll(RegExp(r'^```(?:json)?', multiLine: false), '').replaceAll(RegExp(r'```$'), '').trim();
    final a = s.indexOf('{');
    final b = s.lastIndexOf('}');
    if (a >= 0 && b > a) {
      try {
        final m = jsonDecode(s.substring(a, b + 1)) as Map<String, dynamic>;
        final reply = '${m['reply'] ?? ''}'.trim();
        final acts = m['actions'] is List ? List<dynamic>.from(m['actions'] as List) : <dynamic>[];
        return AiResult(reply, acts);
      } catch (_) {}
    }
    return AiResult(content, []);
  }
}
