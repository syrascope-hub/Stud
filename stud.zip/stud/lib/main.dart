import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'store.dart';
import 'theme.dart';
import 'pages/planner_page.dart';
import 'pages/focus_page.dart';
import 'pages/forest_page.dart';
import 'pages/ai_page.dart';
import 'pages/welcome_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.load();
  runApp(StudApp(store: store));
}

class StudApp extends StatefulWidget {
  final AppStore store;
  const StudApp({super.key, required this.store});
  @override
  State<StudApp> createState() => _StudAppState();
}

class _StudAppState extends State<StudApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangePlatformBrightness() {
    // يعيد بناء الواجهة عندما يكون المظهر "تلقائي"
    widget.store.pokeTheme();
  }

  @override
  Widget build(BuildContext context) {
    return StoreScope(
      store: widget.store,
      child: Builder(
        builder: (ctx) {
          final s = StoreScope.of(ctx);
          final sys = WidgetsBinding.instance.platformDispatcher.platformBrightness == Brightness.dark;
          final dark = s.themeMode == 2 || (s.themeMode == 0 && sys);
          C.p = dark ? Pal.darkPal : Pal.lightPal;
          return MaterialApp(
            title: 'Stud',
            debugShowCheckedModeBanner: false,
            theme: buildTheme(C.p),
            locale: const Locale('ar'),
            supportedLocales: const [Locale('ar')],
            localizationsDelegates: const [
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            home: s.onboarded ? const Shell() : const WelcomePage(),
          );
        },
      ),
    );
  }
}

class Shell extends StatelessWidget {
  const Shell({super.key});

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    return Scaffold(
      body: IndexedStack(
        index: s.tab,
        children: const [PlannerPage(), FocusPage(), ForestPage(), AiPage()],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: s.tab,
        onDestinationSelected: s.setTab,
        destinations: [
          const NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'المخطط'),
          NavigationDestination(
            icon: Icon(s.active != null ? Icons.local_florist : Icons.timer_outlined),
            selectedIcon: Icon(s.active != null ? Icons.local_florist : Icons.timer),
            label: 'التركيز',
          ),
          const NavigationDestination(icon: Icon(Icons.forest_outlined), selectedIcon: Icon(Icons.forest), label: 'الغابة'),
          const NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'المساعد'),
        ],
      ),
    );
  }
}
