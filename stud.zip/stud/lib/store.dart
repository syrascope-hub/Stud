import 'dart:convert';
import 'dart:math';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

class ActiveSession {
  final String type;
  final int startMs;
  final int minutes;
  final String? subjectId;
  ActiveSession({required this.type, required this.startMs, required this.minutes, this.subjectId});
  int get endMs => startMs + minutes * 60000;
  Map<String, dynamic> toJson() =>
      {'type': type, 'startMs': startMs, 'minutes': minutes, 'subjectId': subjectId};
  factory ActiveSession.fromJson(Map<String, dynamic> j) => ActiveSession(
        type: j['type'] as String,
        startMs: j['startMs'] as int,
        minutes: j['minutes'] as int,
        subjectId: j['subjectId'] as String?,
      );
}

class ChatMsg {
  final bool user;
  final String text;
  final List<String> changes;
  ChatMsg(this.user, this.text, [this.changes = const []]);
  Map<String, dynamic> toJson() => {'user': user, 'text': text, 'changes': changes};
  factory ChatMsg.fromJson(Map<String, dynamic> j) => ChatMsg(
        j['user'] as bool,
        j['text'] as String,
        ((j['changes'] ?? []) as List).map((e) => '$e').toList(),
      );
}

class FocusPreset {
  final String? subjectId;
  final int? minutes;
  const FocusPreset({this.subjectId, this.minutes});
}

class AppStore extends ChangeNotifier {
  late SharedPreferences _p;
  List<Subject> subjects = [];
  List<PlanItem> plan = [];
  List<PlantRecord> plants = [];
  Set<String> done = {};
  ActiveSession? active;
  String apiKey = '';
  String model = 'openai/gpt-4o-mini';
  bool strict = true;
  bool lowPower = true;
  int themeMode = 0; // 0 تلقائي، 1 فاتح، 2 داكن
  bool onboarded = false;
  int coins = 0;
  Set<String> unlocked = {'oak', 'pine', 'bush'};
  String sound = 'none';
  List<ChatMsg> chat = [];
  int tab = 1;
  FocusPreset? preset;
  String? _undo;
  final _rnd = Random();

  bool get canUndo => _undo != null;
  String get currentWeekKey => dateKey(weekStartOf(DateTime.now()));

  // ---------- load / save ----------
  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    try {
      final s = _p.getString('subjects');
      subjects = s == null
          ? _defaultSubjects()
          : (jsonDecode(s) as List).map((e) => Subject.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      final pl = _p.getString('plan');
      plan = pl == null
          ? _defaultPlan()
          : (jsonDecode(pl) as List).map((e) => PlanItem.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      final pn = _p.getString('plants');
      plants = pn == null
          ? []
          : (jsonDecode(pn) as List).map((e) => PlantRecord.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      done = (_p.getStringList('done') ?? []).toSet();
      final a = _p.getString('active');
      active = a == null ? null : ActiveSession.fromJson(Map<String, dynamic>.from(jsonDecode(a) as Map));
      apiKey = _p.getString('apiKey') ?? '';
      model = _p.getString('model') ?? model;
      strict = _p.getBool('strict') ?? true;
      lowPower = _p.getBool('lowPower') ?? true;
      themeMode = _p.getInt('themeMode') ?? 0;
      onboarded = _p.getBool('onboarded') ?? false;
      coins = _p.getInt('coins') ?? 0;
      unlocked = (_p.getStringList('unlocked') ?? ['oak', 'pine', 'bush']).toSet();
      sound = _p.getString('sound') ?? 'none';
      final c = _p.getString('chat');
      chat = c == null
          ? []
          : (jsonDecode(c) as List).map((e) => ChatMsg.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) {
      subjects = _defaultSubjects();
      plan = _defaultPlan();
      plants = [];
      done = {};
      active = null;
    }
  }

  Future<void> _save() async {
    try {
      await _p.setString('subjects', jsonEncode(subjects.map((e) => e.toJson()).toList()));
      await _p.setString('plan', jsonEncode(plan.map((e) => e.toJson()).toList()));
      await _p.setString('plants', jsonEncode(plants.map((e) => e.toJson()).toList()));
      await _p.setStringList('done', done.toList());
      if (active == null) {
        await _p.remove('active');
      } else {
        await _p.setString('active', jsonEncode(active!.toJson()));
      }
      await _p.setString('apiKey', apiKey);
      await _p.setString('model', model);
      await _p.setBool('strict', strict);
      await _p.setBool('lowPower', lowPower);
      await _p.setInt('themeMode', themeMode);
      await _p.setBool('onboarded', onboarded);
      await _p.setInt('coins', coins);
      await _p.setStringList('unlocked', unlocked.toList());
      await _p.setString('sound', sound);
      final tail = chat.length > 40 ? chat.sublist(chat.length - 40) : chat;
      await _p.setString('chat', jsonEncode(tail.map((e) => e.toJson()).toList()));
    } catch (_) {}
  }

  void _commit() {
    notifyListeners();
    _save();
  }

  String _id() => '${DateTime.now().microsecondsSinceEpoch}${_rnd.nextInt(999)}';

  // ---------- navigation ----------
  void setTab(int i) {
    tab = i;
    notifyListeners();
  }

  void startFocusFor(PlanItem item) {
    preset = FocusPreset(subjectId: item.subjectId, minutes: min(item.minutes, 50));
    setTab(1);
  }

  // ---------- subjects & plan ----------
  Subject subjectById(String id) => subjects.firstWhere(
        (s) => s.id == id,
        orElse: () => subjects.isNotEmpty
            ? subjects.first
            : Subject(id: 'x', name: 'مادة', emoji: '📘', color: 0xFF90A4AE),
      );

  List<PlanItem> itemsForDay(int d) => plan.where((e) => e.day == d).toList();
  int plannedMinutes(int d) => itemsForDay(d).fold(0, (a, b) => a + b.minutes);
  int doneMinutes(int d, String wk) =>
      itemsForDay(d).where((e) => isDone(e, wk)).fold(0, (a, b) => a + b.minutes);
  bool isDone(PlanItem i, String wk) => done.contains('$wk:${i.id}');

  void toggleDone(PlanItem i, String wk) {
    final k = '$wk:${i.id}';
    if (!done.remove(k)) done.add(k);
    _commit();
  }

  void addItem({required int day, required String subjectId, required String title, required int minutes}) {
    plan.add(PlanItem(id: _id(), day: day, subjectId: subjectId, title: title, minutes: minutes));
    _commit();
  }

  void updateItem(PlanItem i, {int? day, String? subjectId, String? title, int? minutes}) {
    if (day != null) i.day = day;
    if (subjectId != null) i.subjectId = subjectId;
    if (title != null) i.title = title;
    if (minutes != null) i.minutes = minutes;
    _commit();
  }

  void removeItem(PlanItem i) {
    plan.removeWhere((e) => e.id == i.id);
    _commit();
  }

  // ---------- plants & sessions ----------
  List<PlantRecord> plantsFor(String weekKey, int day) =>
      plants.where((p) => p.weekKey == weekKey && p.day == day).toList();

  List<double> nextPosition(String weekKey, int day) {
    final ex = plantsFor(weekKey, day);
    double best = -1, bx = 0, bz = 0;
    for (var i = 0; i < 70; i++) {
      final a = _rnd.nextDouble() * 2 * pi;
      final d = sqrt(_rnd.nextDouble()) * 2.6;
      final x = cos(a) * d, z = sin(a) * d;
      double md = 99;
      for (final p in ex) {
        final dx = p.x - x, dz = p.z - z;
        md = min(md, sqrt(dx * dx + dz * dz));
      }
      if (ex.isEmpty) md = 5 - d;
      if (md > best) {
        best = md;
        bx = x;
        bz = z;
      }
    }
    return [bx, bz];
  }

  void startSession(String type, int minutes, String? subjectId) {
    active = ActiveSession(
      type: type,
      startMs: DateTime.now().millisecondsSinceEpoch,
      minutes: minutes,
      subjectId: subjectId,
    );
    _commit();
  }

  PlantRecord? finishSession(bool alive) {
    final a = active;
    if (a == null) return null;
    final start = DateTime.fromMillisecondsSinceEpoch(a.startMs);
    final wk = dateKey(weekStartOf(start));
    final day = weekdayIndex(start);
    final pos = nextPosition(wk, day);
    final rec = PlantRecord(
      id: _id(),
      weekKey: wk,
      day: day,
      type: a.type,
      minutes: a.minutes,
      alive: alive,
      x: pos[0],
      z: pos[1],
      seed: _rnd.nextInt(100000),
      ts: DateTime.now().millisecondsSinceEpoch,
      subjectId: a.subjectId,
    );
    plants.add(rec);
    if (alive) coins += a.minutes;
    active = null;
    _commit();
    return rec;
  }

  int aliveTodayCount() {
    final now = DateTime.now();
    final wk = dateKey(weekStartOf(now));
    return plantsFor(wk, weekdayIndex(now)).where((p) => p.alive).length;
  }

  // ---------- settings ----------
  void setApi({String? key, String? mdl}) {
    if (key != null) apiKey = key.trim();
    if (mdl != null && mdl.trim().isNotEmpty) model = mdl.trim();
    _commit();
  }

  void setThemeMode(int m) {
    themeMode = m;
    _commit();
  }

  /// يُستدعى عند تغيّر سطوع النظام ليعاد بناء الواجهة
  void pokeTheme() => notifyListeners();

  void finishOnboarding() {
    onboarded = true;
    _commit();
  }

  void setSound(String id) {
    sound = id;
    _commit();
  }

  bool buyPlant(String id) {
    final t = plantById(id);
    if (unlocked.contains(id)) return true;
    if (coins < t.price) return false;
    coins -= t.price;
    unlocked.add(id);
    _commit();
    return true;
  }

  /// عدد الأيام المتتالية (حتى اليوم) التي فيها شجرة حيّة على الأقل
  int streak() {
    final days = <String>{};
    for (final r in plants) {
      if (!r.alive) continue;
      final b = DateTime.parse(r.weekKey);
      days.add(dateKey(DateTime(b.year, b.month, b.day + r.day)));
    }
    var d = DateTime.now();
    var n = 0;
    if (!days.contains(dateKey(d))) d = DateTime(d.year, d.month, d.day - 1);
    while (days.contains(dateKey(d))) {
      n++;
      d = DateTime(d.year, d.month, d.day - 1);
    }
    return n;
  }

  void setLowPower(bool v) {
    lowPower = v;
    _commit();
  }

  void setStrict(bool v) {
    strict = v;
    _commit();
  }

  // ---------- chat / AI ----------
  void addChat(ChatMsg m) {
    chat.add(m);
    _commit();
  }

  void clearChat() {
    chat = [];
    _commit();
  }

  String planForAi() => jsonEncode({
        'days': {for (var i = 0; i < 7; i++) '$i': dayNames[i]},
        'subjects': subjects.map((s) => s.name).toList(),
        'items': plan
            .map((p) => {
                  'id': p.id,
                  'day': p.day,
                  'subject': subjectById(p.subjectId).name,
                  'title': p.title,
                  'minutes': p.minutes,
                })
            .toList(),
      });

  Map<String, dynamic> _snapshot() => {
        'subjects': subjects.map((e) => e.toJson()).toList(),
        'plan': plan.map((e) => e.toJson()).toList(),
        'done': done.toList(),
      };

  void undo() {
    final u = _undo;
    if (u == null) return;
    final m = jsonDecode(u) as Map<String, dynamic>;
    subjects = (m['subjects'] as List).map((e) => Subject.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    plan = (m['plan'] as List).map((e) => PlanItem.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    done = (m['done'] as List).map((e) => '$e').toSet();
    _undo = null;
    _commit();
  }

  int? _dayOf(dynamic v) {
    if (v is num) {
      final i = v.toInt();
      return (i >= 0 && i <= 6) ? i : null;
    }
    if (v is String) {
      final n = int.tryParse(v.trim());
      if (n != null) return (n >= 0 && n <= 6) ? n : null;
      final s = normAr(v);
      for (var i = 0; i < 7; i++) {
        final d = normAr(dayNames[i]);
        if (s == d || s.contains(d) || d.contains(s) && s.length > 2) return i;
      }
    }
    return null;
  }

  int _intOf(dynamic v, int def) {
    if (v is num) return v.toInt().clamp(5, 600);
    if (v is String) return (int.tryParse(v.trim()) ?? def).clamp(5, 600);
    return def;
  }

  Subject _subjectFor(dynamic name) {
    final s = normAr('${name ?? ''}');
    for (final x in subjects) {
      final n = normAr(x.name);
      if (n == s || (s.isNotEmpty && (n.contains(s) || s.contains(n)))) return x;
    }
    const palette = [0xFF4DB6AC, 0xFFFF8A65, 0xFF9575CD, 0xFFAED581, 0xFF4DD0E1, 0xFFFFD54F];
    final ns = Subject(
      id: _id(),
      name: '${name ?? 'مادة'}'.trim().isEmpty ? 'مادة' : '${name}'.trim(),
      emoji: '📘',
      color: palette[_rnd.nextInt(palette.length)],
    );
    subjects.add(ns);
    return ns;
  }

  PlanItem? _itemById(dynamic id) {
    for (final p in plan) {
      if (p.id == '$id') return p;
    }
    return null;
  }

  List<String> applyActions(List<dynamic> actions) {
    final before = jsonEncode(_snapshot());
    final out = <String>[];
    for (final a in actions) {
      if (a is! Map) continue;
      final op = '${a['op']}';
      try {
        if (op == 'add') {
          final d = _dayOf(a['day']);
          if (d == null) continue;
          final s = _subjectFor(a['subject']);
          final m = _intOf(a['minutes'], 60);
          final t = '${a['title'] ?? ''}'.trim();
          plan.add(PlanItem(id: _id(), day: d, subjectId: s.id, title: t, minutes: m));
          out.add('➕ ${dayNames[d]}: ${s.name} ${fmtMin(m)}');
        } else if (op == 'update' || op == 'move') {
          final it = _itemById(a['id']);
          if (it == null) continue;
          if (a['day'] != null) {
            final d = _dayOf(a['day']);
            if (d != null) it.day = d;
          }
          if (a['subject'] != null) it.subjectId = _subjectFor(a['subject']).id;
          if (a['title'] != null) it.title = '${a['title']}'.trim();
          if (a['minutes'] != null) it.minutes = _intOf(a['minutes'], it.minutes);
          out.add('✏️ ${dayNames[it.day]}: ${subjectById(it.subjectId).name} ${fmtMin(it.minutes)}');
        } else if (op == 'remove') {
          final it = _itemById(a['id']);
          if (it == null) continue;
          plan.removeWhere((e) => e.id == it.id);
          out.add('🗑️ حُذف: ${subjectById(it.subjectId).name} (${dayNames[it.day]})');
        } else if (op == 'clear_day') {
          final d = _dayOf(a['day']);
          if (d == null) continue;
          plan.removeWhere((e) => e.day == d);
          out.add('🧹 أُفرغ يوم ${dayNames[d]}');
        }
      } catch (_) {}
    }
    if (out.isNotEmpty) _undo = before;
    _commit();
    return out;
  }
}

class StoreScope extends InheritedNotifier<AppStore> {
  const StoreScope({super.key, required AppStore store, required super.child}) : super(notifier: store);
  static AppStore of(BuildContext c) => c.dependOnInheritedWidgetOfExactType<StoreScope>()!.notifier!;
  static AppStore read(BuildContext c) => c.getInheritedWidgetOfExactType<StoreScope>()!.notifier!;
}

List<Subject> _defaultSubjects() => [
      Subject(id: 'math', name: 'رياضيات', emoji: '📐', color: 0xFF4FC3F7),
      Subject(id: 'physics', name: 'فيزياء', emoji: '⚡', color: 0xFFFFB74D),
      Subject(id: 'chem', name: 'كيمياء', emoji: '🧪', color: 0xFFBA68C8),
      Subject(id: 'science', name: 'علوم', emoji: '🧬', color: 0xFF81C784),
      Subject(id: 'arabic', name: 'عربي', emoji: '📖', color: 0xFFE57373),
      Subject(id: 'english', name: 'إنكليزي', emoji: '🔤', color: 0xFF64B5F6),
      Subject(id: 'french', name: 'فرنسي', emoji: '🥖', color: 0xFFF06292),
      Subject(id: 'religion', name: 'ديانة', emoji: '🕌', color: 0xFFA1887F),
    ];

List<PlanItem> _defaultPlan() {
  var n = 0;
  PlanItem p(int d, String s, String t, int m) =>
      PlanItem(id: 'd${n++}', day: d, subjectId: s, title: t, minutes: m);
  return [
    p(0, 'math', '3 فيديوهات + حل تمارين', 180),
    p(0, 'physics', 'فيديوهان + حل', 150),
    p(0, 'science', 'درس جديد', 90),
    p(0, 'english', 'درس', 60),
    p(1, 'math', '3 فيديوهات + حل تمارين', 180),
    p(1, 'arabic', 'درس', 90),
    p(1, 'science', 'مراجعة', 60),
    p(1, 'english', 'درس', 60),
    p(1, 'french', 'درس', 60),
    p(1, 'chem', 'حل أسئلة', 30),
    p(2, 'math', '3 فيديوهات + حل تمارين', 150),
    p(2, 'physics', 'فيديوهان + حل', 120),
    p(2, 'chem', 'درس جديد', 90),
    p(2, 'science', 'درس', 60),
    p(2, 'arabic', 'درس', 60),
    p(3, 'math', '3 فيديوهات + حل تمارين', 180),
    p(3, 'chem', 'حل + مراجعة', 90),
    p(3, 'science', 'مراجعة', 60),
    p(3, 'arabic', 'درس', 60),
    p(3, 'religion', 'درس', 60),
    p(3, 'english', 'مراجعة', 30),
    p(4, 'math', '3 فيديوهات + حل تمارين', 180),
    p(4, 'physics', 'فيديوهان + حل', 150),
    p(4, 'chem', 'حل أسئلة', 60),
    p(4, 'french', 'درس', 60),
    p(4, 'english', 'درس', 30),
    p(5, 'math', 'حل دورة كاملة بوقت الامتحان', 180),
    p(5, 'math', 'تصحيح الدورة وتدوين الأخطاء', 60),
    p(5, 'physics', 'مراجعة', 30),
    p(5, 'chem', 'مراجعة', 30),
    p(5, 'science', 'مراجعات مختلفة', 60),
    p(6, 'math', '3 فيديوهات + حل تمارين', 180),
    p(6, 'physics', 'فيديوهان + حل', 120),
    p(6, 'arabic', 'درس', 90),
    p(6, 'chem', 'درس', 60),
    p(6, 'religion', 'درس', 30),
  ];
}
