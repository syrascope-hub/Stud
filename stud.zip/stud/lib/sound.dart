import 'package:audioplayers/audioplayers.dart';

const soundOptions = [
  ['none', 'بدون', '🔇'],
  ['rain', 'مطر', '🌧️'],
  ['wind', 'رياح', '🍃'],
  ['waves', 'أمواج', '🌊'],
  ['brown', 'ضوضاء هادئة', '🌙'],
];

/// تشغيل أصوات محيطة متكررة أثناء التركيز (ملفات مضمّنة، تعمل بدون إنترنت)
class SoundService {
  static final AudioPlayer _p = AudioPlayer();
  static String? _cur;

  static Future<void> play(String id) async {
    try {
      if (id == 'none') {
        await stop();
        return;
      }
      if (_cur == id) return;
      await _p.setReleaseMode(ReleaseMode.loop);
      await _p.setVolume(0.6);
      await _p.play(AssetSource('sounds/$id.wav'));
      _cur = id;
    } catch (_) {}
  }

  static Future<void> stop() async {
    try {
      await _p.stop();
    } catch (_) {}
    _cur = null;
  }
}
