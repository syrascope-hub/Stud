import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'plant_models.dart';
import 'scene3d.dart';
import 'store.dart';

class PlantInstance {
  final String id;
  final String type;
  final double x, z;
  final int seed;
  final double size;
  final double growth;
  final bool alive;
  const PlantInstance({
    required this.id,
    required this.type,
    required this.x,
    required this.z,
    required this.seed,
    this.size = 1.0,
    this.growth = 1.0,
    this.alive = true,
  });
}

double sizeForMinutes(int minutes) => 0.72 + 0.5 * (math.min(minutes, 120) / 120.0);

class ForestPainter extends CustomPainter {
  final List<PlantInstance> plants;
  final double yaw, pitch, zoom, islandR, centerY;
  final bool night, autoRotate, lite;
  final ValueListenable<double> time;
  Cam? lastCam;

  ForestPainter({
    required this.plants,
    required this.yaw,
    required this.pitch,
    required this.zoom,
    required this.islandR,
    required this.centerY,
    required this.night,
    required this.autoRotate,
    required this.lite,
    required this.time,
  }) : super(repaint: time);

  double get _t => lite ? 0.0 : time.value;

  @override
  void paint(Canvas canvas, Size size) {
    final t = _t;
    _sky(canvas, size, t);
    final cam = Cam(
      yaw: yaw + (autoRotate && !lite ? t * 0.14 : 0),
      pitch: pitch,
      unit: size.shortestSide / 6.2 * zoom,
      center: Offset(size.width / 2, size.height * centerY),
    );
    lastCam = cam;
    final s = Scene3D(cam, flat: true, lite: lite);
    s.island(islandR);
    s.decor(islandR);
    for (final p in plants) {
      buildPlant(
        s,
        p.type,
        V3(p.x, 0, p.z),
        growth: p.growth,
        size: p.size,
        seed: p.seed,
        alive: p.alive,
        t: t,
      );
    }
    s.paint(canvas);
  }

  void _sky(Canvas cv, Size size, double t) {
    final rect = Offset.zero & size;
    final top = night ? const Color(0xFF16213E) : const Color(0xFFBDE9F7);
    final bot = night ? const Color(0xFF2A3A5E) : const Color(0xFFF4FBE9);
    cv.drawRect(rect, Paint()..shader = ui.Gradient.linear(rect.topCenter, rect.bottomCenter, [top, bot]));
    if (night) {
      if (!lite) {
        final r = math.Random(5);
        for (var i = 0; i < 30; i++) {
          final tw = 0.5 + 0.5 * math.sin(t * 2 + i);
          cv.drawCircle(
            Offset(r.nextDouble() * size.width, r.nextDouble() * size.height * 0.55),
            0.6 + r.nextDouble() * 1.1,
            Paint()..color = Colors.white.withValues(alpha: 0.35 + 0.5 * tw),
          );
        }
      }
      cv.drawCircle(Offset(size.width * 0.82, size.height * 0.14), 22, Paint()..color = const Color(0xFFFFF3C4));
    } else {
      final c = Offset(size.width * 0.2, size.height * 0.14);
      cv.drawCircle(c, 26, Paint()..color = const Color(0xFFFFE9A0));
      if (!lite) {
        for (var i = 0; i < 3; i++) {
          final x = ((i * 0.37 + t * 0.004 * (1 + i * 0.2)) % 1.3 - 0.15) * size.width;
          final y = size.height * (0.08 + 0.07 * i);
          final p = Paint()..color = Colors.white.withValues(alpha: 0.85);
          final w = 26.0 + i * 6;
          cv.drawCircle(Offset(x, y), w * 0.6, p);
          cv.drawCircle(Offset(x + w * 0.6, y + 3), w * 0.5, p);
          cv.drawCircle(Offset(x - w * 0.6, y + 4), w * 0.45, p);
        }
      }
    }
    final hill = Path()..moveTo(0, size.height);
    for (var x = 0.0; x <= size.width; x += 16) {
      hill.lineTo(x, size.height * 0.62 + math.sin(x * 0.012 + 1) * 14 + math.sin(x * 0.03) * 5);
    }
    hill.lineTo(size.width, size.height);
    hill.close();
    cv.drawPath(hill, Paint()..color = night ? const Color(0xFF1E3550) : const Color(0xFFD3EFC4));
  }

  PlantInstance? hit(Offset pos) {
    final cam = lastCam;
    if (cam == null) return null;
    PlantInstance? best;
    var bd = double.infinity;
    for (final p in plants) {
      final pr = cam.proj(V3(p.x, 0.7 * p.size, p.z));
      final d = (pr.o - pos).distance;
      final th = 0.8 * pr.k * p.size + 12;
      if (d < th && d < bd) {
        bd = d;
        best = p;
      }
    }
    return best;
  }

  @override
  bool shouldRepaint(covariant ForestPainter old) => true;
}

class ForestView extends StatefulWidget {
  final List<PlantInstance> plants;
  final bool autoRotate;
  final double islandR;
  final double zoom;
  final double centerY;
  final double pitch;
  final void Function(PlantInstance)? onTapPlant;
  const ForestView({
    super.key,
    required this.plants,
    this.autoRotate = false,
    this.islandR = 3.4,
    this.zoom = 1.0,
    this.centerY = 0.58,
    this.pitch = 0.62,
    this.onTapPlant,
  });

  @override
  State<ForestView> createState() => _ForestViewState();
}

class _ForestViewState extends State<ForestView> with TickerProviderStateMixin {
  final ValueNotifier<double> _time = ValueNotifier<double>(0);
  Ticker? _ticker;
  Duration _last = Duration.zero;
  double _yaw = -0.6;
  late double _pitch = widget.pitch;
  late double _zoom = widget.zoom;
  double _baseZoom = 1;
  ForestPainter? _painter;

  @override
  void dispose() {
    _ticker?.dispose();
    _time.dispose();
    super.dispose();
  }

  /// في الوضع الخفيف لا يوجد مؤقت رسم أبداً: المشهد ثابت ويُعاد رسمه عند اللمس فقط.
  void _syncTicker(bool lite) {
    if (lite) {
      _ticker?.dispose();
      _ticker = null;
    } else if (_ticker == null) {
      _ticker = createTicker((elapsed) {
        if ((elapsed - _last).inMilliseconds >= 33) {
          _last = elapsed;
          _time.value = elapsed.inMilliseconds / 1000.0;
        }
      })..start();
    }
  }

  bool get _night {
    final h = DateTime.now().hour;
    return h >= 19 || h < 5;
  }

  @override
  Widget build(BuildContext context) {
    final lite = StoreScope.of(context).lowPower;
    _syncTicker(lite);
    _painter = ForestPainter(
      plants: widget.plants,
      yaw: _yaw,
      pitch: _pitch,
      zoom: _zoom,
      islandR: widget.islandR,
      centerY: widget.centerY,
      night: _night,
      autoRotate: widget.autoRotate,
      lite: lite,
      time: _time,
    );
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onScaleStart: (d) => _baseZoom = _zoom,
      onScaleUpdate: (d) {
        setState(() {
          _yaw += d.focalPointDelta.dx * 0.011;
          _pitch = (_pitch - d.focalPointDelta.dy * 0.004).clamp(0.3, 1.2).toDouble();
          if (d.pointerCount > 1) {
            _zoom = (_baseZoom * d.scale).clamp(widget.zoom * 0.6, widget.zoom * 2.2).toDouble();
          }
        });
      },
      onTapUp: (d) {
        final p = _painter?.hit(d.localPosition);
        if (p != null) widget.onTapPlant?.call(p);
      },
      child: RepaintBoundary(
        child: SizedBox.expand(
          child: CustomPaint(painter: _painter, isComplex: true),
        ),
      ),
    );
  }
}
