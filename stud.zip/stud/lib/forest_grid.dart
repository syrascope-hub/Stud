import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'models.dart';
import 'plant_models.dart';
import 'scene3d.dart';

const int kMaxGrid = 8;

/// حجم الرقعة (n × n) حسب عدد النباتات
int gridSideFor(int count) => math.min(kMaxGrid, math.max(4, math.sqrt(count.toDouble()).ceil()));

/// رقعة متساوية القياس: كل نبتة في مربع، بأسلوب تطبيق Forest
class GridForestPainter extends CustomPainter {
  final List<PlantRecord> plants; // مرتّبة زمنياً
  final bool lite;
  Cam? lastCam;
  List<List<double>> _cells = []; // لكل نبتة: [x, z]

  GridForestPainter({required this.plants, required this.lite});

  List<double> cellCenter(int n, int idx) {
    final i = idx % n, j = idx ~/ n;
    return [i - (n - 1) / 2, j - (n - 1) / 2];
  }

  @override
  void paint(Canvas canvas, Size size) {
    final list = plants.length > kMaxGrid * kMaxGrid ? plants.sublist(plants.length - kMaxGrid * kMaxGrid) : plants;
    final n = gridSideFor(list.length);
    final cam = Cam(
      yaw: math.pi / 4,
      pitch: 0.6,
      unit: size.width * 0.66 / n,
      center: Offset(size.width / 2, size.height * 0.56),
      dist: 30,
    );
    lastCam = cam;
    final half = n / 2;
    const thick = 0.55;

    // ---- جوانب التربة ----
    final corners = [V3(-half, 0, -half), V3(half, 0, -half), V3(half, 0, half), V3(-half, 0, half)];
    final faces = <_Face>[];
    for (var k = 0; k < 4; k++) {
      final a = corners[k], b = corners[(k + 1) % 4];
      final pa = cam.proj(a), pb = cam.proj(b);
      final pa2 = cam.proj(V3(a.x, -thick, a.z)), pb2 = cam.proj(V3(b.x, -thick, b.z));
      final mid = V3((a.x + b.x) / 2, 0, (a.z + b.z) / 2);
      final nrm = V3(mid.x, 0, mid.z).norm();
      final f = 0.7 + 0.3 * math.max(0.0, nrm.dot(kLight));
      faces.add(_Face((pa.depth + pb.depth) / 2, pa, pb, pa2, pb2, f, a, b));
    }
    faces.sort((x, y) => y.depth.compareTo(x.depth));

    // ظل أسفل الرقعة
    final sh = Path();
    for (var k = 0; k < 4; k++) {
      final p = cam.proj(V3(corners[k].x * 1.04, -thick - 0.05, corners[k].z * 1.04));
      if (k == 0) {
        sh.moveTo(p.x, p.y + 10);
      } else {
        sh.lineTo(p.x, p.y + 10);
      }
    }
    sh.close();
    canvas.drawPath(sh, Paint()..color = Colors.black.withValues(alpha: 0.18));

    for (final f in faces) {
      final soil = Path()
        ..moveTo(f.pa.x, f.pa.y)
        ..lineTo(f.pb.x, f.pb.y)
        ..lineTo(f.pb2.x, f.pb2.y)
        ..lineTo(f.pa2.x, f.pa2.y)
        ..close();
      canvas.drawPath(soil, Paint()..color = shade(const Color(0xFF8B5A2B), f.f));
      // حبيبات تربة بسيطة
      if (!lite) {
        final rnd = math.Random(f.pa.x.toInt() * 7 + n);
        final dots = Paint()..color = shade(const Color(0xFF6E441F), f.f);
        for (var i = 0; i < n * 3; i++) {
          final t = rnd.nextDouble();
          final u = 0.25 + rnd.nextDouble() * 0.6;
          final x = f.pa.x + (f.pb.x - f.pa.x) * t;
          final y = f.pa.y + (f.pb.y - f.pa.y) * t + (f.pa2.y - f.pa.y) * u;
          canvas.drawCircle(Offset(x, y), 2.2, dots);
        }
      }
      // حافة العشب
      final lipA = cam.proj(V3(f.a.x, -0.12, f.a.z));
      final lipB = cam.proj(V3(f.b.x, -0.12, f.b.z));
      final lip = Path()
        ..moveTo(f.pa.x, f.pa.y)
        ..lineTo(f.pb.x, f.pb.y)
        ..lineTo(lipB.x, lipB.y)
        ..lineTo(lipA.x, lipA.y)
        ..close();
      canvas.drawPath(lip, Paint()..color = shade(const Color(0xFF6DBB3F), 0.78 + 0.25 * f.f));
    }

    // ---- سطح العشب ----
    final top = Path();
    for (var k = 0; k < 4; k++) {
      final p = cam.proj(corners[k]);
      if (k == 0) {
        top.moveTo(p.x, p.y);
      } else {
        top.lineTo(p.x, p.y);
      }
    }
    top.close();
    canvas.drawPath(top, Paint()..color = const Color(0xFFA6DD55));
    final dark = Paint()..color = const Color(0xFF97D04A);
    for (var i = 0; i < n; i++) {
      for (var j = 0; j < n; j++) {
        if ((i + j).isOdd) continue;
        final x0 = i - half, z0 = j - half;
        final q = Path();
        final ps = [V3(x0, 0, z0), V3(x0 + 1, 0, z0), V3(x0 + 1, 0, z0 + 1), V3(x0, 0, z0 + 1)];
        for (var k = 0; k < 4; k++) {
          final p = cam.proj(ps[k]);
          if (k == 0) {
            q.moveTo(p.x, p.y);
          } else {
            q.lineTo(p.x, p.y);
          }
        }
        q.close();
        canvas.drawPath(q, dark);
      }
    }

    // ---- النباتات ----
    final order = List<int>.generate(n * n, (i) => i)..shuffle(math.Random(n * 1013 + 5));
    _cells = [];
    final s = Scene3D(cam, flat: true, lite: lite || list.length > 20);
    for (var i = 0; i < list.length; i++) {
      final r = list[i];
      final c = cellCenter(n, order[i]);
      _cells.add(c);
      buildPlant(
        s,
        r.type,
        V3(c[0], 0, c[1]),
        growth: 1.0,
        size: 0.5 + 0.3 * (math.min(r.minutes, 120) / 120.0),
        seed: r.seed,
        alive: r.alive,
        t: 0,
      );
    }
    s.paint(canvas);
  }

  PlantRecord? hit(Offset pos) {
    final cam = lastCam;
    if (cam == null) return null;
    final list = plants.length > kMaxGrid * kMaxGrid ? plants.sublist(plants.length - kMaxGrid * kMaxGrid) : plants;
    PlantRecord? best;
    var bd = double.infinity;
    for (var i = 0; i < _cells.length && i < list.length; i++) {
      final pr = cam.proj(V3(_cells[i][0], 0.5, _cells[i][1]));
      final d = (pr.o - pos).distance;
      if (d < pr.k * 0.7 && d < bd) {
        bd = d;
        best = list[i];
      }
    }
    return best;
  }

  @override
  bool shouldRepaint(covariant GridForestPainter old) => old.plants != plants || old.lite != lite;
}

class _Face {
  final double depth;
  final P pa, pb, pa2, pb2;
  final double f;
  final V3 a, b;
  _Face(this.depth, this.pa, this.pb, this.pa2, this.pb2, this.f, this.a, this.b);
}

class GridForestView extends StatefulWidget {
  final List<PlantRecord> plants;
  final bool lite;
  final void Function(PlantRecord) onTap;
  const GridForestView({super.key, required this.plants, required this.lite, required this.onTap});

  @override
  State<GridForestView> createState() => _GridForestViewState();
}

class _GridForestViewState extends State<GridForestView> {
  GridForestPainter? _painter;

  @override
  Widget build(BuildContext context) {
    final sorted = [...widget.plants]..sort((a, b) => a.ts.compareTo(b.ts));
    _painter = GridForestPainter(plants: sorted, lite: widget.lite);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapUp: (d) {
        final r = _painter?.hit(d.localPosition);
        if (r != null) widget.onTap(r);
      },
      child: RepaintBoundary(child: SizedBox.expand(child: CustomPaint(painter: _painter, isComplex: true))),
    );
  }
}
