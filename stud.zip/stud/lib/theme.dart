import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class C {
  static const bg = Color(0xFF0D1913);
  static const surface = Color(0xFF16261E);
  static const surface2 = Color(0xFF1F342A);
  static const accent = Color(0xFF6EE7A0);
  static const onAccent = Color(0xFF06281A);
  static const amber = Color(0xFFFFD166);
  static const text = Color(0xFFE8F5EC);
  static const sub = Color(0xFF93AD9C);
  static const danger = Color(0xFFFF6B6B);
}

ThemeData buildTheme() {
  final base = ThemeData(
    brightness: Brightness.dark,
    useMaterial3: true,
    scaffoldBackgroundColor: C.bg,
    colorScheme: ColorScheme.fromSeed(seedColor: C.accent, brightness: Brightness.dark).copyWith(
      primary: C.accent,
      onPrimary: C.onAccent,
      secondary: C.amber,
      surface: C.surface,
      onSurface: C.text,
    ),
  );
  return base.copyWith(
    textTheme: GoogleFonts.cairoTextTheme(base.textTheme).apply(bodyColor: C.text, displayColor: C.text),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: C.surface,
      indicatorColor: C.accent.withValues(alpha: 0.18),
      labelTextStyle: WidgetStatePropertyAll(GoogleFonts.cairo(fontSize: 12, fontWeight: FontWeight.w600)),
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: C.surface,
      surfaceTintColor: Colors.transparent,
    ),
  );
}

class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final Color? color;
  final EdgeInsets margin;
  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.color,
    this.margin = EdgeInsets.zero,
  });
  @override
  Widget build(BuildContext context) => Container(
        margin: margin,
        padding: padding,
        decoration: BoxDecoration(
          color: color ?? C.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: Colors.white.withValues(alpha: 0.05)),
        ),
        child: child,
      );
}

ButtonStyle bigButton({Color? bg, Color? fg}) => FilledButton.styleFrom(
      backgroundColor: bg ?? C.accent,
      foregroundColor: fg ?? C.onAccent,
      minimumSize: const Size.fromHeight(54),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      textStyle: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w700),
    );

InputDecoration fieldDeco(String label, {String? hint}) => InputDecoration(
      labelText: label,
      hintText: hint,
      filled: true,
      fillColor: C.surface2,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
    );
