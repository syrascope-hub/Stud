import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'plant_models.dart';
import 'scene3d.dart';

/// دائرة المؤقت: قرص كريمي + حلقة تقدّم
class RingPainter extends CustomPainter {
  final double progress;
  const RingPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.shortestSide / 2 - 12;
    canvas.drawCircle(c, r, Paint()..color = const Color(0xFFE6E7A8));
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 14
      ..color = const Color(0xFFCDCF86);
    canvas.drawCircle(c, r, ring);
    if (progress > 0) {
      final arc = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 14
        ..strokeCap = StrokeCap.round
        ..color = const Color(0xFF8CC63F);
      canvas.drawArc(Rect.fromCircle(center: c, radius: r), -math.pi / 2, 2 * math.pi * progress, false, arc);
      final a = -math.pi / 2 + 2 * math.pi * progress;
      canvas.drawCircle(Offset(c.dx + math.cos(a) * r, c.dy + math.sin(a) * r), 11, Paint()..color = const Color(0xFF8CC63F));
    }
  }

  @override
  bool shouldRepaint(covariant RingPainter old) => old.progress != progress;
}

/// وعاء تربة تنمو فيه نبتة (يُرسم داخل الدائرة)
class BowlPainter extends CustomPainter {
  final String type;
  final double growth;
  final double plantSize;
  final bool alive;
  const BowlPainter({required this.type, required this.growth, this.plantSize = 1.0, this.alive = true});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final cam = Cam(yaw: 0.0, pitch: 0.14, unit: w / 5.8, center: Offset(w / 2, h * 0.70), dist: 18);
    final o = cam.proj(const V3(0, 0, 0)).o;
    final rw = w * 0.30;
    final body = Path()
      ..moveTo(o.dx - rw, o.dy)
      ..quadraticBezierTo(o.dx - rw * 0.9, o.dy + h * 0.17, o.dx, o.dy + h * 0.19)
      ..quadraticBezierTo(o.dx + rw * 0.9, o.dy + h * 0.17, o.dx + rw, o.dy)
      ..close();
    canvas.drawPath(body, Paint()..color = const Color(0xFF7B4220));
    canvas.drawOval(Rect.fromCenter(center: o, width: rw * 2, height: h * 0.075), Paint()..color = const Color(0xFF9A5A2B));
    final s = Scene3D(cam, flat: true, lite: false);
    buildPlant(s, type, const V3(0, 0, 0), growth: growth, size: plantSize, seed: 7, alive: alive, t: 0);
    s.paint(canvas);
  }

  @override
  bool shouldRepaint(covariant BowlPainter old) =>
      old.type != type || old.growth != growth || old.alive != alive || old.plantSize != plantSize;
}

/// شخصية المساعد: برعم صغير (تصميم أصلي لتطبيق Stud)
class SproutPainter extends CustomPainter {
  const SproutPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final c = Offset(w / 2, h * 0.58);
    final r = w * 0.34;
    // ظل
    canvas.drawOval(Rect.fromCenter(center: Offset(w / 2, h * 0.93), width: r * 1.6, height: h * 0.07),
        Paint()..color = Colors.black.withValues(alpha: 0.12));
    // الجسم (بذرة كريمية)
    final body = Rect.fromCenter(center: c, width: r * 2, height: r * 2.15);
    canvas.drawOval(body, Paint()..color = const Color(0xFFFFE9B8));
    canvas.drawOval(
      Rect.fromCenter(center: Offset(c.dx - r * 0.12, c.dy - r * 0.15), width: r * 1.6, height: r * 1.7),
      Paint()..color = const Color(0xFFFFF4D6),
    );
    // ساق وورقتان
    final stem = Paint()
      ..color = const Color(0xFF4E9F5B)
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.03
      ..strokeCap = StrokeCap.round;
    final top = Offset(c.dx, c.dy - r * 1.05);
    canvas.drawLine(top, Offset(top.dx, top.dy - h * 0.08), stem);
    Path leaf(double dir) => Path()
      ..moveTo(top.dx, top.dy - h * 0.07)
      ..quadraticBezierTo(top.dx + dir * w * 0.16, top.dy - h * 0.2, top.dx + dir * w * 0.22, top.dy - h * 0.1)
      ..quadraticBezierTo(top.dx + dir * w * 0.1, top.dy - h * 0.05, top.dx, top.dy - h * 0.07)
      ..close();
    canvas.drawPath(leaf(1), Paint()..color = const Color(0xFF66BB6A));
    canvas.drawPath(leaf(-1), Paint()..color = const Color(0xFF8BD17C));
    // الوجه
    final eye = Paint()..color = const Color(0xFF2A3B2F);
    final ey = c.dy - r * 0.05;
    canvas.drawCircle(Offset(c.dx - r * 0.38, ey), r * 0.11, eye);
    canvas.drawCircle(Offset(c.dx + r * 0.38, ey), r * 0.11, eye);
    final hi = Paint()..color = Colors.white;
    canvas.drawCircle(Offset(c.dx - r * 0.35, ey - r * 0.04), r * 0.04, hi);
    canvas.drawCircle(Offset(c.dx + r * 0.41, ey - r * 0.04), r * 0.04, hi);
    final blush = Paint()..color = const Color(0xFFFFA8A0).withValues(alpha: 0.65);
    canvas.drawOval(Rect.fromCenter(center: Offset(c.dx - r * 0.62, ey + r * 0.28), width: r * 0.26, height: r * 0.16), blush);
    canvas.drawOval(Rect.fromCenter(center: Offset(c.dx + r * 0.62, ey + r * 0.28), width: r * 0.26, height: r * 0.16), blush);
    final mouth = Paint()
      ..color = const Color(0xFF2A3B2F)
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.014
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(Rect.fromCenter(center: Offset(c.dx, ey + r * 0.3), width: r * 0.3, height: r * 0.22), 0.2, math.pi - 0.4, false, mouth);
  }

  @override
  bool shouldRepaint(covariant SproutPainter old) => false;
}

class Sprout extends StatelessWidget {
  final double size;
  const Sprout({super.key, this.size = 56});
  @override
  Widget build(BuildContext context) =>
      SizedBox(width: size, height: size, child: const CustomPaint(painter: SproutPainter()));
}

/// دائرة المؤقت مع الوعاء والنبتة
class TimerCircle extends StatelessWidget {
  final double size;
  final double progress; // 0..1 (حلقة)
  final String type;
  final double growth;
  final double plantSize;
  final bool alive;
  const TimerCircle({
    super.key,
    required this.size,
    required this.progress,
    required this.type,
    required this.growth,
    this.plantSize = 1.0,
    this.alive = true,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        children: [
          Positioned.fill(child: CustomPaint(painter: RingPainter(progress))),
          Positioned.fill(
            child: CustomPaint(
              painter: BowlPainter(type: type, growth: growth, plantSize: plantSize, alive: alive),
            ),
          ),
        ],
      ),
    );
  }
}
