import 'package:flutter/material.dart';
import '../ai_service.dart';
import '../store.dart';
import '../theme.dart';

class AiPage extends StatefulWidget {
  const AiPage({super.key});
  @override
  State<AiPage> createState() => _AiPageState();
}

class _AiPageState extends State<AiPage> {
  final _ctl = TextEditingController();
  final _scroll = ScrollController();
  bool _loading = false;

  static const _suggestions = [
    'انقل الكيمياء من الثلاثاء إلى الأربعاء',
    'خفف يوم السبت ساعتين',
    'أضف ساعة مراجعة فيزياء كل خميس',
    'اجعل الجمعة يوم راحة بعد الظهر',
  ];

  @override
  void dispose() {
    _ctl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _toBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _settings() async {
    final s = StoreScope.read(context);
    final key = TextEditingController(text: s.apiKey);
    final model = TextEditingController(text: s.model);
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('إعدادات OpenRouter'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: key,
                obscureText: true,
                decoration: fieldDeco('مفتاح API', hint: 'sk-or-v1-...'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: model,
                decoration: fieldDeco('النموذج', hint: 'openai/gpt-4o-mini'),
              ),
              const SizedBox(height: 10),
              const Text(
                'يُحفظ المفتاح على جهازك فقط. احصل عليه من openrouter.ai/keys. '
                'يمكنك استخدام أي نموذج من القائمة، ومنها المجانية التي تنتهي بـ :free',
                style: TextStyle(color: C.sub, fontSize: 12, height: 1.6),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              s.setApi(key: key.text, mdl: model.text);
              Navigator.pop(ctx);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  Future<void> _send([String? preset]) async {
    final s = StoreScope.read(context);
    final text = (preset ?? _ctl.text).trim();
    if (text.isEmpty || _loading) return;
    if (s.apiKey.isEmpty) {
      await _settings();
      if (s.apiKey.isEmpty) return;
    }
    _ctl.clear();
    final recent = s.chat.length > 8 ? s.chat.sublist(s.chat.length - 8) : List<ChatMsg>.from(s.chat);
    final history = [
      for (final m in recent) {'role': m.user ? 'user' : 'assistant', 'content': m.text},
    ];
    s.addChat(ChatMsg(true, text));
    setState(() => _loading = true);
    _toBottom();
    try {
      final r = await AiService.ask(
        apiKey: s.apiKey,
        model: s.model,
        planJson: s.planForAi(),
        history: history,
        userText: text,
      );
      final changes = r.actions.isNotEmpty ? s.applyActions(r.actions) : <String>[];
      final reply = r.reply.isNotEmpty ? r.reply : (changes.isEmpty ? 'تم.' : 'تم تعديل المخطط ✅');
      s.addChat(ChatMsg(false, reply, changes));
    } catch (e) {
      s.addChat(ChatMsg(false, '⚠️ ${e.toString().replaceFirst('Exception: ', '')}'));
    } finally {
      if (mounted) setState(() => _loading = false);
      _toBottom();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 8, 8),
            child: Row(
              children: [
                const Expanded(
                  child: Text('المساعد', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                ),
                if (s.canUndo)
                  TextButton.icon(
                    onPressed: s.undo,
                    icon: const Icon(Icons.undo, size: 18),
                    label: const Text('تراجع'),
                  ),
                if (s.chat.isNotEmpty)
                  IconButton(onPressed: s.clearChat, icon: const Icon(Icons.delete_sweep_outlined)),
                IconButton(onPressed: _settings, icon: const Icon(Icons.settings_outlined)),
              ],
            ),
          ),
          Expanded(
            child: s.chat.isEmpty && !_loading
                ? _intro()
                : ListView(
                    controller: _scroll,
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                    children: [
                      for (final m in s.chat) _bubble(m),
                      if (_loading)
                        const Align(
                          alignment: AlignmentDirectional.centerEnd,
                          child: Padding(
                            padding: EdgeInsets.all(12),
                            child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5)),
                          ),
                        ),
                    ],
                  ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _ctl,
                    minLines: 1,
                    maxLines: 4,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _send(),
                    decoration: fieldDeco('اطلب تعديلاً على المخطط...').copyWith(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  style: IconButton.styleFrom(backgroundColor: C.accent, foregroundColor: C.onAccent),
                  onPressed: _loading ? null : () => _send(),
                  icon: const Icon(Icons.arrow_upward),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _intro() => ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('✨', style: TextStyle(fontSize: 44), textAlign: TextAlign.center),
          const SizedBox(height: 8),
          const Text(
            'قل لي ما تريد تغييره في مخططك\nوسأعدّله لك مباشرة',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 17, height: 1.7, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 20),
          for (final t in _suggestions)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: ActionChip(
                backgroundColor: C.surface,
                side: BorderSide.none,
                label: Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text(t)),
                onPressed: () => _send(t),
              ),
            ),
        ],
      );

  Widget _bubble(ChatMsg m) {
    return Align(
      alignment: m.user ? AlignmentDirectional.centerStart : AlignmentDirectional.centerEnd,
      child: Container(
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          color: m.user ? C.accent : C.surface,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(m.text, style: TextStyle(color: m.user ? C.onAccent : C.text, height: 1.6)),
            if (m.changes.isNotEmpty) ...[
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: C.accent.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [for (final c in m.changes) Text(c, style: const TextStyle(fontSize: 13, height: 1.6))],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
