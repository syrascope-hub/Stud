import 'dart:async';
import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../forest_view.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

class FocusPage extends StatefulWidget {
  const FocusPage({super.key});
  @override
  State<FocusPage> createState() => _FocusPageState();
}

class _FocusPageState extends State<FocusPage> with WidgetsBindingObserver {
  String plant = 'oak';
  int minutes = 25;
  String? subjectId;
  Timer? _tick;
  int? _leftAt;
  bool _finishing = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final a = StoreScope.read(context).active;
      if (a == null) return;
      _startTicker();
      if (DateTime.now().millisecondsSinceEpoch >= a.endMs) {
        _complete();
      } else {
        WakelockPlus.enable();
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _tick?.cancel();
    super.dispose();
  }

  void _startTicker() {
    _tick?.cancel();
    _tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      final a = StoreScope.read(context).active;
      if (a == null) {
        _tick?.cancel();
        return;
      }
      if (DateTime.now().millisecondsSinceEpoch >= a.endMs) {
        _complete();
      } else {
        setState(() {});
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState st) {
    if (!mounted) return;
    final s = StoreScope.read(context);
    final a = s.active;
    if (a == null) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (st == AppLifecycleState.paused) {
      _leftAt = now;
    } else if (st == AppLifecycleState.resumed) {
      final left = _leftAt;
      _leftAt = null;
      if (now >= a.endMs) {
        _complete();
      } else if (left != null && s.strict && now - left > 8000) {
        _fail('خرجت من التطبيق أثناء التركيز فذبلت الشجرة 🥀');
      }
    }
  }

  void _begin(AppStore s) {
    s.startSession(plant, minutes, subjectId);
    WakelockPlus.enable();
    _startTicker();
  }

  void _complete() {
    if (_finishing) return;
    final s = StoreScope.read(context);
    if (s.active == null) return;
    _finishing = true;
    _tick?.cancel();
    final p = plantById(s.active!.type);
    final mins = s.active!.minutes;
    s.finishSession(true);
    WakelockPlus.disable();
    _finishing = false;
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: Text('${p.emoji} نمت شجرتك!'),
        content: Text('أنهيت ${fmtMin(mins)} من التركيز وزُرعت ${p.name} في غابة اليوم.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('متابعة')),
          FilledButton(
            onPressed: () {
              Navigator.pop(ctx);
              s.setTab(2);
            },
            child: const Text('عرض الغابة'),
          ),
        ],
      ),
    );
  }

  void _fail(String why) {
    final s = StoreScope.read(context);
    if (s.active == null) return;
    _tick?.cancel();
    s.finishSession(false);
    WakelockPlus.disable();
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('🥀 ذبلت الشجرة'),
        content: Text(why),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('حسناً'))],
      ),
    );
  }

  Future<void> _giveUp() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('التخلي عن الجلسة؟'),
        content: const Text('ستذبل الشجرة وتبقى في غابة اليوم كشجرة ميتة.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('أكمل التركيز')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('تخلَّ', style: TextStyle(color: C.danger)),
          ),
        ],
      ),
    );
    if (ok == true && mounted) _fail('تخليت عن الجلسة قبل الانتهاء.');
  }

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    final pr = s.preset;
    if (pr != null) {
      if (pr.subjectId != null) subjectId = pr.subjectId;
      if (pr.minutes != null) minutes = ((pr.minutes! / 5).round() * 5).clamp(5, 120).toInt();
      s.preset = null;
    }
    return SafeArea(child: s.active == null ? _idle(s) : _running(s));
  }

  // ---------------- قبل البدء ----------------
  Widget _idle(AppStore s) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 4),
            child: Text('التركيز', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 270,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(26),
              child: ForestView(
                key: ValueKey(plant),
                plants: [
                  PlantInstance(id: 'preview', type: plant, x: 0, z: 0, seed: 7, size: sizeForMinutes(minutes)),
                ],
                autoRotate: true,
                islandR: 2.3,
                zoom: 1.15,
              ),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 78,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: plantTypes.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final p = plantTypes[i];
                final sel = p.id == plant;
                return GestureDetector(
                  onTap: () => setState(() => plant = p.id),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    width: 74,
                    decoration: BoxDecoration(
                      color: sel ? C.accent.withValues(alpha: 0.18) : C.surface,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: sel ? C.accent : Colors.transparent, width: 1.6),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(p.emoji, style: const TextStyle(fontSize: 26)),
                        const SizedBox(height: 2),
                        Text(p.name, style: const TextStyle(fontSize: 11), maxLines: 1, overflow: TextOverflow.ellipsis),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 14),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text('مدة التركيز', style: TextStyle(color: C.sub)),
                    const Spacer(),
                    Text(fmtMin(minutes), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: C.accent)),
                  ],
                ),
                Slider(
                  value: minutes.toDouble(),
                  min: 5,
                  max: 120,
                  divisions: 23,
                  onChanged: (v) => setState(() => minutes = v.round()),
                ),
                const SizedBox(height: 4),
                const Text('المادة', style: TextStyle(color: C.sub)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  runSpacing: 2,
                  children: [
                    ChoiceChip(
                      label: const Text('بدون'),
                      selected: subjectId == null,
                      onSelected: (_) => setState(() => subjectId = null),
                    ),
                    for (final sub in s.subjects)
                      ChoiceChip(
                        label: Text('${sub.emoji} ${sub.name}'),
                        selected: subjectId == sub.id,
                        onSelected: (_) => setState(() => subjectId = sub.id),
                      ),
                  ],
                ),
                const SizedBox(height: 6),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: s.strict,
                  onChanged: s.setStrict,
                  title: const Text('وضع الصرامة'),
                  subtitle: const Text('تذبل الشجرة إن غادرت التطبيق أكثر من 8 ثوانٍ',
                      style: TextStyle(fontSize: 12, color: C.sub)),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: s.lowPower,
                  onChanged: s.setLowPower,
                  title: const Text('وضع الأداء المنخفض'),
                  subtitle: const Text('مشهد ثابت وتفاصيل أقل للهواتف الضعيفة. أطفئه لتحصل على حركة وأشجار أغنى',
                      style: TextStyle(fontSize: 12, color: C.sub)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            style: bigButton(),
            onPressed: () => _begin(s),
            icon: const Icon(Icons.eco),
            label: const Text('ازرع وابدأ التركيز'),
          ),
        ],
      ),
    );
  }

  // ---------------- أثناء التركيز ----------------
  Widget _running(AppStore s) {
    final a = s.active!;
    final now = DateTime.now().millisecondsSinceEpoch;
    final total = a.minutes * 60000;
    final g = ((now - a.startMs) / total).clamp(0.0, 1.0).toDouble();
    final remSec = ((a.endMs - now) / 1000).ceil().clamp(0, 999999).toInt();
    final mm = (remSec ~/ 60).toString().padLeft(2, '0');
    final ss = (remSec % 60).toString().padLeft(2, '0');
    final sub = a.subjectId == null ? null : s.subjectById(a.subjectId!);
    final p = plantById(a.type);
    return Column(
      children: [
        Expanded(
          child: ForestView(
            key: const ValueKey('running'),
            plants: [
              PlantInstance(id: 'live', type: a.type, x: 0, z: 0, seed: 7, size: sizeForMinutes(a.minutes), growth: g),
            ],
            autoRotate: true,
            islandR: 2.3,
            zoom: 1.2,
            centerY: 0.6,
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
          child: Column(
            children: [
              Text('$mm:$ss',
                  style: const TextStyle(fontSize: 64, fontWeight: FontWeight.w800, fontFeatures: [FontFeature.tabularFigures()])),
              Text(
                '${p.emoji} ${p.name} تنمو${sub == null ? '' : ' · ${sub.emoji} ${sub.name}'}',
                style: const TextStyle(color: C.sub),
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(value: g, minHeight: 8, backgroundColor: C.surface2, color: C.accent),
              ),
              const SizedBox(height: 12),
              TextButton.icon(
                onPressed: _giveUp,
                icon: const Icon(Icons.close, color: C.danger),
                label: const Text('تخلَّ عن الجلسة', style: TextStyle(color: C.danger)),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
