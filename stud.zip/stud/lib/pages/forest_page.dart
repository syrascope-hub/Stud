import 'package:flutter/material.dart';
import '../forest_view.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

class ForestPage extends StatefulWidget {
  const ForestPage({super.key});
  @override
  State<ForestPage> createState() => _ForestPageState();
}

class _ForestPageState extends State<ForestPage> {
  int day = weekdayIndex(DateTime.now());
  int weekOffset = 0;

  DateTime get _weekStart {
    final b = weekStartOf(DateTime.now());
    return DateTime(b.year, b.month, b.day + 7 * weekOffset);
  }

  String get _wk => dateKey(_weekStart);

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    final wk = _wk;
    final list = s.plantsFor(wk, day);
    final alive = list.where((p) => p.alive).length;
    final dead = list.length - alive;
    final mins = list.where((p) => p.alive).fold(0, (a, b) => a + b.minutes);
    final dayDate = DateTime(_weekStart.year, _weekStart.month, _weekStart.day + day);

    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 12, 12),
            child: Row(
              children: [
                const Expanded(
                  child: Text('غابتي', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                ),
                IconButton(
                  onPressed: () => setState(() => weekOffset--),
                  icon: const Icon(Icons.chevron_right),
                ),
                Text(
                  weekOffset == 0 ? 'هذا الأسبوع' : (weekOffset == -1 ? 'الأسبوع الماضي' : 'قبل ${-weekOffset} أسابيع'),
                  style: const TextStyle(color: C.sub, fontSize: 13),
                ),
                IconButton(
                  onPressed: weekOffset >= 0 ? null : () => setState(() => weekOffset++),
                  icon: const Icon(Icons.chevron_left),
                ),
              ],
            ),
          ),
          DayChips(
            selected: day,
            onTap: (i) => setState(() => day = i),
            badge: (i) => s.plantsFor(wk, i).where((p) => p.alive).length,
          ),
          const SizedBox(height: 10),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(28),
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: ForestView(
                        key: ValueKey('$wk-$day'),
                        autoRotate: true,
                        plants: [
                          for (final r in list)
                            PlantInstance(
                              id: r.id,
                              type: r.type,
                              x: r.x,
                              z: r.z,
                              seed: r.seed,
                              size: sizeForMinutes(r.minutes),
                              alive: r.alive,
                            ),
                        ],
                        onTapPlant: (pi) {
                          final rec = list.firstWhere((r) => r.id == pi.id);
                          _showPlant(s, rec);
                        },
                      ),
                    ),
                    Positioned(
                      top: 12,
                      left: 12,
                      right: 12,
                      child: Row(
                        children: [
                          _chip('${dayNames[day]} ${dayDate.day}/${dayDate.month}'),
                          const Spacer(),
                          _chip('🌳 $alive'),
                          const SizedBox(width: 6),
                          if (dead > 0) ...[_chip('🥀 $dead'), const SizedBox(width: 6)],
                          _chip('⏱ ${fmtMin(mins)}'),
                        ],
                      ),
                    ),
                    if (list.isEmpty)
                      Positioned(
                        bottom: 18,
                        left: 24,
                        right: 24,
                        child: Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.45),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: Text(
                            'غابة ${dayNames[day]} فارغة.\nابدأ جلسة تركيز لتزرع أول شجرة 🌱',
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white, height: 1.6),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _chip(String t) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.42),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Text(t, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
      );

  void _showPlant(AppStore s, PlantRecord r) {
    final p = plantById(r.type);
    final t = DateTime.fromMillisecondsSinceEpoch(r.ts);
    final sub = r.subjectId == null ? null : s.subjectById(r.subjectId!);
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 4, 24, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(r.alive ? p.emoji : '🥀', style: const TextStyle(fontSize: 52)),
            const SizedBox(height: 6),
            Text(p.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text(
              '${r.alive ? 'نمت بعد' : 'ذبلت (كانت ستنمو في)'} ${fmtMin(r.minutes)}'
              '${sub == null ? '' : ' · ${sub.emoji} ${sub.name}'}',
              style: const TextStyle(color: C.sub),
            ),
            const SizedBox(height: 4),
            Text(
              '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')} · ${t.day}/${t.month}',
              style: const TextStyle(color: C.sub, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
