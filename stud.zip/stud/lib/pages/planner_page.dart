import 'package:flutter/material.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

class PlannerPage extends StatefulWidget {
  const PlannerPage({super.key});
  @override
  State<PlannerPage> createState() => _PlannerPageState();
}

class _PlannerPageState extends State<PlannerPage> {
  bool week = false;
  int day = weekdayIndex(DateTime.now());

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    return Scaffold(
      backgroundColor: C.bg,
      floatingActionButton: week
          ? null
          : FloatingActionButton.extended(
              backgroundColor: C.accent,
              foregroundColor: C.onAccent,
              onPressed: () => showItemSheet(context, s, day: day),
              icon: const Icon(Icons.add),
              label: const Text('مهمة'),
            ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 12),
              child: Row(
                children: [
                  const Expanded(
                    child: Text('مخططي', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                  ),
                  SegmentedButton<bool>(
                    showSelectedIcon: false,
                    style: SegmentedButton.styleFrom(visualDensity: VisualDensity.compact),
                    segments: const [
                      ButtonSegment(value: false, label: Text('يومي')),
                      ButtonSegment(value: true, label: Text('أسبوعي')),
                    ],
                    selected: {week},
                    onSelectionChanged: (v) => setState(() => week = v.first),
                  ),
                ],
              ),
            ),
            Expanded(child: week ? _weekView(s) : _dayView(s)),
          ],
        ),
      ),
    );
  }

  // ---------------- يومي ----------------
  Widget _dayView(AppStore s) {
    final wk = s.currentWeekKey;
    final items = s.itemsForDay(day);
    final planned = s.plannedMinutes(day);
    final dn = s.doneMinutes(day, wk);
    final today = weekdayIndex(DateTime.now());
    return Column(
      children: [
        DayChips(
          selected: day,
          onTap: (i) => setState(() => day = i),
          badge: (i) => s.itemsForDay(i).length,
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 100),
            children: [
              Panel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          dayNames[day] + (day == today ? ' · اليوم' : ''),
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                        ),
                        const Spacer(),
                        Text('${fmtMin(dn)} / ${fmtMin(planned)}', style: TextStyle(color: C.sub)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: planned == 0 ? 0 : dn / planned,
                        minHeight: 10,
                        backgroundColor: C.surface2,
                        color: C.accent,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              if (items.isEmpty)
                Padding(
                  padding: EdgeInsets.all(40),
                  child: Center(
                    child: Text('لا مهام في هذا اليوم.\nأضف مهمة أو اطلب من المساعد 🌱',
                        textAlign: TextAlign.center, style: TextStyle(color: C.sub, height: 1.7)),
                  ),
                )
              else
                for (final it in items)
                  Padding(padding: const EdgeInsets.only(bottom: 10), child: _tile(s, it, wk)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _tile(AppStore s, PlanItem it, String wk) {
    final sub = s.subjectById(it.subjectId);
    final d = s.isDone(it, wk);
    return GestureDetector(
      onTap: () => showItemSheet(context, s, item: it, day: day),
      child: Opacity(
        opacity: d ? 0.55 : 1,
        child: Panel(
          padding: const EdgeInsets.fromLTRB(14, 12, 6, 12),
          child: Row(
            children: [
              Container(
                width: 5,
                height: 46,
                decoration: BoxDecoration(color: sub.c, borderRadius: BorderRadius.circular(4)),
              ),
              const SizedBox(width: 12),
              Text(sub.emoji, style: const TextStyle(fontSize: 26)),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      sub.name,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        decoration: d ? TextDecoration.lineThrough : null,
                      ),
                    ),
                    if (it.title.isNotEmpty)
                      Text(it.title, style: TextStyle(color: C.sub, fontSize: 13)),
                    Text(fmtMin(it.minutes), style: TextStyle(color: sub.c, fontSize: 12, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'ابدأ تركيزاً',
                icon: Icon(Icons.play_circle_fill, color: C.accent, size: 30),
                onPressed: () => s.startFocusFor(it),
              ),
              IconButton(
                tooltip: 'تم',
                icon: Icon(d ? Icons.check_circle : Icons.radio_button_unchecked,
                    color: d ? C.accent : C.sub, size: 28),
                onPressed: () => s.toggleDone(it, wk),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------- أسبوعي ----------------
  Widget _weekView(AppStore s) {
    final today = weekdayIndex(DateTime.now());
    final total = List.generate(7, (i) => s.plannedMinutes(i)).fold(0, (a, b) => a + b);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        Panel(
          child: Row(
            children: [
              const Text('📅', style: TextStyle(fontSize: 26)),
              const SizedBox(width: 12),
              Expanded(
                child: Text('إجمالي الأسبوع: ${fmtMin(total)}',
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        for (var i = 0; i < 7; i++) ...[
          GestureDetector(
            onTap: () => setState(() {
              day = i;
              week = false;
            }),
            child: Panel(
              color: i == today ? C.surface2 : null,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(dayNames[i], style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                      if (i == today)
                        Container(
                          margin: const EdgeInsets.symmetric(horizontal: 8),
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(color: C.accent, borderRadius: BorderRadius.circular(10)),
                          child: Text('اليوم', style: TextStyle(color: C.onAccent, fontSize: 11, fontWeight: FontWeight.w700)),
                        ),
                      const Spacer(),
                      Text(fmtMin(s.plannedMinutes(i)), style: TextStyle(color: C.sub)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  _segments(s, i),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final it in s.itemsForDay(i))
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                          decoration: BoxDecoration(
                            color: s.subjectById(it.subjectId).c.withValues(alpha: 0.18),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            '${s.subjectById(it.subjectId).emoji} ${s.subjectById(it.subjectId).name} ${fmtMin(it.minutes)}',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                      if (s.itemsForDay(i).isEmpty)
                        Text('— راحة —', style: TextStyle(color: C.sub, fontSize: 12)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
        ],
      ],
    );
  }

  Widget _segments(AppStore s, int d) {
    final items = s.itemsForDay(d);
    if (items.isEmpty) {
      return Container(height: 8, decoration: BoxDecoration(color: C.surface2, borderRadius: BorderRadius.circular(6)));
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(6),
      child: SizedBox(
        height: 8,
        child: Row(
          children: [
            for (final it in items)
              Expanded(flex: it.minutes, child: Container(color: s.subjectById(it.subjectId).c)),
          ],
        ),
      ),
    );
  }
}

/// نافذة إضافة / تعديل مهمة
Future<void> showItemSheet(BuildContext context, AppStore s, {PlanItem? item, required int day}) {
  var d = item?.day ?? day;
  var sid = item?.subjectId ?? (s.subjects.isNotEmpty ? s.subjects.first.id : 'x');
  var minutes = item?.minutes ?? 60;
  final ctl = TextEditingController(text: item?.title ?? '');
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => Padding(
        padding: EdgeInsets.fromLTRB(20, 4, 20, 20 + MediaQuery.of(ctx).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(item == null ? 'مهمة جديدة' : 'تعديل المهمة',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 14),
              Text('المادة', style: TextStyle(color: C.sub)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  for (final sub in s.subjects)
                    ChoiceChip(
                      label: Text('${sub.emoji} ${sub.name}'),
                      selected: sid == sub.id,
                      onSelected: (_) => set(() => sid = sub.id),
                    ),
                ],
              ),
              const SizedBox(height: 12),
              Text('اليوم', style: TextStyle(color: C.sub)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  for (var i = 0; i < 7; i++)
                    ChoiceChip(label: Text(dayNames[i]), selected: d == i, onSelected: (_) => set(() => d = i)),
                ],
              ),
              const SizedBox(height: 12),
              TextField(controller: ctl, decoration: fieldDeco('الوصف (اختياري)', hint: 'مثال: 3 فيديوهات + حل')),
              const SizedBox(height: 12),
              Row(
                children: [
                  Text('المدة', style: TextStyle(color: C.sub)),
                  const Spacer(),
                  IconButton.filledTonal(
                    onPressed: () => set(() => minutes = (minutes - 15).clamp(15, 360)),
                    icon: const Icon(Icons.remove),
                  ),
                  SizedBox(
                    width: 86,
                    child: Text(fmtMin(minutes),
                        textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                  ),
                  IconButton.filledTonal(
                    onPressed: () => set(() => minutes = (minutes + 15).clamp(15, 360)),
                    icon: const Icon(Icons.add),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              FilledButton(
                style: bigButton(),
                onPressed: () {
                  if (item == null) {
                    s.addItem(day: d, subjectId: sid, title: ctl.text.trim(), minutes: minutes);
                  } else {
                    s.updateItem(item, day: d, subjectId: sid, title: ctl.text.trim(), minutes: minutes);
                  }
                  Navigator.pop(ctx);
                },
                child: const Text('حفظ'),
              ),
              if (item != null)
                TextButton.icon(
                  onPressed: () {
                    s.removeItem(item);
                    Navigator.pop(ctx);
                  },
                  icon: Icon(Icons.delete_outline, color: C.danger),
                  label: Text('حذف', style: TextStyle(color: C.danger)),
                ),
            ],
          ),
        ),
      ),
    ),
  );
}
