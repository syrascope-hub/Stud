import 'package:flutter/material.dart';
import '../art.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});
  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  final _ctl = PageController();
  int _i = 0;

  static const _titles = ['ازرع شجرة، ركّز', 'نظّم أسبوعك', 'مساعد يعدّل مخططك'];
  static const _texts = [
    'كل جلسة تركيز تزرع شجرة. إن خرجت من التطبيق ذبلت، وإن أكملتها نمت غابتك يوماً بعد يوم.',
    'مخطط يومي وأسبوعي لموادك. تتبّع ما أنجزته وابدأ التركيز على أي مهمة بضغطة.',
    'قل له ما تريد تغييره في جدولك بكلماتك، وسيعدّله لك فوراً مع إمكانية التراجع.',
  ];

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  Widget _art(int i, double size) {
    if (i == 0) {
      return TimerCircle(size: size, progress: 0.7, type: 'pine', growth: 1.0);
    }
    if (i == 1) {
      return SizedBox(
        width: size,
        height: size,
        child: Center(
          child: Container(
            width: size * 0.92,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.95), borderRadius: BorderRadius.circular(26)),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (var d = 0; d < 4; d++)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    child: Row(
                      children: [
                        SizedBox(width: 54, child: Text(dayNames[d], style: const TextStyle(color: Color(0xFF1C3A2E), fontWeight: FontWeight.w700, fontSize: 13))),
                        for (var k = 0; k < 2 + (d % 3); k++)
                          Expanded(
                            flex: 2 + ((d + k) % 3),
                            child: Container(
                              height: 12,
                              margin: const EdgeInsets.symmetric(horizontal: 2),
                              decoration: BoxDecoration(
                                color: const [Color(0xFF4FC3F7), Color(0xFFFFB74D), Color(0xFFBA68C8), Color(0xFF81C784)][k],
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    }
    return SizedBox(
      width: size,
      height: size,
      child: Container(
        decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.2), shape: BoxShape.circle),
        child: Center(child: Sprout(size: size * 0.8)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = StoreScope.of(context);
    final w = MediaQuery.of(context).size.width;
    final art = (w * 0.68).clamp(180.0, 300.0).toDouble();
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [C.stage, Color.lerp(C.stage, Colors.black, 0.25)!],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Align(
                alignment: AlignmentDirectional.centerEnd,
                child: TextButton(
                  onPressed: s.finishOnboarding,
                  child: const Text('تخطّي', style: TextStyle(color: Colors.white70)),
                ),
              ),
              Expanded(
                child: PageView.builder(
                  controller: _ctl,
                  itemCount: 3,
                  onPageChanged: (v) => setState(() => _i = v),
                  itemBuilder: (_, i) => Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _art(i, art),
                        const SizedBox(height: 32),
                        Text(
                          _titles[i],
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          _texts[i],
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Colors.white70, fontSize: 15, height: 1.8),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (var k = 0; k < 3; k++)
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.all(4),
                      width: _i == k ? 22 : 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: _i == k ? Colors.white : Colors.white38,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
                child: FilledButton(
                  style: bigButton(bg: const Color(0xFF6FD3A8), fg: const Color(0xFF0B3B2A)),
                  onPressed: () {
                    if (_i < 2) {
                      _ctl.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
                    } else {
                      s.finishOnboarding();
                    }
                  },
                  child: Text(_i < 2 ? 'التالي' : 'ابدأ'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
